-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2022 at 08:45 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `care`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity`
--

CREATE TABLE `activity` (
  `id` int(11) NOT NULL,
  `activity_by` int(11) NOT NULL,
  `tittle` varchar(60) NOT NULL,
  `category` varchar(60) NOT NULL DEFAULT 'Alert',
  `information` varchar(100) NOT NULL,
  `event_time` varchar(60) NOT NULL,
  `msgto` int(11) NOT NULL DEFAULT 0,
  `activity_status` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `activity`
--

INSERT INTO `activity` (`id`, `activity_by`, `tittle`, `category`, `information`, `event_time`, `msgto`, `activity_status`) VALUES
(1, 0, 'New child has been added', 'info', '	\r\nabi madame ,', '1654233922', 0, 1),
(2, 0, 'System Under Maintenance', 'Alert', 'The Care international system is still under maintenance you would excuse the failures you may find ', '1654619421', 0, 1),
(3, 1, 'New Name has been Added', 'message', 'New name:Guaranted has been added to the system', '1656407402', 0, 1),
(4, 1, 'New Name has been Added', 'info', 'New name: Bwiza. has been added to the system', '1658225589', 0, 1),
(5, 1, 'A New User has been Added', 'info', 'New User: paddy. has been added to the system', '1658355399', 0, 1),
(6, 1, 'A New Location/Branch has been Added', 'info', 'New Branch: Gasabo. has been added to the system', '1658356577', 0, 1),
(7, 1, 'A New Location/Branch has been Added', 'info', 'New Branch: Nyarugenge. has been added to the system', '1658356712', 0, 1),
(8, 1, 'A New User has been Added', 'info', 'New User: vfiacre. has been added to the system', '1658401858', 0, 1),
(9, 0, 'vfiacre Rules .Nyarugenge. Branch', 'info', 'Care Rwanda, .Nyarugenge. Branch is Now is Managed By : 4. if you may call him/her on any informatio', '1658513792', 0, 1),
(10, 1, 'vfiacre Rules .Nyarugenge. Branch', 'info', 'Care Rwanda, .Nyarugenge. Branch is Now is Managed By : 4. if you may call him/her on any informatio', '1658513962', 0, 1),
(11, 1, 'A New Location/Branch has been Added', 'info', 'New Branch: Muhanga. has been added to the system', '1659036448', 0, 1),
(12, 1, 'A New Location/Branch has been Added', 'info', 'New Branch: Muhanga. has been added to the system', '1659036473', 0, 1),
(13, 4, 'New Name has been Added', 'info', 'New name: Mutoni. has been added to the system', '1659197964', 0, 1),
(14, 1, 'A New Location/Branch has been Added', 'info', 'New Branch: Rusizi. has been added to the system', '1659896132', 0, 1),
(15, 1, 'A New User has been Added', 'info', 'New User: Jado. has been added to the system', '1659897116', 0, 1),
(16, 1, 'Jado Rules .Rusizi. Branch Now', 'info', 'Care Rwanda, .Rusizi. Branch is Now is Managed By : 5. if you may call him/her on any information', '1660063000', 0, 1),
(17, 1, 'Jado Rules .Rusizi. Branch Now', 'info', 'Care Rwanda, .Rusizi. Branch is Now is Managed By : 5. if you may call him/her on any information', '1660063134', 0, 1),
(18, 1, 'A New Location/Branch has been Added', 'info', 'New Branch: Karongi. has been added to the system', '1660242224', 0, 1),
(19, 3, 'New Name has been Added', 'info', 'New name: Uwizeyimana. has been added to the system', '1660242390', 0, 1),
(20, 1, 'A New User has been Added', 'info', 'New User: u.ange. has been added to the system', '1663252610', 0, 1),
(21, 1, 'New Name has been Added', 'info', 'New name: Gretta. has been added to the system', '1664201226', 0, 1),
(22, 1, 'You have Given A BRANCH tO Manage', 'message', 'Hello: u.ange. You are now Responsibly to .Muhanga. branch of Care Rwanda', '1667520395', 6, 1),
(23, 1, 'u.ange Rules .Muhanga. Branch Now', 'info', 'Care Rwanda, .Muhanga. Branch is Now is Managed By : 6. if you may call him/her on any information', '1667520395', 0, 1),
(24, 1, 'A New Location/Branch has been Added', 'info', 'New Branch: Gasabo. has been added to the system', '1669329230', 0, 1),
(25, 4, 'New Name has been Added', 'info', 'New name: Asake. has been added to the system', '1669407948', 0, 1),
(26, 3, 'New Name has been Added', 'info', 'New name: Mushimiyimana. has been added to the system', '1669464550', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cases`
--

CREATE TABLE `cases` (
  `id` int(11) NOT NULL,
  `case_code` varchar(60) NOT NULL,
  `case_time` varchar(60) NOT NULL,
  `event_text` varchar(1000) NOT NULL,
  `child_id` int(11) NOT NULL,
  `event_by` int(11) NOT NULL,
  `event_time` varchar(60) NOT NULL,
  `event_tittle` varchar(100) NOT NULL,
  `request` tinyint(1) NOT NULL DEFAULT 0,
  `progress` int(11) NOT NULL,
  `closed` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cases`
--

INSERT INTO `cases` (`id`, `case_code`, `case_time`, `event_text`, `child_id`, `event_by`, `event_time`, `event_tittle`, `request`, `progress`, `closed`) VALUES
(1, 'CABF', '1663183537', ' Replace this with your Message...e\r\n Ange.U                      ', 6, 1, '1663183537', 'Raised a Case', 1, 1, 0),
(2, '8B9U', '1664201647', '                      Please check all necessary Info to Gretta, You can consider the Sponsorship! \r\n                       \r\n                        Ange.U                      ', 13, 1, '1664201647', 'Raised a Case', 1, 1, 0),
(3, '75UH', '1667515018', '             Yes this is Necessary for sure\r\n               ', 6, 1, '1667515018', 'Added an idea', 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `donations`
--

CREATE TABLE `donations` (
  `id` int(11) NOT NULL,
  `Donor_names` varchar(60) NOT NULL,
  `Donor_email` varchar(60) NOT NULL,
  `amout` int(11) NOT NULL,
  `donor_msg` varchar(200) NOT NULL,
  `donate_for` int(11) NOT NULL,
  `event_time` varchar(60) NOT NULL,
  `particular_reasons` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donations`
--

INSERT INTO `donations` (`id`, `Donor_names`, `Donor_email`, `amout`, `donor_msg`, `donate_for`, `event_time`, `particular_reasons`) VALUES
(1, 'Ketty', 'Ketty@gmail.com', 1002, 'we', 0, '1668434663', 'No reason Given'),
(2, 'amanda', 'amanda@gmail.com', 10034, 'scascas', 0, '1668434692', 'No reason Given'),
(3, 'Kevin', 'Kevin@gmail.com', 100000, 'Just Helping', 0, '1668434964', 'No reason Given');

-- --------------------------------------------------------

--
-- Table structure for table `girls`
--

CREATE TABLE `girls` (
  `id` int(11) NOT NULL,
  `fname` varchar(60) NOT NULL,
  `lname` varchar(60) NOT NULL,
  `age` int(11) NOT NULL,
  `phone` varchar(20) NOT NULL DEFAULT 'NA',
  `email` varchar(60) NOT NULL DEFAULT 'N/A',
  `girl_unique` varchar(60) NOT NULL DEFAULT 'None',
  `birthdate` varchar(60) NOT NULL,
  `image` varchar(60) NOT NULL DEFAULT 'profile.png',
  `about` varchar(1000) NOT NULL,
  `district` int(11) NOT NULL,
  `lsector` varchar(60) NOT NULL DEFAULT 'Unknown',
  `lcell` varchar(60) NOT NULL DEFAULT 'Unknown',
  `supervisor` int(11) NOT NULL,
  `join_date` varchar(60) NOT NULL,
  `inschool` tinyint(1) NOT NULL DEFAULT 0,
  `father` varchar(60) NOT NULL,
  `mother` varchar(60) NOT NULL,
  `palive` tinyint(1) NOT NULL DEFAULT 1,
  `malive` tinyint(1) NOT NULL DEFAULT 1,
  `category` varchar(60) NOT NULL DEFAULT 'Normal',
  `boy_names` varchar(60) NOT NULL DEFAULT 'Unknown',
  `boy_bod` varchar(60) NOT NULL DEFAULT 'Unknown',
  `boy_age` int(11) NOT NULL DEFAULT 0,
  `boy_location` varchar(60) NOT NULL DEFAULT 'Unknown',
  `hospital` varchar(60) NOT NULL DEFAULT 'Unknown',
  `hospital_id` varchar(60) NOT NULL DEFAULT 'Unknown'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `girls`
--

INSERT INTO `girls` (`id`, `fname`, `lname`, `age`, `phone`, `email`, `girl_unique`, `birthdate`, `image`, `about`, `district`, `lsector`, `lcell`, `supervisor`, `join_date`, `inschool`, `father`, `mother`, `palive`, `malive`, `category`, `boy_names`, `boy_bod`, `boy_age`, `boy_location`, `hospital`, `hospital_id`) VALUES
(4, 'abi', 'madame', 15, 'NA', '', '3WQMSO', '1169334000', '1654297166_member.jpg', '                <p>Hello Care Rwanda!</p>\r\n                <p>This should be a<strong>full Story</strong> For this Unique Girl</p>\r\n              ', 1, 'Unknown', 'Unknown', 2, '1654233922', 0, '', '', 1, 1, 'Normal', 'Unknown', 'Unknown', 0, 'Unknown', 'Unknown', 'Unknown'),
(5, 'Second ', 'Child', 16, 'NA', 'uwizeyimana@gmail.com', 'RZGPTJ', '1150063200', '1654619519_member.jpg', '<p>Hello Care Rwanda!</p>\r\n<p>This should be a<strong>full Story</strong> For this Unique Girl</p>', 2, 'Unknown', 'Unknown', 1, '1654619421', 0, 'Papa Second2', '1', 0, 1, 'Major', 'Unknown', 'Unknown', 0, 'Unknown', 'Unknown', 'Unknown'),
(6, 'Guaranted', 'Prints', 15, '0785637288', '', 'A07P39', '1182895200', '1656407471_member.jpg', '<p>Hello Care Rwanda!</p>\r\n<p>This should be a<strong>full Story</strong> For this Unique Girl</p>', 1, 'Unknown', 'Unknown', 1, '1656407402', 0, 'Papa Guaranted', 'mama Prints', 1, 1, 'Major', 'Unknown', 'Unknown', 0, 'Unknown', 'Unknown', 'Unknown'),
(7, 'Bwiza', 'Leady', 9, '0784624822', 'bwiza@gmail.com', 'AQTJ0L', '1365285600', 'profile.png', '<p>Hello Care Rwanda!</p>\r\n<p>I go the run my place, remember my name ,the name is kweku the husler, it\'s great mn i know Bwiza Bwiza account remember u know what traveler ,i know u miss me i kno tell me you u u , Niba un kunda u u u See i</p>\r\n<p>go marry you ,if u wait me i go gm u</p>', 1, 'Unknown', 'Unknown', 1, '1658225423', 0, '', '', 1, 1, 'Normal', 'Unknown', 'Unknown', 0, 'Unknown', 'Unknown', 'Unknown'),
(8, 'Bwiza', 'Leady', 9, '0784624822', 'bwiza@gmail.com', '23G9SQ', '1365285600', 'profile.png', '<p>Hello Care Rwanda!</p>\r\n<p>I go the run my place, remember my name ,the name is kweku the husler, it\'s great mn i know Bwiza Bwiza account remember u know what traveler ,i know u miss me i kno tell me you u u , Niba un kunda u u u See i</p>\r\n<p>go marry you ,if u wait me i go gm u</p>', 1, 'Unknown', 'Unknown', 1, '1658225533', 0, '', '', 1, 1, 'Normal', 'Unknown', 'Unknown', 0, 'Unknown', 'Unknown', 'Unknown'),
(9, 'Bwiza', 'Leady', 9, '0784624822', 'bwiza@gmail.com', 'NAVG8K', '1365285600', 'profile.png', '<p>Hello Care Rwanda!</p>\r\n<p>I go the run my place, remember my name ,the name is kweku the husler, it\'s great mn i know Bwiza Bwiza account remember u know what traveler ,i know u miss me i kno tell me you u u , Niba un kunda u u u See i</p>\r\n<p>go marry you ,if u wait me i go gm u</p>', 1, 'Unknown', 'Unknown', 1, '1658225558', 0, '', '', 1, 1, 'Normal', 'Unknown', 'Unknown', 0, 'Unknown', 'Unknown', 'Unknown'),
(10, 'Bwiza', 'Leady', 9, '0784624822', 'bwiza@gmail.com', 'DKP9EN', '1365285600', '1658225674_member.jpg', '<p>Hello Care Rwanda!</p>\r\n<p>I go the run my place, remember my name ,the name is kweku the husler, it\'s great mn i know Bwiza Bwiza account remember u know what traveler ,i know u miss me i kno tell me you u u , Niba un kunda u u u See i</p>\r\n<p>go marry you ,if u wait me i go gm u</p>', 1, 'Unknown', 'Unknown', 1, '1658225589', 1, 'Bwiza Muzehe', 'MUKABWIZA', 1, 0, 'Minor', 'Unknown', 'Unknown', 0, 'Unknown', 'Unknown', 'Unknown'),
(11, 'Mutoni', 'Clementine', 13, 'NA', '', 'L04REP', '1239746400', '1659198085_member.jpg', '<p>Hello Care Rwanda!</p>\r\n<p>This should be a<strong>full Story</strong> For Mutoni Clementine!</p>', 4, 'Unknown', 'Unknown', 4, '1659197964', 1, 'Clement', 'Mutoni', 1, 1, 'Minor', 'Unknown', 'Unknown', 0, 'Unknown', 'Unknown', 'Unknown'),
(12, 'Uwizeyimana', 'Femme', 12, 'NA', 'Uwizeyimana1@gmail.com', '29JZRK', '1262300400', 'profile.png', '<p>Hello Care Rwanda!</p>\r\n<p>This should be a<strong>full Story</strong> For this Unique Girl</p>', 0, 'Unknown', 'Unknown', 3, '1660242390', 0, '', '', 1, 1, 'Normal', 'Unknown', 'Unknown', 0, 'Unknown', 'Unknown', 'Unknown'),
(13, 'Gretta', 'Umutoniwase', 23, '0788343563', 'umutoniwase@gmail.com', 'P1R4QF', '937864800', '1664201369_member.jpg', '<p>Hello Care Rwanda!</p>\r\n<p>This should be a<strong>full Story</strong> For this Unique Girl</p>', 4, 'Unknown', 'Unknown', 1, '1664201226', 1, 'Didi', 'Dudu', 1, 1, 'Critical', 'Unknown', 'Unknown', 0, 'Unknown', 'Unknown', 'Unknown'),
(14, 'Asake', 'Mukeshimana', 16, '0785318962', 'asake@gmail.com', 'JDBY4K', '1150236000', '1669411493_member.jpg', '<p>Asake has became&nbsp; a single Mom on her Only 16 years old<br />Due to the Luck of education that could have prevented her from getting into Gangs who belives schools are for Loosers</p>', 0, 'Unknown', 'Unknown', 4, '1669407948', 0, '', '', 1, 1, 'Normal', 'Unknown', 'Unknown', 0, 'Unknown', 'Unknown', 'Unknown'),
(15, 'Mushimiyimana', 'Sandrine', 17, '0785318962', 'sandy@gmail.com', '1NCK63', '1115330400', '1669464594_member.jpg', '<p>Sandrine Mushimiyimana</p>\r\n<p>&nbsp;</p>\r\n<p>A young Girl who deserves a care than Before</p>', 10, 'Gikondo', 'kagunga', 3, '1669464550', 1, 'Muzehe Nshimiye', 'Uwimana Marie Ange', 0, 1, 'Major', 'Mugabo Ghad', '862610400', 25, 'Kigali -Kicukiro', 'CHUK', 'CH1278342K');

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `id` int(11) NOT NULL,
  `country` varchar(60) NOT NULL DEFAULT 'Rwanda',
  `province` varchar(60) NOT NULL,
  `District` varchar(60) NOT NULL,
  `sector` varchar(60) NOT NULL DEFAULT 'Kigarama',
  `cell` varchar(60) NOT NULL DEFAULT 'Kigarama',
  `created_date` varchar(60) NOT NULL,
  `D_admin` int(11) NOT NULL,
  `approve` tinyint(1) NOT NULL DEFAULT 0,
  `total_girls` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`id`, `country`, `province`, `District`, `sector`, `cell`, `created_date`, `D_admin`, `approve`, `total_girls`) VALUES
(1, 'Rwanda', 'Kigali', 'Kicukiro', 'Kigarama', 'Kigarama', '1658356712', 1, 0, 0),
(2, 'Rwanda', 'Kigali', 'Gasabo', 'Bumbogo', 'Musave', '1658356712', 2, 0, 0),
(4, 'Rwanda', 'Kigali', 'Nyarugenge', 'Kimisagara', 'Kamuhoza', '1658356712', 4, 0, 0),
(5, 'Rwanda', 'South ', 'Muhanga', 'Shyogwe', 'Kinini', '1659036448', 6, 0, 0),
(7, 'Rwanda', 'western', 'Rusizi', 'Bugarama', 'Nyange', '1659896132', 5, 0, 0),
(8, 'Rwanda', 'Western', 'Karongi', 'Runda', 'Bwishyura', '1660242224', 0, 0, 0),
(9, 'Rwanda', 'Kigali', 'Gasabo', 'Rusororo', 'Kabuga I', '1669329230', 1, 0, 0),
(10, 'Rwanda', 'Kigali', 'Kicukiro', 'Gikondo', 'kagunga', '', 1, 0, 0),
(11, 'Rwanda', 'Kigali', 'Kicukiro', 'Gikondo', 'kagunga', '1669463557', 1, 0, 0),
(12, 'Rwanda', 'Kigali', 'Kicukiro', 'Gikondo', 'kagunga', '1669464162', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fname` varchar(60) NOT NULL,
  `lname` varchar(60) NOT NULL,
  `user_name` varchar(60) NOT NULL,
  `Join_date` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  `profile` varchar(60) NOT NULL DEFAULT 'profile.png',
  `contacts` varchar(13) NOT NULL,
  `country` varchar(60) NOT NULL DEFAULT 'Rwanda',
  `R_district` int(11) NOT NULL,
  `status` varchar(60) NOT NULL DEFAULT 'offline',
  `first_login` tinyint(1) NOT NULL DEFAULT 0,
  `account_type` varchar(60) NOT NULL DEFAULT 'user',
  `last_login` varchar(60) NOT NULL,
  `about` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `user_name`, `Join_date`, `email`, `password`, `profile`, `contacts`, `country`, `R_district`, `status`, `first_login`, `account_type`, `last_login`, `about`) VALUES
(1, 'UMWALI', 'Ange', 'Ange.U', '1652199010', 'abirihosother@gmail.com', '202cb962ac59075b964b07152d234b70', '1667523438_member.jpg', '0785318962', 'Rwanda', 1, 'Offline', 1, 'Manager', '1669452454', 'THIS IS ALL ABOUT My self'),
(2, 'Delphine', 'Mutoni', 'Tsamy', '1649272407', 'tsamy@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'profile.png', '', 'Rwanda', 2, 'Offline', 1, 'user', '1653488564', ''),
(3, '', 'Patrick', 'paddy', '1658355399', 'paddy@gmail.com', '202cb962ac59075b964b07152d234b70', '1669464594_member.jpg', '', 'Rwanda', 1, 'Online', 1, 'user', '1669459239', 'Yes am a member of Care Rwanda but only in Ange\'s School Project\r\nOh my God how i wish this to be in'),
(4, '', 'v', 'vfiacre', '1658401858', 'fiacrerukundo8@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '1669411493_member.jpg', '', 'Rwanda', 4, 'Online', 1, 'user', '1669401595', ''),
(5, 'Jean de Die', 'Rusine', 'Jado', '1659897116', 'jado@gmail.com', '65019d26bfd15474807cbc94fd1cc59b', 'profile.png', '', 'Rwanda', 7, 'offline', 0, 'user', '1659897116', ''),
(6, 'Ange', 'umwali', 'u.ange', '1663252610', 'doknge@gmail.com', 'e7880f4be5b280cb33e4148d01e10192', 'profile.png', '', 'Rwanda', 5, 'Offline', 1, 'user', '1667460800', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity`
--
ALTER TABLE `activity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cases`
--
ALTER TABLE `cases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `donations`
--
ALTER TABLE `donations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `girls`
--
ALTER TABLE `girls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity`
--
ALTER TABLE `activity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `cases`
--
ALTER TABLE `cases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `donations`
--
ALTER TABLE `donations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `girls`
--
ALTER TABLE `girls`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
