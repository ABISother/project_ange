<?php
session_start();
?>
<?php
if(!isset($_SESSION["p_user"])){
echo("<script>location.href='login.php';</script>");
}elseif (isset($_SESSION["p_user"])&& !isset($_SESSION["access"])){
 echo("<script>location.href='lock.php';</script>");
}
else{

    include('../member/connection.php'); 
$account_key=$_SESSION["p_user"];
$sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['user_name'];
$myemail=$fetch_account['email'];


//assignments.php
if(isset($_POST["event_type"]))
{
   
 $event_type = mysqli_real_escape_string($con, $_POST["event_type"]);
 $user= mysqli_real_escape_string($con, $_POST["user_id"]);
 $event_body= mysqli_real_escape_string($con, $_POST["event_body"]);
 $event_body=str_replace("'", "\'",$event_body);

 $now=time();
//echo $user." Is assigned To". $event_type;

if(!isset($_POST["event_code"])){
//===========generate the sku=============
function checkkeys($con,$randstr){
	$sql ="SELECT * FROM cases";
	$result=mysqli_query($con,$sql);
	while ($row=mysqli_fetch_assoc($result)){
		if($row['case_code']==$randstr){
			$keyExists=true;
			break;
			}else{
			$keyExists=false;
		}
    return $keyExists;
	}
}
function generatekey($con){
	$keylength = 4;
$str="1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ";
$randstr = substr(str_shuffle($str),0, $keylength);
$checkkeys= checkkeys($con,$randstr);
while ($checkkeys==true) {
$randstr = substr(str_shuffle($str),0, $keylength);
$checkkeys= checkkeys($con,$randstr);
}
return $randstr;
}
 //echo generatekey($con);
$event_code=generatekey($con);
//------------======------End of sku Generations----========----
}else{
  $event_code=$_POST["event_code"];
}

$saveactivity=$con->query("INSERT INTO cases(case_code,case_time,event_text,child_id,event_by,event_time,event_tittle,request,progress,closed) VALUES ('$event_code','$now','$event_body','$user','$account_key','$now','$event_type','1','1','0')")or die($con->error);
echo '<div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show" role="alert">';

 $sel_clients=$con->query("SELECT*from cases where 	child_id='.$user.' ")or die($con->error); 
 //Danger message

// $changequery=$con->query("UPDATE girls SET image='$imagename' WHERE girl_unique ='$now_member' ")or die($con->error);
   
//  $query = " INSERT INTO comments(comment_subject, comment_text) VALUES ('$subject', '$comment')
//  ";
//  mysqli_query($connect, $query);
}else{
    Echo ' <div class="alert alert-warning alert-dismissable">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h4><i class="icon fa fa-warning"></i> Alert!</h4>
    Nothing Received!
  </div>';
}

}


?>