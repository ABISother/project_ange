<?php
session_start();
?>
<?php
if(!isset($_SESSION["p_user"])){
echo("<script>location.href='../member/login.php';</script>");
}elseif (isset($_SESSION["p_user"])&& !isset($_SESSION["access"])){
 echo("<script>location.href='../member/lock.php';</script>");
}
else{
    include('../member/connection.php'); 
$account_key=$_SESSION["p_user"];
$sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['user_name'];
$myemail=$fetch_account['email'];

$sel_place=$con->query("SELECT*from locations WHERE D_admin='$account_key' ")or die($con->error);
if($count_place=$sel_place->num_rows>0){
//Number of locations this user has responsed to work on
  $locations=$count_place;
 
}else{
  $locations=0;
}

$today=date(" M d, Y");
$time=date("h:i a");
}
    ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Case | Care International Rwanda</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Font Awesome Icons -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons -->
    <link href="http://code.ionicframework.com/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css" />
    <!-- fullCalendar 2.2.5-->
    <link href="plugins/fullcalendar/fullcalendar.min.css" rel="stylesheet" type="text/css" />
    <link href="plugins/fullcalendar/fullcalendar.print.css" rel="stylesheet" type="text/css" media='print' />
    <!-- Theme style -->
    <link href="dist/css/AdminLTE.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link href="dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- iCheck -->
    <link href="plugins/iCheck/flat/blue.css" rel="stylesheet" type="text/css" />
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

        <!-- Ajax reasons-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  </head>
  <body class="sidebar-collapse">
    <div class="wrapper">
      
      <header class="main-header">
        <a href="../member/index.php" class="logo"><b>Care</b>Rwanda </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              
              
             
              <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <img src="../member/assets/img/users/<?php echo $fetch_account['profile'] ?>" class="user-image" alt="User Image"/>
                  <span class="hidden-xs"><?php echo $fetch_account['user_name'] ?></span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  
              <li>
                <a class="dropdown-item d-flex align-items-center" href="../member/profile.php">
                  <i class="bi bi-person"></i>
                  <span>My Profile</span>
                </a>
              </li>
              <li>
              <hr class="dropdown-divider">
            </li>
              <li>
                <a class="dropdown-item d-flex align-items-center" href="../member/logout.php">
                  <i class="bi bi-person"></i>
                  
                  <span>Sign Out</span>
                </a>
              </li>
           

                </ul>
              </li>
            </ul>
          </div>
        </nav>

        <!-- Logout Disabled Backdrop Modal-->
       <div class="card">
            <div class="card-body">
             <!-- <h5 class="card-title">Disabled Backdrop</h5>
              <p>You can disable the backdrop by adding <code>data-bs-backdrop="false"</code> to <code>.modal-dialog</code></p>-->

              <!-- Disabled Backdrop Modal -->
             <!-- <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#disablebackdrop">
                Launch Modal
              </button>-->
              <div class="modal fade" id="disablebackdrop" tabindex="-1" data-bs-backdrop="false">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">LOG OUT</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                      You are about to Logout your account, Unsaved changes May be lost!
                      <br>
                      <code>Are you Sure you want to End this Session?</code>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-dark" data-bs-dismiss="modal">Cancel</button>
                       <a href="logout.php?lockscreen" class="btn btn-secondary">Lock Instead</a>
                      <a href="logout.php" class="btn btn-primary">Logout</a>
                    </div>
                  </div>
                </div>
              </div><!-- End Disabled Backdrop Modal-->

            </div>
          </div>
          
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      

      <!-- Right side column. Contains the navbar and content of the page -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
        <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="../member/index.php"><i class="fa fa-dashboard"></i> Home</a></li>
          <li class="breadcrumb-item">Cases</li>
          <li class="breadcrumb-item active">Case Details</li>
        </ol>
      </nav>
        <!-- =======================================================  * All Retreives======================================================== -->
        <?php 
                    
                    if(isset($_GET['U08R'])||isset($_POST['U08R'])){
                        if(isset($_POST['U08R'])){
                        $client_id=$_POST['U08R'];
                        }else{
                      $client_id=$_GET['U08R'];
                        }

      //========================================== Select Client/Girls====================================================
                      $sel_client=$con->query("SELECT*from girls where id='$client_id' ")or die($con->error);
                      if($count_client=$sel_client->num_rows>0){  
                        $fetch_client=$sel_client->fetch_assoc();
                        $selected_client=1;
                    }else{
                      $selected_client=0;
                    }

//========================================== Select Cases====================================================
                    $sel_case=$con->query("SELECT*from cases where child_id='$client_id' ")or die($con->error);
                    $count_case=$sel_case->num_rows;
                    if($count_case>0){
                        $fetch_case=$sel_case->fetch_assoc();
                        echo $fetch_case['case_code'];
                        $selected_case=1;
                    }else{
                      $selected_case=0;  
                     // echo $fetch_account['R_district']." None"; 
                    }
                    
                  }else{
                     echo '<div class="callout callout-info">
               <h4><i class="icon fa fa-info"></i>  No Case Selected!</h4>
               <p>
               <hr>
               Go to <a>all cases</a>.</p> </div>
            ';            
                  }?>

  <!-- =======================================================  * End of All Retreives======================================================== -->
          <h1>
            Case
            <small><?php if(isset($selected_client)&&$selected_client==1){ echo $fetch_client['fname']." ".$fetch_client['lname']; } ?></small>
          </h1>
          
          
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-md-3">
            <?php  if(isset($selected_client)&&$selected_client==1){  
              if(isset($selected_case)&&$selected_case==1){
                echo '<a class="btn btn-primary btn-block margin-bottom"   href="case.php?U08R='.$fetch_client["id"].'" >Back To All</a>';
              }else{
                echo '<a class="btn btn-primary btn-block margin-bottom"  href="case.php?U08R='.$fetch_client["id"].'" >Back To All For '.$fetch_client["fname"].'</a>';
              }
              }else{
                echo '<a class="btn btn-primary btn-block margin-bottom"   href="../member/index.php">Back to Dashboard</a>';?>
                <script>
                window.stop();
                </script>
           <?php   } ?>
              
            
         

              <div class="box box-solid">
                <div class="box-body ">
                  <ul class="users-list clearfix">
                    
                      <img src="../member/assets/img/users/<?php echo $fetch_client['image'];?>" width="50%" alt="User Image"/>
                      <a class="users-list-name" href="#"><?php echo $fetch_client['fname']." ".$fetch_client['lname']; ?></a>
                     
                      <?php if($fetch_client['category']=='Critical'){ 
                      echo '<span class="badge btn-danger btn-sm"><i class="bi bi-exclamation-octagon me-1"></i> '.$fetch_client["category"].'</span>';
                    }elseif($fetch_client['category']=='Major'){ 
                      echo '<span class="badge btn-primary btn-sm"><i class="bi bi-exclamation-triangle me-1"></i>  '.$fetch_client["category"].'</span>';
                    }elseif($fetch_client['category']=='Minor'){ 
                      echo '<span class="badge btn-info btn-sm"><i class="bi bi-info-circle me-1"></i> '.$fetch_client["category"].'</span>';
                    }else{ 
                      echo '<span class="badge bg-secondary"><i class="bi bi-collection me-1"></i> '.$fetch_client["category"].'</span>';
                    }
                    ?>
                </div>
                <div class="box-header with-border">
                  <h3 class="box-title">Folders</h3>
                </div>
                <div class="box-body no-padding">
                  <ul class="nav nav-pills nav-stacked">
                    <li ><a href="case.php?U08R=<?php echo $fetch_client["id"]; ?>"><i class="fa fa-inbox"></i> All Events <span class="label label-primary pull-right"><?php echo $count_case; ?></span></a></li>
                    <li class="active"><a href="compose.php?U08R=<?php echo $fetch_client["id"]; ?>"><i class="fa fa-inbox"></i> ADD your Event </a></li>
                    <li><a href="#"><i class="fa fa-envelope-o"></i> Add/Propose an Event on the Case</a></li>
                    <li><a href="#"><i class="fa fa-file-text-o"></i> Drafts</a></li>
                    <li><a href="#"><i class="fa fa-filter"></i> Junk <span class="label label-waring pull-right">65</span></a></li>
                    <li><a href="#"><i class="fa fa-trash-o"></i> Close Case</a></li>
                  </ul>
                </div><!-- /.box-body -->
              </div><!-- /. box -->
              <div class="box box-solid">
                <div class="box-header with-border">
                  <h3 class="box-title">Labels</h3>
                </div>
                <div class="box-body no-padding">
                  <ul class="nav nav-pills nav-stacked">
                    <li><a href="#" class="btn-danger"><i class="fa fa-circle-o text-light-blue"></i> Make Critical</a></li>
                    <li><a href="#" class="btn-warning"><i class="fa fa-circle-o text-light-blue"></i> Make Major</a></li>
                    <li><a href="#" class="btn-info" disabled><i class="fa fa-circle-o text-light-blue"></i> Minor</a></li>
                  </ul>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
            <div class="col-md-9">
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Compose New Message</h3>
                </div><!-- /.box-header -->
                <form name="Event_form" id="event_form" method="post" >
                  <div class="box-body">
                    <div class="form-group">
                      <input class="form-control" placeholder="<?php echo $fetch_client["id"]; ?>" value="<?php echo $fetch_client["id"]; ?>" id="user_id" name="user_id"/>
                    </div>
                    <!-- Select multiple-->
                    <div class="form-group">
                        <label>Choose Type of Event</label>
                        <select  class="form-control" id="event_type" name="event_type" required>
                        <option Value="" selected="" >Choose a Subject</option>
                        <option Value="Raised a Case" >Openning a case</option>
                        <option Value="Added an idea" >Just an Idea</option>
                          <option value="Requested To change Client category">Requesting To change Client category</option>
                          <option value="Updated The case">Updating The case</option>
                          <option value="Updated The case">Adding Necessaly informations</option>
                          <option value="Informed Others">Informing Others</option>
                          
                          
                        </select>
                    </div>
                    <div class="form-group">
                    <label>Describe your Idea</label>
                      <textarea id="" class="form-control" id="event_body" name="event_body" style="height: 100px">
                        Replace this with your Message...e
                       
                        <?php echo($names); ?>
                      </textarea>
                    </div>
                    <div class="form-group">
                      <div class="btn btn-default btn-file">
                        <i class="fa fa-paperclip"></i> Attachment
                        <input type="file" name="attachment" id="event_file" name="event_file" />
                      </div>
                      <p class="help-block">Max. 32MB</p>
                    </div>
                  </div><!-- /.box-body -->
                  <div id="fedback_alert"></div>
                  <div class="box-footer">
                    <div class="pull-right">
                      <button class="btn btn-default"><i class="fa fa-pencil"></i> Draft</button>
                      <button type="submit" name="post" id="post" class="btn btn-primary"><i class="fa fa-envelope-o"></i> Send</button>
                    </div>
                    <button class="btn btn-default" type="reset"><i class="fa fa-times"></i> Discard</button>
                  </div><!-- /.box-footer -->


                  <script>
$(document).ready(function(){

 $('#event_form').on('submit', function(event){
  event.preventDefault();
  if($('#event_type').val() != '' && $('#event_body').val() != '')
  {
   var form_data = $(this).serialize();
   $.ajax({
    url:"submit_event.php",
    method:"POST",
    data:form_data,
    success:function(data)
    {
     $('#event_form')[0].reset();
     $('#fedback_alert').html(data);
    }
   })
  }
  else
  {
   alert("Both Fields (Event Type and Message) are Required");
  }
 });
});
</script>
                  </form> 
              </div><!-- /. box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
       <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>Care</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
     
      Designed by <a href="#">Umwali Ange</a>
    </div>
  </footer><!-- End Footer -->
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.3 -->
    <script src="plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- Slimscroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js" type="text/javascript"></script>
    <!-- iCheck -->
    <script src="plugins/iCheck/icheck.min.js" type="text/javascript"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
    <!-- Page Script -->
    <script>
      $(function () {
        //Add text editor
        $("#compose-textarea").wysihtml5();
      });
    </script>
  </body>
</html>