<?php
session_start();
?>
<?php
if(!isset($_SESSION["p_user"])){
echo("<script>location.href='login.php';</script>");
}elseif (isset($_SESSION["p_user"])&& !isset($_SESSION["access"])){
 echo("<script>location.href='lock.php';</script>");
}
else{

    include('connection.php'); 
$account_key=$_SESSION["p_user"];
$sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['user_name'];
$myemail=$fetch_account['email'];

if($_SESSION["access"]=='Manager'){
    echo("<script>location.href='Manager-index.php';</script>"); 
}

if($fetch_account['first_login']==0){
 echo("<script>location.href='setting.php';</script>");
}

}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Dashboard - Care International Rwanda</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Project Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  
  <!-- Ajax reasons-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
 <!-- =======================================================
  * Project Name: Care International Rwanda
  * Author: Umwali Ange
  * License: +250786193917
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <?php 
$active_admin='dashboard';
$dashboard='user';
include'header.php';?>

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-8">
          <div class="row">

            <!-- Girls Card -->
            <div class="col-xxl-4 col-md-6">
              <div class="card info-card Girls-card">

                <div class="filter">
                  <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
                  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                    <li class="dropdown-header text-start">
                      <h6>Filter</h6>
                    </li>

                    <li><a class="dropdown-item" href="#">Today</a></li>
                    <li><a class="dropdown-item" href="#">This Month</a></li>
                    <li><a class="dropdown-item" href="#">This Year</a></li>
                  </ul>
                </div>

                <div class="card-body">
                  <h5 class="card-title">Girls <span>| From my Village</span></h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-people"></i>
                    </div>
                    <div class="ps-3">
                      <h6><?php echo $count_nearme_cases; ?></h6>
                      <span class="text-muted small pt-2 ps-1"><a href="new_1.php" class="text-primary"><button type="button" class="btn btn-primary rounded-pill"><i class="bi bi-plus"></i>ADD</button></a></span>

                    </div>
                  </div>
                </div>

              </div>
            </div><!-- End Girls Card -->

            <!-- Revenue Card -->
            <div class="col-xxl-4 col-md-6">
              <div class="card info-card revenue-card">

               

                <div class="card-body">
                  <h5 class="card-title">Cases <span>| This Month</span></h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-pin"></i>
                    </div>
                    <div class="ps-3">
                      <h6 id="viewcases">0</h6>
                      <!-- <span class="text-success small pt-1 fw-bold">8%</span> <span class="text-muted small pt-2 ps-1">increase</span> -->

                    </div>
                  </div>
                </div>

              </div>
            </div><!-- End Revenue Card -->

            <!-- Customers Card -->
            <div class="col-xxl-4 col-xl-12">

              <div class="card info-card customers-card">

               

                <div class="card-body">
                  <h5 class="card-title">Locations <span>| My District</span></h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-people"></i>
                    </div>
                    <div class="ps-3">
                      <h6><?php echo $count_mydestinations; ?></h6>
                      <span class="text-danger small pt-1 fw-bold">12%</span> <span class="text-muted small pt-2 ps-1">decrease</span>

                    </div>
                  </div>

                </div>
              </div>

            </div><!-- End Customers Card -->

            

            <!-- Recent Girls -->
            <div class="col-12">
              <div class="card recent-Girls overflow-auto">

                <div class="filter">
                  <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
                  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                    <li class="dropdown-header text-start">
                      <h6>Filter</h6>
                    </li>

                    <li><a class="dropdown-item" href="#">Today</a></li>
                    <li><a class="dropdown-item" href="#">This Month</a></li>
                    <li><a class="dropdown-item" href="#">This Year</a></li>
                  </ul>
                </div>

                <div class="card-body">
                  <h5 class="card-title">Recent Girls <span>| Today</span></h5>

                  <table class="table table-borderless datatable">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Names</th>
                        <th scope="col">Girl Code</th>
                        <th scope="col">Joined On</th>
                        <th scope="col">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php $n=0;
                    while($fetch_members=$sel_nearme_cases->fetch_assoc()){ 
                      $n++; ?>
                      <tr>
                        <th scope="row"><a href="#"><?php echo $n; ?></a></th>
                        <td><?php echo $fetch_members['fname']." ".$fetch_members['lname'];?></td>
                        <td><a href="girls.php?view=<?php echo $fetch_members['girl_unique'] ?>" class="text-primary"><?php echo $fetch_members['girl_unique'] ?></a></td>
                        <td><?php $herday=$fetch_members['join_date'];
                       print date("M d,Y - h:m A",$herday);?></td>
                        <td><?php if($fetch_members['category']=='Critical'){ 
                      echo '<span class="badge bg-danger"><i class="bi bi-exclamation-octagon me-1"></i> '.$fetch_members["category"].'</span>';
                    }elseif($fetch_members['category']=='Major'){ 
                      echo '<span class="badge bg-warning text-dark"><i class="bi bi-exclamation-triangle me-1"></i>  '.$fetch_members["category"].'</span>';
                    }elseif($fetch_members['category']=='Minor'){ 
                      echo '<span class="badge bg-info text-dark"><i class="bi bi-info-circle me-1"></i> '.$fetch_members["category"].'</span>';
                    }else{ 
                      echo '<span class="badge bg-secondary"><i class="bi bi-collection me-1"></i> '.$fetch_members["category"].'</span>';
                    }
                    ?></td>
                      </tr>
                      <?php  } ?>
                     
                      
                    </tbody>
                  </table>

                </div>

              </div>
            </div><!-- End Recent Girls -->

       <!-- News & Updates Traffic -->
       <div class="card col-12">
            

            <div class="card-body pb-0">
              <h5 class="card-title">Cases &amp; Updates <span>| Currently</span></h5>
              <div class="news">
              <?php    
               $sel_nearme_girls=$con->query("SELECT*from girls where supervisor='$account_key' ")or die($con->error);
            if($count_nearme_girls=$sel_nearme_girls->num_rows>0){
              
            
                    while($fetch_mygirls=$sel_nearme_girls->fetch_assoc()){ 
                      $client_id=$fetch_mygirls['id'];
                       //========================================== Select Cases====================================================
                    $sel_case=$con->query("SELECT*from cases where child_id='$client_id' ")or die($con->error);
                    $count_case=$sel_case->num_rows>0;
                        while($fetch_case=$sel_case->fetch_assoc()){
                       
                      ?>

              
                <div class="post-item clearfix">
                  <img src="assets/img/users/<?php echo $fetch_mygirls['image'];?>" alt="">
                  <h4><a href="../report/case.php?U08R=<?php echo $fetch_mygirls['id'];?>" target="_blank"><?php echo $fetch_mygirls['fname'];?> |[ <?php echo $fetch_case['case_code'];?> ] </a></h4>
                  <p><?php echo $fetch_case['event_text'];?></p>
                  <p><?php $evday=$fetch_case['event_time'];
                       print date("h:m A (M d,Y)",$evday);?></p>
                </div>
                      <?php } } ?>
               

               

              
                            <?php } ?>
                            </div><!-- End sidebar recent posts-->
            </div>
          </div><!-- End News & Updates -->

          </div>
        </div><!-- End Left side columns -->

        <!-- Right side columns -->
        <div class="col-lg-4">

          <!-- Recent Activity -->
          <div class="card">
            <div class="filter">
              <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
              <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                <li class="dropdown-header text-start">
                  <h6>Filter</h6>
                </li>

                <li><a class="dropdown-item" href="#">Today</a></li>
                <li><a class="dropdown-item" href="#">This Month</a></li>
                <li><a class="dropdown-item" href="#">This Year</a></li>
              </ul>
            </div>

            <div class="card-body">
              <h5 class="card-title">Recent Activity <span>| Today</span></h5>

              <div class="activity">
              <?php  
        
          $sel_acivities=$con->query("SELECT*from activity ORDER BY id DESC LIMIT 8;")or die($con->error);
        
         
        
        if($count_acivities=$sel_acivities->num_rows>0){

          while($fetch_acivities=$sel_acivities->fetch_assoc()){
            $event_time=$fetch_acivities['event_time'];
        ?>
                <div class="activity-item d-flex">
                  <div class="activite-label">
                  <?php  
 //date_default_timezone_set('America/New_York');  
 //echo facebook_time_ago('2016-03-11 04:58:00');  

      $time_ago = $event_time;  
      $current_time = time();  
      $time_difference = $current_time - $time_ago;  
      $seconds = $time_difference;  
      $minutes      = round($seconds / 60 );           // value 60 is seconds  
      $hours           = round($seconds / 3600);           //value 3600 is 60 minutes * 60 sec  
      $days          = round($seconds / 86400);          //86400 = 24 * 60 * 60;  
      $weeks          = round($seconds / 604800);          // 7*24*60*60;  
      $months          = round($seconds / 2629440);     //((365+365+365+365+366)/5/12)*24*60*60  
      $years          = round($seconds / 31553280);     //(365+365+365+365+366)/5 * 24 * 60 * 60  
      if($seconds <= 60)  
      {  
     echo "Just Now";  
   }  
      else if($minutes <=60)  
      {  
     if($minutes==1)  
           {  
       echo "one minute ago";  
     }  
     else  
           {  
       echo "$minutes minutes ago";  
     }  
   }  
      else if($hours <=24)  
      {  
     if($hours==1)  
           {  
       echo "an hour ago";  
     }  
           else  
           {  
       echo "$hours hrs ago";  
     }  
   }  
      else if($days <= 7)  
      {  
     if($days==1)  
           {  
       echo "yesterday";  
     }  
           else  
           {  
       echo "$days days ago";  
     }  
   }  
      else if($weeks <= 4.3) //4.3 == 52/12  
      {  
     if($weeks==1)  
           {  
       echo "a week ago";  
     }  
           else  
           {  
       echo "$weeks weeks";  
     }  
   }  
       else if($months <=12)  
      {  
     if($months==1)  
           {  
       echo "a month ago";  
     }  
           else  
           {  
       echo "$months months ago";  
     }  
   }  
      else  
      {  
     if($years==1)  
           {  
       echo "one year ago";  
     }  
           else  
           {  
       echo "$years years ago";  
     }  
   }  

 ?> 
                </div>
                <?php if($fetch_acivities['category']=='info'){
                  echo "<i class='bi bi-circle-fill activity-badge text-primary align-self-start'></i>";
                }elseif($fetch_acivities['category']=='Alert'){ 
                 echo "<i class='bi bi-circle-fill activity-badge text-danger align-self-start'></i>";
                }elseif($fetch_acivities['category']=='warning'){ 
                  echo "<i class='bi bi-circle-fill activity-badge text-warning align-self-start'></i>";
                 }elseif($fetch_acivities['category']=='message'){ 
                  echo "<i class='bi bi-circle-fill activity-badge text-success align-self-start' tittle='Message'></i>";
                 }else{
                  echo "<i class='bi bi-circle-fill activity-badge text-muted align-self-start'></i>";
                }
                ?>
                  
                  <div class="activity-content">
                  <?php echo $fetch_acivities['tittle'];?>  <a href="#" class="fw-bold text-dark">More</a> 
                  </div>
                </div><!-- End activity item-->
                <?php } } ?>

               
              </div>

            </div>
          </div><!-- End Recent Activity -->
          <?php  
                    $howmn=$fetch_account['id'];
                    $sel_howmn=$con->query("SELECT*from locations where D_admin='$howmn' ")or die($con->error);
                    $count_howmn=$sel_howmn->num_rows>0;
                       
                        $c=0;
                        
                  ?>
          <!-- News & Updates Traffic -->
          <div class="card">
            <div class="filter">
              <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
              <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                <li class="dropdown-header text-start">
                  <h6>Filter</h6>
                </li>

                <li><a class="dropdown-item" href="#">Today</a></li>
                <li><a class="dropdown-item" href="#">This Month</a></li>
                <li><a class="dropdown-item" href="#">This Year</a></li>
              </ul>
            </div>

            <div class="card-body pb-0">
              <h5 class="card-title">MY Locations <span>| <?php echo $count_howmn."District"; ?></span></h5>

              <!-- Primary Color Bordered Table -->
              <table class="table table-bordered border-primary">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Place</th>
                    <th scope="col">Children</th>
                   
                  </tr>
                </thead>
                <tbody>
                  <?php while($fetch_howmn=$sel_howmn->fetch_assoc()){ 
                    $c++;
                    $branch_id=$fetch_howmn['id'];
                    ?>
                  <tr>
                    <th scope="row"><?php echo $c; ?></th>
                    <td><?php echo $fetch_howmn['District']; ?></td>
                   
                    <td><?php $sel_girls=$con->query("SELECT*from girls where district='$branch_id' ")or die($con->error); 
                        $count_girls=$sel_girls->num_rows; 
                      if($count_girls>0){
                       
                       echo $count_girls." Girl(s)";
                      }else{
                        echo $count_girls."(None)";
                      } ?></td>
                    
                  </tr>
                  <?php } ?>
                  
                
                </tbody>
              </table>
              <!-- End Primary Color Bordered Table --><!-- End sidebar recent posts-->

            </div>
          </div><!-- End News & Updates -->


          <!-- Website Traffic -->
          <div class="card">
            <div class="filter">
              <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
              <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                <li class="dropdown-header text-start">
                  <h6>Filter</h6>
                </li>

                <li><a class="dropdown-item" href="#">Today</a></li>
                <li><a class="dropdown-item" href="#">This Month</a></li>
                <li><a class="dropdown-item" href="#">This Year</a></li>
              </ul>
            </div>

            <div class="card-body pb-0">
              <h5 class="card-title">Website Traffic <span>| Today</span></h5>

              <div id="trafficChart" style="min-height: 400px;" class="echart"></div>

              <script>
                document.addEventListener("DOMContentLoaded", () => {
                  echarts.init(document.querySelector("#trafficChart")).setOption({
                    tooltip: {
                      trigger: 'item'
                    },
                    legend: {
                      top: '5%',
                      left: 'center'
                    },
                    series: [{
                      name: 'Access From',
                      type: 'pie',
                      radius: ['40%', '70%'],
                      avoidLabelOverlap: false,
                      label: {
                        show: false,
                        position: 'center'
                      },
                      emphasis: {
                        label: {
                          show: true,
                          fontSize: '18',
                          fontWeight: 'bold'
                        }
                      },
                      labelLine: {
                        show: false
                      },
                      data: [{
                          value: 1048,
                          name: 'Search Engine'
                        },
                        {
                          value: 735,
                          name: 'Direct'
                        },
                        {
                          value: 580,
                          name: 'Email'
                        },
                        {
                          value: 484,
                          name: 'Union Ads'
                        },
                        {
                          value: 300,
                          name: 'Video Ads'
                        }
                      ]
                    }]
                  });
                });
              </script>

            </div>
          </div><!-- End Website Traffic -->



        </div><!-- End Right side columns -->

      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>Care</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
     
      Designed by <a href="#">Umwali Ange</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.min.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Project Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>