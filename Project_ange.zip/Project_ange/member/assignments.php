<?php
session_start();
?>
<?php
if(!isset($_SESSION["p_user"])){
echo("<script>location.href='login.php';</script>");
}elseif (isset($_SESSION["p_user"])&& !isset($_SESSION["access"])){
 echo("<script>location.href='lock.php';</script>");
}
else{

    include('connection.php'); 
$account_key=$_SESSION["p_user"];
$sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['user_name'];
$myemail=$fetch_account['email'];


//assignments.php
if(isset($_POST["alocation"]))
{
   
 $location = mysqli_real_escape_string($con, $_POST["alocation"]);
 $user= mysqli_real_escape_string($con, $_POST["auser"]);
 $now=time();
//echo $user." Is assigned To". $location;

$sel_locations=$con->query("SELECT*from locations where id='$location' ")or die($con->error); 
if($count_locations=$sel_locations->num_rows>0){
    $fetch_locations=$sel_locations->fetch_assoc(); 
    $branch_name=$fetch_locations['District'];
    $sel_luser=$con->query("SELECT*from users where id='$user' ")or die($con->error);
    if($count_luser=$sel_luser->num_rows>0){
    $fetch_luser=$sel_luser->fetch_assoc();
    $user_name=$fetch_luser['user_name'];
    if($fetch_luser['R_district']=='0'){
        $changeR_district=$con->query("UPDATE users SET R_district='$location' WHERE id='$user' ")or die($con-error);
            if($changeR_district){
                echo '<div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show" role="alert">
                '.$user_name.' IS Made a Responsible For'.$branch_name.'!
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>';
              $saveactivity=$con->query("INSERT INTO activity(activity_by,tittle,category,information,msgto,event_time) VALUES ('$account_key','You have Given A BRANCH tO Manage','message','Hello: $user_name. You are now Responsibly to .$branch_name. branch of Care Rwanda','$user','$now')")or die($con->error);
            }
    }
    $changedistrict=$con->query("UPDATE locations SET D_admin='$user' WHERE id='$location' ")or die($con-error);
    $saveactivity=$con->query("INSERT INTO activity(activity_by,tittle,category,information,event_time) VALUES ('$account_key','$user_name Rules .$branch_name. Branch Now','info','Care Rwanda, .$branch_name. Branch is Now is Managed By : $user. if you may call him/her on any information','$now')")or die($con->error);
    echo '<div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show" role="alert">
    '.$user_name.' IS assigned To  '.$branch_name.'!
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>';
}
    
}else{
    echo '<div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show" role="alert">
    A simple danger alert with solid color—check it out!
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
}
//Danger message

// $changequery=$con->query("UPDATE girls SET image='$imagename' WHERE girl_unique ='$now_member' ")or die($con->error);
   
//  $query = " INSERT INTO comments(comment_subject, comment_text) VALUES ('$subject', '$comment')
//  ";
//  mysqli_query($connect, $query);
}

}


?>