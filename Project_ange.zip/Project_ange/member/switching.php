<?php
session_start();

require_once('connection.php');
if(isset($_SESSION["access"])){
	if(isset($_GET['view'])&&($_GET['view']=='user')){
		$_SESSION["access"]='user';
		
		//$query=$con->query("UPDATE users SET status='Offline' WHERE id ='".$_SESSION["p_user"]."' ")or die($con->error);
		echo("<script>location.href='index.php';</script>");

	}elseif (isset($_GET['view'])&&($_GET['view']=='Manager')) {
        $_SESSION["access"]='Manager';
		
		//$query=$con->query("UPDATE users SET status='Offline' WHERE id ='".$_SESSION["p_user"]."' ")or die($con->error);
		echo("<script>location.href='manager-index.php';</script>");
    }
    else{

        echo('<script>alert("Sorry Denied!")</script>');
	 echo("<script>location.back';</script>");
	}
	}else{
		echo("<script>location.href='login.php';</script>");
	}
?>