<?php
session_start();
?>
<?php
if(!isset($_SESSION["p_user"])){
echo("<script>location.href='login.php';</script>");
}elseif (isset($_SESSION["p_user"])&& !isset($_SESSION["access"])){
 echo("<script>location.href='lock.php';</script>");
}
else{
    include('connection.php'); 
$account_key=$_SESSION["p_user"];
$sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['user_name'];
$myemail=$fetch_account['email'];

$today=date(" M d, Y");
$time=date("h:i a");
}
    ?>
<?PHP
if(isset($_POST['changing_profile'])){

 if(empty($_POST['about']) ||empty($_POST['fullName']) ||empty($_POST['account_type'])){
     $info="Please Fill All the Blanks to Update, Every box must contain details";
   }else{
     $about = $_POST['about'];
     $about=str_replace("'", "\'",   $about);
  $fullName=$_POST['fullName'];
  $fullName=str_replace("'", "\'",   $fullName);
  $account_type=$_POST['account_type'];
  $account_type=str_replace("'", "\'",   $account_type);
     $contact = $_POST['contact'];
  $newemail=$_POST['email'];
  $account_type=$_POST['account_type'];
  $country=$_POST['country'];
  $image=$_POST['imagename'];

   $changequery=$con->query("UPDATE users SET account_type='$account_type',contacts='$contact',profile='$image',country='$country',about='$about',email='$newemail' WHERE id ='$account_key' ")or die($con->error);
      if ($changequery) {
       $approvo="Your account is UPDATE now!<br> <a href='profile.php' class='btn btn-primary ms-auto'>Click here</a> to See updates";
 

             //echo("<script>location.href='index.php?load&user=".$names."';</script>"); 
          }    
   }

}

if(isset($_POST['update_pass']))
{

 
  

  if(empty($_POST['old']) ||empty($_POST['newp']) ||empty($_POST['renew']))

  {
    //echo("<div class='error_message btn-primary text-center'>Please Fill in the Blanks.</div><br/>"); 
      $info="Please Fill in the Blanks to change password";
    
  }
  else{
 $new = $_POST['newp'];
  $renew=$_POST['renew'];
  $old=$_POST['old'];
     $pass = md5($_POST['old']);

    $query="select * from  users  where id='".$account_key."' and password='".$pass."' ";
    $result=mysqli_query($con,$query);
    if(mysqli_fetch_assoc($result))
    {
//$view_p=$con->query("SELECT * from users where  password='$pass' and  user_name='$username' or password='$pass' and email='$username'")or die("Connection failed: " . $con->connect_error);
     // $view=$view_p->fetch_assoc();
      //$id=$view['store_No'];
      // $_SESSION["p_user"] = $view['id'];
      // $_SESSION["access"] = 'yes';

//       if($view['type']=='Owner'){
//       $_SESSION["users"] =$view['user_name'];    
// }
      if($new!=$renew){
         $info="New password was not confirmed <br> please choose the password you can remember!";
      }elseif ($old==$new) {
        $info='New password Can not be the same as previous!<br> Choose any other keyword Please.</span>';
      }else{
          $security=md5($new);
 $changequery=$con->query("UPDATE users SET password='$security',first_login='1' WHERE id ='$account_key' ")or die($con->error);
      if ($changequery) {
       $approvo="New password Setted!<br> Loading Dashboard...";
             //echo("<script>location.href='index.php?load&user=".$names."';</script>"); 
          }    
      
    } }
    else{
 //echo("<div class='error_message btn-danger text-center'>Invalid!<br> Enter Correct User name/email OR Password.</div><br/>");

$alert="Old Password was Invalid!<br> Enter Correct Password.";
    }
  }


// else{
// echo("<div class='error_message text-center'>login.</div><br/>");
// }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Users / Profile - Gender Justice for women and girls analytic and  management System</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../images/logo.png" rel="icon">
  <link href="../images/logo.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Image Crop upload -->

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Care International Rwanda
  * Author: Umwali Ange
  * License: +250786193917
  ======================================================== -->
  <style>
      .hidding{display:none;}
     </style>
  <!-- Ajax reasons-->
  <script src="assets/js/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.css" />
</head>

<body>

  <!-- ======= Header ======= -->
 <?php 
$active_admin='profile';
include'header.php';?>

 

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Profile</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item">Users</li>
          <li class="breadcrumb-item active">Profile</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
    <?php if(isset($_GET['welcome'])){ ?>
                   <div class="alert alert-warning bg-primary text-light border-0 alert-dismissible fade show" role="alert">
                 <STRONG>Welcome</STRONG>, to Gender Justice for women and girls analytic and management System <br>Start to <a class="text-warning" href="index.php">Dashboard</a>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
                  <?php } ?>
    <section class="section profile">
      <div class="row">
        <div class="col-xl-4">

          <div class="card">
            <div class="card-body profile-card pt-4 d-flex flex-column align-items-center">

              <img src="assets/img/users/<?php echo $fetch_account['profile'] ?>" alt="Profile" class="rounded-circle">
              <h2><?php echo $fetch_account['user_name'] ?></h2>
              <h3><?php echo $fetch_account['account_type'] ?></h3>
              <div class="social-links mt-2">
                <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
                <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
                <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
                <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
              </div>

            <!--Crop image modal-->
                <div id="uploadimageModal" class="modal" role="dialog">
 <div class="modal-dialog">
  <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">×</button>
          <h4 class="modal-title">Upload & Crop Image</h4>
        </div>
        <div class="modal-body">
          <div class="row">
       <div class="col-md-8 text-center">
        <div id="image_demo" style="width:350px; margin-top:30px"></div>
       </div>
       
    </div>
        </div>
        <div class="modal-footer">
           <button class="btn btn-success crop_image">Crop & Upload Image</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
     </div>
    </div>
</div>
                <!---End Crop image modal----->


            </div>
          </div>
          <div id="msg"></div>
        </div>

        <div class="col-xl-8">
    <?php if(isset($alert)){ ?>
    <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show" role="alert">
                <?php echo $alert; ?>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
                  <?php } ?>
                  <?php if(isset($info)){ ?>
    <div class="alert alert-info bg-info text-light border-0 alert-dismissible fade show" role="alert">
                <?php echo $info; ?>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
                  <?php } ?>

<?php if(isset($approvo)){ ?>
                   <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show" role="alert">
                 <?php echo $approvo; ?>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
                  <?php } ?>
                 
          <div class="card">
            <div class="card-body pt-3">
              <!-- Bordered Tabs -->
              <ul class="nav nav-tabs nav-tabs-bordered">

                <li class="nav-item">
                  <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#profile-overview">Overview</button>
                </li>

                <li class="nav-item">
                  <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-edit">Edit Profile</button>
                </li>

                <li class="nav-item">
                  <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-settings">Settings</button>
                </li>

                <li class="nav-item">
                  <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-change-password">Change Password</button>
                </li>

              </ul>
              <div class="tab-content pt-2">

                <div class="tab-pane fade show active profile-overview" id="profile-overview">
                  <h5 class="card-title">About</h5>
                  <p class="small fst-italic"><?php echo $fetch_account['about'] ?></p>

                  <h5 class="card-title">Profile Details</h5>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label ">Full Name</div>
                    <div class="col-lg-9 col-md-8"><?php echo $fetch_account['fname'] ?> <?php echo $fetch_account['lname'] ?></div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label ">User Name</div>
                    <div class="col-lg-9 col-md-8"><?php echo $fetch_account['user_name'] ?></div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label">Join</div>
                    <div class="col-lg-9 col-md-8"><?php 
                    $nowtime=$fetch_account['Join_date'];
                    print date("D - M d,Y ",$nowtime);?></div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label">account_type</div>
                    <div class="col-lg-9 col-md-8"><?php echo $fetch_account['account_type'] ?></div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label">Country</div>
                    <div class="col-lg-9 col-md-8"><?php echo $fetch_account['country'] ?></div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label">Responsible District</div>
                    <div class="col-lg-9 col-md-8"><?php 
                    $loc=$fetch_account['R_district'];
                    $sel_loc=$con->query("SELECT*from locations where id='$loc' ")or die($con->error);
                    if($count_loc=$sel_loc->num_rows>0){
                        $fetch_loc=$sel_loc->fetch_assoc();
                        echo $fetch_loc['District'];
                    }else{
     echo $fetch_account['R_district']." None"; 
                    }?></div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label">Phone</div>
                    <div class="col-lg-9 col-md-8"><?php echo $fetch_account['contacts'] ?></div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label">Email</div>
                    <div class="col-lg-9 col-md-8"><?php echo $fetch_account['email'] ?></div>
                  </div>

                </div>

                <div class="tab-pane fade profile-edit pt-3" id="profile-edit">

                  <!-- Profile Edit Form -->
                  <form  action="" id="update_account" name="update_account" method="post">
                    <div class="row mb-3">
                      <label for="profileImage" class="col-md-4 col-lg-3 col-form-label">Profile Image</label>
                      <div class="col-md-8 col-lg-9">
                        <img src="assets/img/users/<?php echo $fetch_account['profile'] ?>" alt="Profile">
                        <div class="pt-2">
                          <a href="#" class="btn btn-primary btn-sm" title="Upload new profile image" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne"><i class="bi bi-upload"></i></a>
                          <a href="#" class="btn btn-danger btn-sm" title="Remove my profile image"><i class="bi bi-trash"></i></a>
                        </div>
                        </div>
                            </div>
                               <!-- Accordion without outline borders -->
              <div class="accordion accordion-flush" id="accordionFlushExample">
                <div class="accordion-item">
                  
                  <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                  <div class="row mb-3">
                      <label for="upload_image" class="col-md-4 col-lg-3 col-form-label">Select Profile Image</label>
                      <div class="col-md-8 col-lg-9" align="center">
                      <input type="file" name="upload_image" class="form-control" id="upload_image" value="<?php echo $fetch_account['profile'] ?>" accept="image/*" />
                      <br />
                      <div id="uploaded_image"><input type="hidden" class="form-control" value="<?php echo $fetch_account['profile'] ?>"   name="imagename"  ></div>
                      </div>
                    </div>
                  </div>
                </div>
                
 
                      </div><!-- End Accordion without outline borders -->
                    

   
            
              
                    <div class="row mb-3">
                      <label for="fullName" class="col-md-4 col-lg-3 col-form-label">Full Name</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="fullName" type="text" class="form-control" id="fullName" value="<?php echo $fetch_account['user_name'] ?>">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="about" class="col-md-4 col-lg-3 col-form-label">About</label>
                      <div class="col-md-8 col-lg-9">
                        <textarea name="about" class="form-control" id="about" style="height: 100px"><?php echo $fetch_account['about'] ?></textarea>
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="company" class="col-md-4 col-lg-3 col-form-label">Account Type</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="account_type" type="text"  class="form-control" id="company" value="<?php echo $fetch_account['account_type'] ?>">
                      </div>
                    </div>

                    

                    <div class="row mb-3">
                      <label for="Country" class="col-md-4 col-lg-3 col-form-label">Country</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="country" type="text" class="form-control" id="Country" value="<?php echo $fetch_account['country'] ?>">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="Address" class="col-md-4 col-lg-3 col-form-label">Address</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="address" type="text" class="form-control" id="Address" value="A108 Adam Street, New York, NY 535022">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="Phone" class="col-md-4 col-lg-3 col-form-label">Phone</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="contact" type="text" class="form-control" id="Phone" value="<?php echo $fetch_account['contacts'] ?>">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="Email" class="col-md-4 col-lg-3 col-form-label">Email</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="email" type="email" class="form-control" id="Email" value="<?php echo $fetch_account['email'] ?>">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="Twitter" class="col-md-4 col-lg-3 col-form-label">Twitter Profile</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="twitter" type="text" class="form-control" id="Twitter" value="https://twitter.com/#">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="Facebook" class="col-md-4 col-lg-3 col-form-label">Facebook Profile</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="facebook" type="text" class="form-control" id="Facebook" value="https://facebook.com/#">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="Instagram" class="col-md-4 col-lg-3 col-form-label">Instagram Profile</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="instagram" type="text" class="form-control" id="Instagram" value="https://instagram.com/#">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="Linkedin" class="col-md-4 col-lg-3 col-form-label">Linkedin Profile</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="linkedin" type="text" class="form-control" id="Linkedin" value="https://linkedin.com/#">
                      </div>
                    </div>

                    <div class="text-center">

<button class="btn btn-primary hidding" id="updateloader" type="button" disabled>
<span class="spinner-grow spinner-grow-sm" role="status" aria-hidden="true"></span>
Loading...
</button>

  <button type="submit" id="submit_update_btn" class="btn btn-primary">Save Changes</button>
</div>
</form><!-- End Profile Edit Form -->

                </div>

                <div class="tab-pane fade pt-3" id="profile-settings">

                  <!-- Settings Form -->
                  <form>

                    <div class="row mb-3">
                      <label for="fullName" class="col-md-4 col-lg-3 col-form-label">Email Notifications</label>
                      <div class="col-md-8 col-lg-9">
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" id="changesMade" checked>
                          <label class="form-check-label" for="changesMade">
                            Changes made to your account
                          </label>
                        </div>
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" id="newProducts" checked>
                          <label class="form-check-label" for="newProducts">
                            Information on new products and services
                          </label>
                        </div>
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" id="proOffers">
                          <label class="form-check-label" for="proOffers">
                            Marketing and promo offers
                          </label>
                        </div>
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" id="securityNotify" checked disabled>
                          <label class="form-check-label" for="securityNotify">
                            Security alerts
                          </label>
                        </div>
                      </div>
                    </div>

                    <div class="text-center">
                      <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                  </form><!-- End settings Form -->

                </div>

                <div class="tab-pane fade pt-3" id="profile-change-password">
                  <!-- Change Password Form -->
                  <form action="" method="post">

                    <div class="row mb-3">
                      <label for="currentPassword" class="col-md-4 col-lg-3 col-form-label">Current Password</label>
                      <div class="col-md-8 col-lg-9">
                         <input type="password" name="old" class="form-control" id="yourPassword1" required>
                        <div class="valid-feedback">
                    Looks good!
                  </div>
                      </div>
                    </div>

              

                    <div class="row mb-3 position-relative">
                      <label for="newPassword" class="col-md-4 col-lg-3 col-form-label">New Password</label>
                      <div class="col-md-8 col-lg-9">
                        <input type="password" name="newp" class="form-control" id="yourPassword2" required>
                        
                  <div class="valid-tooltip">
                    Looks good!
                  </div>
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="renewPassword" class="col-md-4 col-lg-3 col-form-label">Re-enter New Password</label>
                      <div class="col-md-8 col-lg-9">
                       <input type="password"  name="renew" class="form-control" id="yourPassword3" required>
                      </div>
                    </div>

                    <div class="col-12 text-center">
                      <div class="form-check">
                        
                        <label class="form-check-label" for="acceptTerms">Show Password 
                          <input class="form-check-input" name="terms" type="checkbox"  onclick="myFunction()">
                      </div>
                    </div>

                   

                                   <script>
function myFunction() {
  var x = document.getElementById("yourPassword1");
  var y = document.getElementById("yourPassword2");
  var z = document.getElementById("yourPassword3");
  if (x.type === "password" || y.type === "password") {
    x.type = "text";
    y.type = "text";
    z.type = "text";
  } else {
    x.type = "password";
     y.type = "password";
      z.type = "password";
  }
}
</script>

                    <div class="text-center">
                      <button type="submit" name="update_pass" class="btn btn-primary">Change Password</button>
                    </div>
                  </form><!-- End Change Password Form -->
 
                </div>

              </div><!-- End Bordered Tabs -->

            </div>
          </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>Care International Rwanda</span></strong>. All Rights Reserved
    </div>
    <div class="credits">

      Designed by <a href="#">Umwali Ange</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.min.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>


<script>          $(document).ready(function(){
        
        $('#new_user').on('submit', function(event){
         event.preventDefault();
         if($('#yourEmail').val() != '' && $('#yourPassword').val() != '')
         {
          var form_data = $(this).serialize();
          $.ajax({
           url:"accounts.php",
           method:"POST",
            data:form_data,
              beforeSend:function(){
                $('#nuserloader').removeClass("hidding");
                $('#submit_nuser_btn').prop("disabled",true);
                $('#submit_nuser_btn').addClass("hidding");
                $('#nuserloader').prop("hidden",false);
                                                             
                                                           },
           
           success:function(data)
           {
            //$('#assign_form')[0].reset();
            $('#msg').html(data);
            $('#nuserloader').addClass("hidding");
            $('#submit_nuser_btn').removeClass("hidding");
                $('#submit_nuser_btn').prop("disabled",false);
                $('#nuserloader').prop("hidden",true);
           }
          })
         }
         else
         {
          alert("Both Fields are Required");
         }
        });

        $('#changepassword').on('submit', function(event){
         event.preventDefault();
         if($('#newPassword').val() != '' && $('#renewPassword').val() != '')
         {
          var form_data = $(this).serialize();
          $.ajax({
           url:"accounts.php",
           method:"POST",
            data:form_data,
              beforeSend:function(){
                $('#changeloader').removeClass("hidding");
                $('#submit_change_btn').prop("disabled",true);
                $('#submit_change_btn').addClass("hidding");
                $('#nuserloader').prop("hidden",false);
                },
           success:function(data)
           {
            //$('#assign_form')[0].reset();
            $('#msgpass').html(data);
            $('#changeloader').addClass("hidding");
            $('#submit_change_btn').removeClass("hidding");
                $('#submit_change_btn').prop("disabled",false);
                $('#changeloader').prop("hidden",true);
           }
          })
         }
         else
         {
          alert("Confirm New Password Please!");
         }
        });
//update scripts====================
$('#update_account').on('submit', function(event){
         event.preventDefault();
         if($('#fullname').val() != '' && $('#Job').val() != '')
         {
          var form_data = $(this).serialize();
          $.ajax({
           url:"accounts.php",
           method:"POST",
            data:form_data,
              beforeSend:function(){
                $('#updateloader').removeClass("hidding");
                $('#submit_update_btn').prop("disabled",true);
                $('#submit_update_btn').addClass("hidding");
                $('#updateloader').prop("hidden",false);
                                                             
                                                           },
           
           success:function(data)
           {
            //$('#assign_form')[0].reset();
            $('#msg').html(data);
            $('#updateloader').addClass("hidding");
            $('#submit_update_btn').removeClass("hidding");
                $('#submit_update_btn').prop("disabled",false);
                $('#updateloader').prop("hidden",true);
           }
          })
         }
         else
         {
          alert("Both Fields are Required");
         }
        });
 
 $image_crop = $('#image_demo').croppie({
    enableExif: true,
    viewport: {
      width:300,
      height:260,
      type:'rectangle' //circle
    },
    boundary:{
      width:420,
      height:400
    }
  });
 
  $('#upload_image').on('change', function(){
    var reader = new FileReader();
    reader.onload = function (event) {
      $image_crop.croppie('bind', {
        url: event.target.result
      }).then(function(){
        console.log('jQuery bind complete');
      });
    }
    reader.readAsDataURL(this.files[0]);
    $('#uploadimageModal').modal('show');
  });
 
  $('.crop_image').click(function(event){
    $image_crop.croppie('result', {
      type: 'canvas',
      size: 'viewport'
    }).then(function(response){
      $.ajax({
        url:"upload.php",
        type: "POST",
        data:{"image": response},
        success:function(data)
        {
          $('#uploadimageModal').modal('hide');
          $('#uploaded_image').html(data);
        }
      });
    })
  });
 
});  
</script>    
</body>

</html>