<?php
session_start();
?>
<?php
if(!isset($_SESSION["p_user"])){
echo("<script>location.href='login.php';</script>");
}elseif (isset($_SESSION["p_user"])&& !isset($_SESSION["access"])){
 echo("<script>location.href='lock.php';</script>");
}
else{
    include('connection.php'); 
$account_key=$_SESSION["p_user"];
$sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['user_name'];
$myemail=$fetch_account['email'];

$todayyear=date("Y");
$today=date(" M d, Y");
$time=date("h:i a");
}
    ?>

<?PHP


if(isset($_POST['new_name'])){

  if(empty($_POST['UniqueName']) ||empty($_POST['lname']) ||empty($_POST['UserId'])){
      $info="Please Fill All Important information the Blanks,<br> Every box must contain Relevant details";
    }
      $Username= $_POST['new_name'];
      $Username=str_replace("'", "\'",   $Username);
      // $nemail= $_POST['UserId'];
      $Job= $_POST['Job'];
      $Job=str_replace("'", "\'",   $Job);

      $nemail= $_POST['nemail'];
      $nemail=str_replace("'", "\'",   $nemail);

      $ulocation= $_POST['ulocation'];
      $ulocation=str_replace("'", "\'",   $ulocation);

      $Dpass= $_POST['npassword'];
      $security=md5($Dpass);

      if(isset($_POST['admin'])){
        $ctype='Admin';
      }else{
        $ctype='User';
      }

      $now=time();

      $sel_availables=$con->query("SELECT*from users where user_name='$Username' or email='$nemail' ")or die($con->error);
      if($count_availables=$sel_availables->num_rows>0){
       $alert="A Username ' ".$Username." ' Is taken <br>Choose a different name as User names should be Unique!";
       echo '   <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show" role="alert">
       A Username '.$Username.' Is taken <br>Choose a different name as User names should be Unique!
       <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
     </div>';
      }

      if (!filter_var($nemail, FILTER_VALIDATE_EMAIL)) {
        $alert = "Invalid email format Try Again";
        
      echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <i class="bi bi-exclamation-octagon me-1"></i>
      Invalid Email ID,
      <h4>	<i class="icon fa fa-times"></i> '.$nemail.' !</h4>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
      }
      elseif(filter_var($nemail, FILTER_VALIDATE_EMAIL)){
  
        $sel_availables=$con->query("SELECT*from users where email='$nemail' ")or die($con->error);
        if($count_availables=$sel_availables->num_rows>0){
         $alert="A User ID ' ".$nemail." ' Is taken <br>Choose a different name as User names should be Unique!";
         echo '   <div class="alert alert-info bg-info text-dark border-0 alert-dismissible fade show" role="alert">
         A UserID '.$nemail.' are being used in System Already <br>User can not have two different Accounts on One Email Id!
         <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
       </div>';
        }
    }
      if(!isset($alert)){
          $savequery=$con->query("INSERT INTO users(user_name,full_names,email,location,passwords,account_type,join_date,Job) VALUES ('$Username','$Username','$nemail','$ulocation','$security','$ctype','$now','$Job')")or die($con->error);
          if ($savequery){
              $approvo="New Member is added in System Please complete all related info!<br> ";

              $last=$con->query("SELECT * FROM users WHERE id=(SELECT max(id) FROM users) ")or die($con->error);
              $fetch_last=$last->fetch_assoc();
              $last_id=$fetch_last['id'];
              $msg='Hello '.$Username.', Greatings from R Nation we are happy to have You Joined the community <br> You have been tasked to be '.$Job.'<p> Welcome!</p>';
              $saveactivity=$con->query("INSERT INTO messages(msg_time,msg_user,msg_side,msg_type,msg_read,msg) VALUES ('$now','$last_id','Admin','Alert','0','$msg')")or die($con->error);
              $url= "www.admin.thernation.com";

                    echo '<div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show" role="alert">
                    New account for '.$Username.' has been registred Successful!
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
                    <script>$("#new_user")[0].reset();</script> 
                  </div>';
        $to =$nemail;
        $subject = 'New Member is initiated in R Nation Ent.';
        $message= '<p style="color:#4c5a7d"> Hello '.$Username.' , </p>';
        $message .= '<p>This is to inform that  </p>';
        $message .= '<p>New account is Created, Use the Below Credentials to Log in Your Account: </p>';
        $message .= '<p> User Name:'.$Username.'</p>';
        $message .= '<p> Email/ID: '.$nemail.'</p>';
        $message .= '<p> Default Password: <b>'.$Dpass.'</b><br><small> Note that you will be Required to update this Right on the Loggin</small></p>';

        $message .= '<p>You can Use this link/Button to </br>';

$message .= '<a href="'.$url.'"><button name="Login" class="btn btn-info ">Login</button></a></p>';
$message .= '<p> if the Button appears to marfunction copy this url <b>https://www.admin.thernation.com</b> into your browser </p>';
        
        if(isset($alert)){
          $message .= '<p> Belows are Some Errors Occured:</p>';
        $message .= '<p> Errors:'.$alert.'</p>';
        }else{
          $message .= '<p> Thank you!</p>';
        }
        $message .= '<p> ------------------------------------------------------------------------------</p>';
        $message .= '<p>  If this was you, you don’t need to do anything. If not, we’ll help you secure your account. call Us now
         <a href="tel:+250784624822"> (+250) 784 624 822 </a> or just Reply to <b>info@admin.thernation.com</b>!</p>';
         $message .= '<p> *******************************************************************************</p>';
         $message .='<p>"CONFIDENTIALITY NOTICE This e-mail message and any attachments are only for the use of the intended recipient and may contain information that is privileged, confidential or exempt from disclosure under applicable law. If you are not the intended recipient, any disclosure, distribution or other use of this e-mail message or attachments is prohibited. If you have received this e-mail message in error, please delete and notify the sender immediately. Thank you."</p>';
         $message .= '<p> *******************************************************************************</p>';
         $headers = "From: R Nation Ent. Your User Account <no-reply@thernation.com>\r\n";
         $headers .= "Reply-To: info@admin.thernation.com\r\n";
         
         $headers .= "Content-type: text/html\r\n";
        
        $send=mail($to, $subject, $message, $headers);
        
        if($send){
          $approvo .="New Member is added in System Please complete all related info!<br> ";
          echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
          <i class="bi bi-check-circle me-1"></i>
          Information Mail has been Sent to '.$nemail.' including his cridentials
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
        }else{
          $info="Email sending failed!";
          echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
          <i class="bi bi-exclamation-triangle me-1"></i>
          Information Mail was not able to be sent!! Please contact '.$Username.' and Ask him/her to login using:
            <p> User Name:'.$Username.'</p>
        <p> Email/ID: '.$nemail.'</p> 
        <p> Default Password: <b>'.$Dpass.'</b><small> Note that He will be Required to update this Right on the Loggin</small></p>

          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
        }
              
                 } 
        }
  }
  elseif(isset($_POST['fullName'])){

    if(empty($_POST['about']) ||empty($_POST['fullName'])){
        $info="Please Fill All the Blanks to Update, Every box must contain details";
        echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-octagon me-1"></i>
        Something Missing,
        <h4>	<i class="icon fa fa-times"></i> '.$info.' !</h4>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
      }else{
        $about = $_POST['about'];
        $about=str_replace("'", "\'",   $about);
     $fullName=$_POST['fullName'];
     $fullName=str_replace("'", "\'",   $fullName);
     $account_type=$_POST['account_type'];
     $account_type=str_replace("'", "\'",   $account_type);
        $contact = $_POST['contact'];
     $nemail=$_POST['email'];
     $account_type=$_POST['account_type'];
     $country=$_POST['country'];
     $image=$_POST['imagename'];

     if (!filter_var($nemail, FILTER_VALIDATE_EMAIL)) {
        $alert = "Invalid email format Try Again";
        
      echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <i class="bi bi-exclamation-octagon me-1"></i>
      Invalid Email ID,
      <h4>	<i class="icon fa fa-times"></i> '.$nemail.' !</h4>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
      }

      if(!isset($alert)){
      $changequery=$con->query("UPDATE users SET contacts='$contact',profile='$image',country='$country',about='$about',email='$nemail' WHERE id ='$account_key' ")or die($con->error);
 if ($changequery){
      $approvo="Changes Have been made to your account successfully!";
      echo("<script>location.href='profile.php?info=".$approvo."';</script>"); 
    }else{
      $alert="There's been an Error!";
    }
  }

      }

  }elseif(isset($_POST['old']))
  {
  
   
    
  
    if(empty($_POST['old']) ||empty($_POST['newp']) ||empty($_POST['renew']))
  
    {
        $alert="Please Fill in the Blanks.";
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-octagon me-1"></i>
        <h4>	<i class="icon fa fa-times"></i> '.$alert.' !</h4>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
      
    }
    else{
   $new = $_POST['newp'];
    $renew=$_POST['renew'];
    $old=$_POST['old'];
    $security = md5($_POST['old']);
  
      $query="select * from  users  where id='".$account_key."' and passwords='".$pass."' ";
      $result=mysqli_query($con,$query);
      if(mysqli_fetch_assoc($result))
      {

        if($new!=$renew){
           echo("<p class='border-info border-1 text-center text-primary'>New password was not confirmed <br> Please choose the password you can remember.</p>");
         ?><script> $('#yourPassword3').addClass("is-invalid");</script><?php
         
        }elseif ($old==$new) {
           echo("<p class='border-info border-1 text-center text-success'>New password Can not be the same as previous!<br> Choose any other keyword Please.</p>");
        }else{
            $security=md5($new);
   $changequery=$con->query("UPDATE users SET passwords='$security',first_login='1' WHERE id ='$account_key' ")or die($con->error);
        if ($changequery) {
          echo("<p class=' border-success text-center border-1 text-success'>New password Setted!<br> Loading Dashboard...</p>");
          if(isset($_SESSION['p_attempt'])){
              unset($_SESSION['p_attempt']);
          }
          $url= "www.admin.thernation.com";
          $to =$myemail;
          $subject = 'Password Resseted On R Nation Ent.';
          $message= '<p style="color:#4c5a7d"> Hello '.$names.' , </p>';
          $message .= '<p>This is to inform that passwords For your Account has been Upgraded </p>';
          $message .= '<p>New account is Created, Use the Below Credentials to Log in Your Account: </p>';
          $message .= '<p> User Name:'.$Username.'</p>';
          $message .= '<p> Email/ID: '.$myemail.'</p>';
          $message .= '<p> New Password: <b>'.$renew.'</b></p>';
  
          $message .= '<p>You can Use this link/Button to </br>';
  
  $message .= '<a href="'.$url.'"><button name="Login" class="btn btn-info ">Login</button></a></p>';
  $message .= '<p> if the Button appears to marfunction copy this url <b>https://www.admin.thernation.com</b> into your browser </p>';
          
          if(isset($alert)){
            $message .= '<p> Belows are Some Errors Occured:</p>';
          $message .= '<p> Errors:'.$alert.'</p>';
          }else{
            $message .= '<p> Thank you!</p>';
          }
          $message .= '<p> ------------------------------------------------------------------------------</p>';
          $message .= '<p>  If this was you, you don’t need to do anything. If not, we’ll help you secure your account. call Us now
           <a href="tel:+250784624822"> (+250) 784 624 822 </a> or just Reply to <b>info@admin.thernation.com</b>!</p>';
           $message .= '<p> *******************************************************************************</p>';
           $message .='<p>"CONFIDENTIALITY NOTICE This e-mail message and any attachments are only for the use of the intended recipient and may contain information that is privileged, confidential or exempt from disclosure under applicable law. If you are not the intended recipient, any disclosure, distribution or other use of this e-mail message or attachments is prohibited. If you have received this e-mail message in error, please delete and notify the sender immediately. Thank you."</p>';
           $message .= '<p> *******************************************************************************</p>';
           $headers = "From: R Nation Ent. Your User Account <no-reply@thernation.com>\r\n";
           $headers .= "Reply-To: info@admin.thernation.com\r\n";
           
           $headers .= "Content-type: text/html\r\n";
          
          $send=mail($to, $subject, $message, $headers);
               echo("<script>location.href='profile.php?welcome&u=".$names."';</script>"); 
            }    
        
      } }
      else{
   //echo("<div class='error_message btn-danger text-center'>Invalid!<br> Enter Correct User name/email OR Password.</div><br/>");
   if(!isset($_SESSION['p_attempt'])){
  $_SESSION['p_attempt']=2;
   }elseif (isset($_SESSION['p_attempt'])&&($_SESSION['p_attempt']<=0)) {
      echo("<script>location.href='logout.php?falseuser=".$names."';</script>"); 
   }
   else{
  $_SESSION['p_attempt']=$_SESSION['p_attempt']-1;
   }
   echo("<p class='text-center border-1 text-danger'>Old Password was Invalid!<br> Enter Correct Password.</p>");
   echo("<p class='text-center border-1 text-danger'>If you keep guessing wrong You will be signed Out!!.</p>");
   echo("<p class='text-center border-1 text-danger'>Remaining Chances: <b>".$_SESSION['p_attempt']."</b></p>");
  
      }
    }
  
  
  // else{
  // echo("<div class='error_message text-center'>login.</div><br/>");
  // }
  }else{
     echo '<label>Not Set, Try Again</label>';
                   } ?>