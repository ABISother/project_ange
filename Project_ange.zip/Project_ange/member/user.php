<?php
session_start();
?>
<?php
if(!isset($_SESSION["p_user"])){
echo("<script>location.href='login.php';</script>");
}elseif (isset($_SESSION["p_user"])&& !isset($_SESSION["access"])){
 echo("<script>location.href='lock.php';</script>");
}
else{
    include('connection.php'); 
$account_key=$_SESSION["p_user"];
$sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['user_name'];
$myemail=$fetch_account['email'];

$sel_place=$con->query("SELECT*from locations WHERE D_admin='$account_key' ")or die($con->error);
if($count_place=$sel_place->num_rows>0){
//Number of locations this user has responsed to work on
  $locations=$count_place;
 
}else{
  $locations=0;
}

$today=date(" M d, Y");
$time=date("h:i a");
}
    ?>

<?PHP
if(isset($_POST['saving_girl'])){

 if(empty($_POST['about']) ||empty($_POST['fName']) ||empty($_POST['bday'])){
     $new_info="Please Fill All the Blanks to Update,<br> Every box must contain Relevant details";
   }else{
     $about = $_POST['about'];
  $fName=$_POST['fName'];
  $bday=$_POST['bday'];
    
  $newemail=$_POST['email'];

  $country=$_POST['country'];
  $image=$_POST['imagename'];

   //$changequery=$con->query("UPDATE users SET bday='$bday',contacts='$contact',profile='$image',country='$country',about='$about',email='$newemail' WHERE id ='$account_key' ")or die($con->error);
      if ($changequery) {
       $approvo="Your account is UPDATE now!<br> <a href='users-profile.php' class='btn btn-primary ms-auto'>Click here</a> to See updates";
             //echo("<script>location.href='index.php?load&user=".$names."';</script>"); 
          }    
   }

}


?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Users / Account - Gender Justice for women and girls analytic and  management System</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../images/logo.png" rel="icon">
  <link href="../images/logo.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Image Crop upload -->

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Care International Rwanda
  * Author: Umwali Ange
  * License: +250786193917
  ======================================================== -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.css" />
</head>

<body>

  <!-- ======= Header ======= -->
 <?php 
$active_admin='account';
include'header.php';?>



  <main id="main" class="main">
 
    <div class="pagetitle">
      <h1>Account</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item">Users</li>
          <li class="breadcrumb-item active">Account</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
    <?php if(isset($_GET['welcome'])){ ?>
                   <div class="alert alert-warning bg-primary text-light border-0 alert-dismissible fade show" role="alert">
                 <STRONG>Welcome</STRONG>, to Gender Justice for women and girls analytic and management System <br>Start to <a class="text-warning" href="index.php">Dashboard</a>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
                  <?php } ?>
    <section class="section profile">
      <div class="row">


        <div class="col-xl-12">
    <?php if(isset($alert)){ ?>
    <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show" role="alert">
                <?php echo $alert; ?>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
                  <?php } ?>
                  <?php if(isset($_GET['alert'])){ ?>
    <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show" role="alert">
                <?php echo $_GET['alert']; ?>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
                  <?php } ?>
                  <?php if(isset($info)){ ?>
    <div class="alert alert-info bg-info text-light border-0 alert-dismissible fade show" role="alert">
                <?php echo $info; ?>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
                  <?php } ?>

<?php if(isset($approvo)){ ?>
                   <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show" role="alert">
                 <?php echo $approvo; ?>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
                  <?php } ?>
          <div class="card">
            <div class="card-body pt-3">
              <!-- Bordered Tabs -->
              <ul class="nav nav-tabs nav-tabs-bordered">

                <li class="nav-item">
                  <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#profile-overview">Overview</button>
                </li>

                <li class="nav-item">
                  <button class="nav-link" data-bs-toggle="tab" data-bs-target="#my-locations">Locations</button>
                </li>

                <li class="nav-item">
                  <button class="nav-link" data-bs-toggle="tab" data-bs-target="#list-of-girls">Girls In My location</button>
                </li>
                <li class="nav-item">
                  <button class="nav-link" data-bs-toggle="tab" data-bs-target="#my-options">Activities</button>
                </li>
              </ul>
              <div class="tab-content pt-2">

                <div class="tab-pane fade show active profile-overview" id="profile-overview">
                  <h5 class="card-title">Overview</h5>
                  <!-- <p class="small fst-italic"><?php echo $fetch_account['about'] ?></p> -->
                  

                  <div class="row">
                    <div class="col-lg-3 col-md-3 label ">Account User (Agent)</div>
                    <div class="col-lg-9 col-md-8"><?php echo $fetch_account['user_name'] ?></div>
                  </div>

                  

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label">Main Location</div>
                    <div class="col-lg-9 col-md-8"><?php echo $fetch_account['country'] ?></div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label">Responsible District</div>
                    <div class="col-lg-9 col-md-8"><?php 
                    $loc=$fetch_account['R_district'];
                    $sel_loc=$con->query("SELECT*from locations where id='$loc' ")or die($con->error);
                    if($count_loc=$sel_loc->num_rows>0){
                        $fetch_loc=$sel_loc->fetch_assoc();
                        echo $fetch_loc['District'];
                    }else{
                     echo $fetch_account['R_district']." None"; 
                    }?></div>
                  </div>
                  <div class="row">
                    <div class="col-lg-3 col-md-4 label">Locations(Districts)</div>
                    <div class="col-lg-9 col-md-8"><?php  
                    $howmn=$fetch_account['id'];
                    $sel_howmn=$con->query("SELECT*from locations where D_admin='$howmn' ")or die($con->error);
                    if($count_howmn=$sel_howmn->num_rows>0){
                        $fetch_howmn=$sel_howmn->fetch_assoc();
                        echo $count_howmn." ";
                        echo $fetch_howmn['District'];
                    }else{
                     echo "(0) None"; 
                    }?></div>
                  </div>


                  <h5 class="card-title">Addition Options</h5>
                  <?php if(isset($new_info)){ ?>
    <div class="alert alert-info bg-info text-light border-0 alert-dismissible fade show" role="alert">
                <?php echo $new_info; ?>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
                  <?php } ?>
                  <!-- Here's the expand button -->
                  <div class="pt-2">
                          <a href="new_1.php" class="btn btn-primary btn-sm" title="Upload new profile image" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">Add a child<i class="bi bi-plus"></i></a>
                          
                        </div>
 <!-- Accordion without outline borders -->

                <div class="accordion-item">
                  
                  <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                     <div class="panel panel-default">
          <BR>
                     <a href="new_1.php" class="btn btn-primary btn-sm"  title="Upload new profile image" >New Women</a>
    
         <!-- Profile Edit Form -->

         
                    </div>
                  </div>

                   
                </div>
                
                    
 
                      </div><!-- End Accordion without outline borders -->
                  
                <div class="tab-pane fade my-locations pt-3" id="my-locations">

                <div class="card-body pb-0">
                  <h5 class="card-title">Top Selling <span>| Today</span></h5>

                  <table class="table table-borderless">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Country</th>
                        <th scope="col">Province</th>
                        <th scope="col">District</th>
                        <th scope="col">Total Girls</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php while( $fetch_place=$sel_place->fetch_assoc()){
                                  $loc_id=$fetch_place['id'];
                       ?>
                      <tr>
                        <th scope="row"><a href="#">#1</th>
                        <td><a href="#" class="text-primary fw-bold"><?php echo $fetch_place['country'] ?></a></td>
                        <td><?php echo $fetch_place['province'] ?></td>
                        <td class="fw-bold"><a href="#" class="text-primary fw-bold"><?php echo $fetch_place['District'] ?></a></td>
                        <td class="fw-bold">
                          <?php $sel_girls_there=$con->query("SELECT*from girls WHERE	district='$loc_id' ")or die($con->error);
                          $countgirlsthere=$sel_place->num_rows;
                          echo $countgirlsthere ?></td>
                      </tr>
                      <?php } ?>
                     
                    </tbody>
                  </table>

                </div>

                </div>

                <div class="tab-pane fade pt-3" id="my-options">

                  <!-- Settings Form -->
                  <form>

                    <div class="row mb-3">
                      <label for="fullName" class="col-md-4 col-lg-3 col-form-label">Available activities on This account</label>
                      <div class="col-md-8 col-lg-9">
                        <div class="form-check">
                          
                          <a href="new_1.php" class="form-check-label  btn-link" >
                          <input class="form-check-input" type="checkbox" id="changesMade" checked>
                            Add a new Girl or member
                          </a>
                        </div>
                        <div class="form-check">
                         
                          <a href="#" class="form-check-label  btn-link" >
                          <input class="form-check-input" type="checkbox" id="changesMade" checked>
                            View List Of Girls 
                      </a>
                        </div>
                        <div class="form-check">
                         
                          <a href="/Project_ange/report/report.php" target="_blank" class="form-check-label  btn-link" >
                          <input class="form-check-input" type="checkbox" id="changesMade" checked>
                           <strong> View Report </strong>
                          </a>
                        </div>
                        <div class="form-check">
                          
                          <a href="new_1.php" class="form-check-label  btn-link" >
                          <input class="form-check-input" type="checkbox" id="changesMade" checked>
                            Add a new Girl
                      </a>
                        </div>
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" id="securityNotify" checked disabled>
                          <label class="form-check-label" for="securityNotify">
                            Security alerts
                          </label>
                        </div>
                      </div>
                    </div>

                    <div class="text-center">
                      <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                  </form><!-- End settings Form -->

                </div>

                <div class="tab-pane fade pt-3" id="list-of-girls">
                  <!-- Change Password Form -->
                    <!-- Recent Sales -->
            <div class="col-12">
              <div class="card recent-sales overflow-auto">

                <div class="filter">
                  <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
                 
                </div>

                <div class="card-body">
                  <h5 class="card-title">Recent Girls <span>| Today</span></h5>

                  <table class="table table-borderless datatable">
                    <thead>
                      <tr>
                      <th scope="col">#</th>
                        <th scope="col">Customer</th>
                        <th scope="col">Location</th>
                        <th scope="col">Unique Code</th>
                        <th scope="col">Age</th>
                        <th scope="col">Status</th>
                      </tr>
                    </thead>
                          
        <?php  
     
          $sel_members=$con->query("SELECT*from girls where supervisor='$account_key' ")or die($con->error);
          if($count_members=$sel_members->num_rows>0){
            $message='<p>The Below is the list of Members Available Care Database You can Sort and see <a href="girls.php?nearme">only Members from Your Location .</a></p>';
            
            $Q=0;
          }else{
            $message='<p>Currently There is No Such Member in Care Database You can be the First to <a href="#">Add a Member From the Location</a></p>';
          }
          
        ?>
        
                    <tbody>
                    <?php while($fetch_members=$sel_members->fetch_assoc()){ 
                    $Q++; ?>
                      <tr>
                        <th scope="row">#<?php echo $Q; ?></th>
                        <th><a href="#" title="Upload new profile image" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne<?php echo $fetch_members['id'];?>" aria-expanded="false" aria-controls="flush-collapseOne<?php echo $fetch_members['id'];?>"><?php echo $fetch_members['fname']." ".$fetch_members['lname'];?></a></th>
                        <td><?php 
                    $her_loc=$fetch_members['district'];
                    $sel_her_loc=$con->query("SELECT*from locations where id='$her_loc' ")or die($con->error);
                    if($count_her_loc=$sel_her_loc->num_rows>0){
                        $fetch_her_loc=$sel_her_loc->fetch_assoc();
                        echo $fetch_her_loc['District'];
                    }else{
                     echo $fetch_account['R_district']."Location Unknown"; 
                    }?></td>
                        <td><a href="#" class="text-primary" title="Upload new profile image" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne<?php echo $fetch_members['id'];?>" aria-expanded="false" aria-controls="flush-collapseOne<?php echo $fetch_members['id'];?>"><?php echo $fetch_members['girl_unique'];?></a>  <!-- Here's the expand button -->
                  </td>
                        <td><?php echo $fetch_members['age'];?></td>
                        <td><?php if($fetch_members['category']=='Critical'){ 
                      echo '<span class="badge bg-danger"><i class="bi bi-exclamation-octagon me-1"></i> '.$fetch_members["category"].'</span>';
                    }elseif($fetch_members['category']=='Major'){ 
                      echo '<span class="badge bg-warning text-dark"><i class="bi bi-exclamation-triangle me-1"></i>  '.$fetch_members["category"].'</span>';
                    }elseif($fetch_members['category']=='Minor'){ 
                      echo '<span class="badge bg-info text-dark"><i class="bi bi-info-circle me-1"></i> '.$fetch_members["category"].'</span>';
                    }else{ 
                      echo '<span class="badge bg-secondary"><i class="bi bi-collection me-1"></i> '.$fetch_members["category"].'</span>';
                    }
                    ?></td>
                      </tr>
                   
 <!-- Accordion without outline borders -->

                <div class="accordion-item">
                  
                  <div id="flush-collapseOne<?php echo $fetch_members['id'];?>" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                     <div class="panel panel-default">
                      <div class="pagination justify-content-end"> <a href="new_1.php" class="btn btn-danger  justify-content-end btn-sm" title="Upload new profile image" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne<?php echo $fetch_members['id'];?>" aria-expanded="false" aria-controls="flush-collapseOne">Close
          <i class="bx bx-x-circle"></i></a> </div>
                    
                  <div class="row mb-3">
                      <label class="col-md-4 col-lg-3 col-form-label"><img src="assets/img/users/<?php echo $fetch_members['image'];?>" class="img-fluid rounded-start" height="200px" class="card-icon rounded-circle" alt=""><span class="badge bg-secondary"><?php echo $fetch_members['fname']." ".$fetch_members['lname'];?></span></label>
                      <div class="col-md-6">
                       
                        <div class="form-check">
                        <label class="form-check-label" for="proOffers">
                        Names: <strong><?php echo $fetch_members['fname']." ".$fetch_members['lname'];?></strong>
                          </label>
                          
                         </div>
                        <div class="form-check">
                          
                          <label class="form-check-label" for="proOffers">
                          Birthdate: <span class="badge bg-secondary"><?php $herday=$fetch_members['birthdate'];
                       print date("d-M-Y ",$herday);?></span> Age: <span class="badge bg-secondary"><?php echo $fetch_members['age'];?></span>
                          </label>
                        </div>

                        <div class="form-check">
                          
                          <label class="form-check-label" for="proOffers">
                         Case Status: <?php if($fetch_members['category']=='Critical'){ 
                      echo '<span class="badge bg-danger"><i class="bi bi-exclamation-octagon me-1"></i> '.$fetch_members["category"].'</span>';
                    }elseif($fetch_members['category']=='Major'){ 
                      echo '<span class="badge bg-warning text-dark"><i class="bi bi-exclamation-triangle me-1"></i>  '.$fetch_members["category"].'</span>';
                    }elseif($fetch_members['category']=='Minor'){ 
                      echo '<span class="badge bg-info text-dark"><i class="bi bi-info-circle me-1"></i> '.$fetch_members["category"].'</span>';
                    }else{ 
                      echo '<span class="badge bg-secondary"><i class="bi bi-collection me-1"></i> '.$fetch_members["category"].'</span>';
                    }
                    ?>
                          </label>
                        </div>

                        <div class="form-check">
                          
                          <label class="form-check-label" for="proOffers">
                          Father: <?php if($fetch_members['palive']=='1'){?><span class="badge border-success border-1 text-success">Alive</span>
                          <?php }else{
                            echo '<span class="badge border-danger border-1 text-danger">Dead</span>';
                          } ?><strong><?php echo $fetch_members['father'];?></strong>
                          </label>
                        </div>

                        <div class="form-check">
                          
                          <label class="form-check-label" for="proOffers">
                          Mother: <?php if($fetch_members['malive']=='1'){?><span class="badge border-success border-1 text-success">Alive</span>
                          <?php }else{
                            echo '<span class="badge border-danger border-1 text-danger">Dead</span>';
                          } ?><strong><?php echo $fetch_members['mother'];?></strong>
                          </label>
                        </div>
                        <div class="form-check">
                          
                          <label class="form-check-label" for="proOffers">
                          Email: <strong><?php echo $fetch_members['email'];?></strong>
                          </label>
                        </div>
                        <div class="form-check">
                          
                          <label class="form-check-label" for="proOffers">
                         Location:
                        <?php 
                    $her_loc=$fetch_members['district'];
                    $sel_her_loc=$con->query("SELECT*from locations where id='$her_loc' ")or die($con->error);
                    if($count_her_loc=$sel_her_loc->num_rows>0){
                        $fetch_her_loc=$sel_her_loc->fetch_assoc();
                        echo $fetch_her_loc['District'];
                    }else{
                     echo $fetch_account['R_district']."Location Unknown"; 
                    }?> </label>
                    </div>
                        <hr>
                      
                        <div class="accordion-item">
                  <h2 class="accordion-header" id="headingTwo">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseMore<?php echo $fetch_members['id'];?>" aria-expanded="false" aria-controls="collapseTwo">
                      Read More
                    </button>
                  </h2>
                  <div id="collapseMore<?php echo $fetch_members['id'];?>" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                    <div class="accordion-body">
                      <strong>This is the second item's accordion body.</strong> <?php echo $fetch_members['about'];?>.
                    </div>
                  </div>
                </div>
                      </div>
                      <div class="col-md-2">
                      <div class="form-check">
                          
                          <a href="new_1.php?edit=<?php echo $fetch_members['id'];?>" class="form-check-label  btn-link" >
                          <input class="form-check-input" type="checkbox" id="changesMade" checked>
                            Edit <?php echo $fetch_members['fname'];?></a>
                         </div>
                            <div class="form-check">
                           <a href="../report/case.php?U08R=<?php echo $fetch_members['id'];?>" class="form-check-label  btn-link" >
                          <input class="form-check-input" type="checkbox" id="changesMade" checked>
                            Open <?php echo $fetch_members['fname'];?>'s Case Details</a>
                        </div>
                  
         <!-- Profile Edit Form -->
                      <?php  } ?>
                     
                     
                    </tbody>
                  </table>

                </div>

              </div>
            </div><!-- End Recent Sales --><!-- End Change Password Form -->
 
                </div>

              </div><!-- End Bordered Tabs -->

            </div>
          </div>

        </div>

                <div class="col-xl-5">

          <div class="card">
            <div class="card-body profile-card pt-4 d-flex flex-column align-items-center">
            <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                    <i class="bi bi-pin-map-fill"></i>
                    </div>
              <!-- <img src="assets/img/users/<?php echo $fetch_account['profile'] ?>" alt="Profile" class="rounded-circle"> -->
              <h2><?php echo $fetch_account['user_name'] ?></h2>
              <h3><?php echo $fetch_account['account_type'] ?></h3>
              <div class="social-links mt-2">
                <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
                <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
                <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
                <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
              </div>

         


            </div>
          </div>
          <div class="card">
                  <h5 class="card-title">Sales <span>| Today</span></h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-cart"></i>
                    </div>
                    <div class="ps-3">
                      <h6>145</h6>
                      <span class="text-success small pt-1 fw-bold">12%</span> <span class="text-muted small pt-2 ps-1">increase</span>

                    </div>
                  </div>
                </div>

              </div>
            </div><!-- End Sales Card -->
        </div>

      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>Care International Rwanda</span></strong>. All Rights Reserved
    </div>
    <div class="credits">

      Designed by <a href="#">Umwali Ange</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.min.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>


<script>  
$(document).ready(function(){
 
 $image_crop = $('#image_demo').croppie({
    enableExif: true,
    viewport: {
      width:300,
      height:260,
      type:'rectangle' //circle
    },
    boundary:{
      width:420,
      height:400
    }
  });
 
  $('#upload_image').on('change', function(){
    var reader = new FileReader();
    reader.onload = function (event) {
      $image_crop.croppie('bind', {
        url: event.target.result
      }).then(function(){
        console.log('jQuery bind complete');
      });
    }
    reader.readAsDataURL(this.files[0]);
    $('#uploadimageModal').modal('show');
  });
 
  $('.crop_image').click(function(event){
    $image_crop.croppie('result', {
      type: 'canvas',
      size: 'viewport'
    }).then(function(response){
      $.ajax({
        url:"upload.php",
        type: "POST",
        data:{"image": response},
        success:function(data)
        {
          $('#uploadimageModal').modal('hide');
          $('#uploaded_image').html(data);
        }
      });
    })
  });
 
});  
</script>    
</body>

</html>