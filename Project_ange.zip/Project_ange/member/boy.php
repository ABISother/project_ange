<?php
session_start();
?>
<?php
if(!isset($_SESSION["p_user"])){
echo("<script>location.href='login.php';</script>");
}elseif (isset($_SESSION["p_user"])&& !isset($_SESSION["access"])){
 echo("<script>location.href='lock.php';</script>");
}
else{
    include('connection.php'); 
$account_key=$_SESSION["p_user"];
$sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['user_name'];
$myemail=$fetch_account['email'];

$sel_place=$con->query("SELECT*from locations WHERE D_admin='$account_key' ")or die($con->error);
if($count_place=$sel_place->num_rows>0){
//Number of locations this user has responsed to work on
  $locations=$count_place;
  $fetch_place=$sel_place->fetch_assoc();
  
}else{
  $locations=0;
}

$today=date(" M d, Y");
$todayyear=date("Y");
$time=date("h:i a");

}

if(isset($_SESSION["new_member"])){
    $now_member=$_SESSION["new_member"];
    $sel_member=$con->query("SELECT*from girls WHERE girl_unique='$now_member' ")or die($con->error);
if($count_member=$sel_member->num_rows>0){

  $fetch_member=$sel_member->fetch_assoc();
  $her_fname=$fetch_member['fname'];
  $her_lname=$fetch_member['lname'];
}else{
  unset($_SESSION["new_member"]);
    echo("<script>location.href='new_1.php?alert=Something went wrong Please Try again!';</script>");
}
 }else{
  unset($_SESSION["new_member"]);
  echo("<script>location.href='new_1.php?alert=You have to first Provide Basic Informations<br> Please Fill the below Form To ADD a New Member To System<br> Or Just <a href='user.php?info=The Previous activity has been canceled!'>Click Here To cancer</a> ';</script>");
 }
    ?>

<?PHP
if(isset($_POST['saving_girl'])){

  $fName=$_POST['fName'];
  $fName=str_replace("'", "\'", $fName);
  $otherName=$_POST['oName'];
  $otherName=str_replace("'", "\'",   $otherName);

  $Hid=$_POST['Hid'];
  $Hid=str_replace("'", "\'", $Hid);

  $Hname=$_POST['Hname'];
  $Hname=str_replace("'", "\'", $Hname);

  $location=$_POST['province'];
  
  $sector=$_POST['sector'];

  $bday=$_POST['bday']; 
  $byear=$_POST['byear'];
  $bMonth=$_POST['bMonth'];

  $age=$todayyear-$byear;
  $Gbday=$bday."-".$bMonth."-".$byear;
     
     $herday=strtotime($Gbday);

if(!isset($alert)){
  //$savequery=$con->query("INSERT INTO girls(fname,lname,age,phone,email,girl_unique,birthdate,about,district,supervisor,join_date) VALUES ('$fName','$otherName','$age','$pnumber','$newemail','$sku','$herday','$about','$location','$account_key','$now')")or die($con->error);
  $changequery=$con->query("UPDATE girls SET boy_names='$fName $otherName',boy_location='$location -$sector', boy_bod='$herday', boy_age='$age', hospital='$Hname', hospital_id='$Hid' WHERE girl_unique ='$now_member' ")or die($con->error);
   
  if ($changequery) {
      $approvo="Father's and Child Info has Been saved! assigned to ".$her_fname." is added in System Please complete all related info!<br> ";
      if(isset($_SESSION["new_member"])){
        echo("<script>location.href='new_3.php';</script>");
       }else{
        unset($_SESSION["new_member"]);
        echo("<script>location.href='user.php?alert=Sorry the selected User Does not much with Database<br>Please Restart the Process <br> If this keeps Happening You should contact the system Manager!';</script>");
       }
     
         } 
}
    
   

}


?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Users / Account - Gender Justice for women and girls analytic and  management System</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

 <!-- Favicons -->
 <link href="assets/img/logo.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Image Crop upload -->

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Care International Rwanda
  * Author: Umwali Ange
  * License: +250786193917
 

  ==========================Image Crop & Upload============================== -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.css" />
</head>

<body>

  <!-- ======= Header ======= -->
 <?php 
 $active_admin='account';
 include'header.php';?> 

 

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>New Member</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item">Users</li>
          <li class="breadcrumb-item">Account</li>
          <li class="breadcrumb-item active">New</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
    <?php if(isset($_GET['welcome'])){ ?>
                   <div class="alert alert-warning bg-primary text-light border-0 alert-dismissible fade show" role="alert">
                 <STRONG>Welcome</STRONG>, to Gender Justice for women and girls analytic and management System <br>Start to <a class="text-warning" href="index.php">Dashboard</a>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
                  <?php } ?>
    <section class="section profile">
      <div class="row">


        <div class="col-xl-12">
    <?php if(isset($alert)){ ?>
    <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show" role="alert">
                <?php echo $alert; ?>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
                  <?php } ?>
                  <?php if(isset($info)){ ?>
    <div class="alert alert-info bg-info text-light border-0 alert-dismissible fade show" role="alert">
                <?php echo $info; ?>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
                  <?php } ?>

<?php if(isset($approvo)){ ?>
                   <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show" role="alert">
                 <?php echo $approvo; ?>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
                  <?php } ?>
                  <div class="card">
            <div class="card-body">
                
              <h5 class="card-title">Informations of a husband/Father</h5>

              <!-- Floating Labels Form -->
              <?php if(isset($_SESSION["new_member"])){?>
                <div class="progress">
                <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 50%" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>
               <label for="Indicator">Progress</label>
            </div>
              <?php }else{ ?>
              <div class="progress">
                <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 5%" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>
               <label for="Indicator">Initiated</label>
            </div>
            <?php } ?>
              <br>
            <form method="post" action="" name="update_account" class="row g-3">

            <div class="col-md-6">
                  <div class="form-floating">
                    <input type="text" class="form-control" id="floatingName" name="fName" placeholder="Name" required/>
                    <label for="floatingName">Boy's Name</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-floating">
                    <input type="text" class="form-control" name="oName" id="floatingOname" placeholder="Other Name">
                    <label for="floatingOname">Other Names</label>
                  </div>
                </div>
                
   
                <div class="col-md-4">
                  <div class="form-floating">Address>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-floating">
                  <select class="form-select" id="validationProvince" name="province" required>
                  <option selected  value="">Boy's Province</option>
                  <option value="Kigali">Kigali</option>
                  <option value="South">South</option>
                  <option value="Western">Western</option>
                  <option value="Eastern">Eastern</option>
                  
                  </select>
                   
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-floating">
                    <input type="text" class="form-control" name="sector" id="floatingOname" placeholder="Other Name">
                    <label for="floatingOname">District</label>
                  </div>
                </div>

                <div class="col-md-2">
                    <div class="form-floating">
                <label for="bday" class="col-form-label">Boy's DOB</label>
                    </div>
                </div>


                <div class="col-md-3">
                  <div class="col-md-12">
                    <div class="form-floating">
                      <input type="Number" class="form-control" name="bday" max="31" min="1" id="floatingDay" placeholder="Day">
                      <label for="floatingDay">Day</label>
                     
                    </div>
                  </div>
                </div>
               
                <div class="col-md-3">
                  <div class="form-floating">
                 
                
                    <select class="form-select" id="floatingbMonth" name="bMonth" aria-label="Month" required/>
                      <option value="1">Jan</option>
                      <option value="2">Feb</option>
                      <option value="3">Marc</option>
                      <option value="4">Apr</option>
                      <option value="5">May</option>
                      <option value="6">Jun</option>
                      <option value="7">Jul</option>
                      <option value="8">Aug</option>
                      <option value="9">Sept</option>
                      <option value="10">Oct</option>
                      <option value="11">Nov</option>
                      <option value="12">Dec</option>

                    </select>
                    <label for="floatingbMonth">Month</label>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-floating mb-3">
                    <select class="form-select" id="floatingSelect" name="byear" aria-label="Year" required/>
                      <option selected>Select Year</option>
                      <?php                       
                       for($i=$todayyear;$i>=1970;$i--){
                           echo '<option value="'.$i.'">'.$i.'</option>';
                       } ?>

                      <option value="1969">Old enough...(< 1970)</option>
                    </select>
                    <label for="floatingSelect">Year</label>
                  </div>
                </div> 

                
                              <div class="accordion-item">
                  <h2 class="accordion-header" id="headingTwo">
                    <button class="accordion-button collapsedbtn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                    <h5 class="card-title"><u>This section is for Hospital (Where the Child was Born if he's Already!) </u></h5>
                    </button>
                  </h2>
                  <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                    <div class="accordion-body">
                        <div class="row">
                                <div class="col-md-6">
                                    <label for="basic-url" class="form-label text-primary">Hospital Name</label>
                                        <div class="input-group mb-3">
                                        <span class="input-group-text" id="basic-addon3">hospital name</span>
                                        <input type="text" class="form-control" name="Hname" value="Unknown" id="basic-url" aria-describedby="basic-addon3">
                                        </div>
                                </div>
                            <div class="col-md-6">
                                    <label for="basic-url" class="form-label text-primary">Hospital ID</label>
                                    <div class="input-group mb-3">
                                    
                                    <span class="input-group-text" id="basic-addon3">End date not Set</span>
                                    
                                    <input type="text" class="form-control" name="Hid"  value="Unknown" required  >
                                    </div>
                            </div>
                        </div>

                     <!-- Small tables -->
              <!-- <table class="table table-sm">
             
                <thead>
                  <tr>
                    <th scope="row">#</th>
                    <th >Categories</th>
                    <th >Prices</th>
                    
                  
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th scope="row">1</th>
                    <td>Early Bird Regular Tickets</td>
                    <td>  <div class="input-group">
                 
                 <input type="number" class="form-control" id="validationVIP" placeholder="Regular Cheap Price" name="eregular_price"  >
                 <span class="input-group-text" id="basic-addon2"><span class="badge bg-secondary"><i class="bi bi-currency-euro me-1"></i> Euros</span></span>
                 <div class="invalid-feedback">
                     Please Set Prices for Regular.
                   </div>
               </div></td>
                    
                   
                  </tr>

                  <tr>
                    <th scope="col" >2</th>
                    <td scope="col">Early Bird VIP Tickets</td>
                    <td >  
                        <div class="input-group">
                 
                 <input type="number" class="form-control" id="validationVIP" placeholder="VIP Price" name="eVIP_price" >
                 <span class="input-group-text" id="basic-addon2"><span class="badge bg-secondary"><i class="bi bi-currency-euro me-1"></i> Euros</span></span>
                 <div class="invalid-feedback">
                     Please Set Prices for VIP.
                   </div>
               </div></td>
                    
                    
                  </tr>

                  <tr>
                    <th scope="col" >2</th>
                    <td scope="col">Early Bird VVIP Tickets</td>
                    <td >
                        <div class="input-group">
                 <input type="number" class="form-control" id="validationVVIP" placeholder="cheap Price to VVIP"  name="eVVIP_price"  >
                 <span class="input-group-text" id="basic-addon2"><span class="badge bg-secondary"><i class="bi bi-currency-euro me-1"></i> Euros</span></span>
                 <div class="invalid-feedback">
                     Please Set Prices for VVIP.
                   </div>
               </div>
            </td>
                   
                    
                  </tr>
                
                  
                </tbody>
              </table> -->
              <!-- End small tables -->

                    </div>
                  </div>
                </div>


                <div class="text-center">
                <a href="new_1.php" class="btn btn-primary">Back</a>
                <button type="reset" class="btn btn-secondary">Reset</button>
                <a href="new_3.php" class="btn btn-primary">Skip</a>
                  <button type="submit" name="saving_girl" class="btn btn-primary">Save &Next</button>
                  
                </div>
              </form><!-- End floating Labels Form -->


                       
            </div>
          </div>

      </div>
      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>Care International Rwanda</span></strong>. All Rights Reserved
    </div>
    <div class="credits">

      Designed by <a href="#">Umwali Ange</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.min.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>


<script>  
$(document).ready(function(){
 
 $image_crop = $('#image_demo').croppie({
    enableExif: true,
    viewport: {
      width:300,
      height:260,
      type:'rectangle' //circle
    },
    boundary:{
      width:420,
      height:400
    }
  });
 
  $('#floatingImage').on('change', function(){
    var reader = new FileReader();
    reader.onload = function (event) {
      $image_crop.croppie('bind', {
        url: event.target.result
      }).then(function(){
        console.log('jQuery bind complete');
      });
    }
    reader.readAsDataURL(this.files[0]);
    $('#uploadimageModal').modal('show');
  });
 
  $('.crop_image').click(function(event){
    $image_crop.croppie('result', {
      type: 'canvas',
      size: 'viewport'
    }).then(function(response){
      $.ajax({
        url:"upload.php",
        type: "POST",
        data:{"image": response},
        success:function(data)
        {
          txt = "Preview";
          document.getElementById("previewT").innerHTML = txt;
          $('#uploadimageModal').modal('hide');
          $('#uploaded_image').html(data);

        }
      });
    })
  });
 
});  
</script>    
</body>

</html>