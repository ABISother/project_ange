<?php
session_start();
?>
<?php
if(!isset($_SESSION["p_user"])){
echo("<script>location.href='login.php';</script>");
}elseif (isset($_SESSION["p_user"])&& !isset($_SESSION["access"])){
 echo("<script>location.href='lock.php';</script>");
}
else{
    include('connection.php'); 
$account_key=$_SESSION["p_user"];
$sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['user_name'];
$myemail=$fetch_account['email'];
if($fetch_account['first_login']!=0){
 echo("<script>location.href='index.php';</script>");
}
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

   <title>Settings - Care</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->

  
      <!-- Site Icons -->
    <link rel="shortcut icon" href="img/slo1.png" type="image/x-icon" />
    <link rel="apple-touch-icon" href="img/slo1.png">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

 <!-- =======================================================
  * Template Name: Care International Rwanda
  * Author: Umwali Ange
  * License: +250786193917
  ======================================================== -->
</head>

<body>

  <main>
    <div class="container">

      <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center">

            <div class="d-flex justify-content-center py-4">
                <a href="index.php" class="logo d-flex align-items-center w-auto">
                  <img src="assets/img/logo.png" alt="">
                  <span class="d-none d-lg-block">Care International Rwanda</span>
                </a>
              </div><!-- End Logo -->

              <div class="card mb-3">

                <div class="card-body">

                  <div class="pt-4 pb-2">
                    <h5 class="card-title text-center pb-0 fs-4">Your First Login!</h5>
                     <?php

require_once('connection.php');

if(isset($_POST['update_pass']))
{

 
  

  if(empty($_POST['old']) ||empty($_POST['newp']) ||empty($_POST['renew']))

  {
    //echo("<div class='error_message btn-primary text-center'>Please Fill in the Blanks.</div><br/>"); 
      echo("<p class='border-primary border-1 text-center text-primary'>Please Fill in the Blanks.</p>");
    
  }
  else{
 $new = $_POST['newp'];
  $renew=$_POST['renew'];
  $old=$_POST['old'];
     $pass = md5($_POST['old']);

    $query="select * from  users  where id='".$account_key."' and password='".$pass."' ";
    $result=mysqli_query($con,$query);
    if(mysqli_fetch_assoc($result))
    {
//$view_p=$con->query("SELECT * from users where  password='$pass' and  user_name='$username' or password='$pass' and email='$username'")or die("Connection failed: " . $con->connect_error);
     // $view=$view_p->fetch_assoc();
      //$id=$view['store_No'];
      // $_SESSION["p_user"] = $view['id'];
      // $_SESSION["access"] = 'yes';

//       if($view['type']=='Owner'){
//       $_SESSION["users"] =$view['user_name'];    
// }
      if($new!=$renew){
         echo("<p class='border-info border-1 text-center text-primary'>New password was not confirmed <br> Please choose the password you can remember.</p>");
      }elseif ($old==$new) {
         echo("<p class='border-info border-1 text-center text-success'>New password Can not be the same as previous!<br> Choose any other keyword Please.</p>");
      }else{
          $security=md5($new);
 $changequery=$con->query("UPDATE users SET password='$security',first_login='1' WHERE id ='$account_key' ")or die($con->error);
      if ($changequery) {
        echo("<p class=' border-success text-center border-1 text-success'>New password Setted!<br> Loading Dashboard...</p>");
        if(isset($_SESSION['p_attempt'])){
            unset($_SESSION['p_attempt']);
        }
             echo("<script>location.href='profile.php?welcome&u=".$names."';</script>"); 
          }    
      
    } }
    else{
 //echo("<div class='error_message btn-danger text-center'>Invalid!<br> Enter Correct User name/email OR Password.</div><br/>");
 if(!isset($_SESSION['p_attempt'])){
$_SESSION['p_attempt']=2;
 }elseif (isset($_SESSION['p_attempt'])&&($_SESSION['p_attempt']<=0)) {
    echo("<script>location.href='logout.php?falseuser=".$names."';</script>"); 
 }
 else{
$_SESSION['p_attempt']=$_SESSION['p_attempt']-1;
 }
 echo("<p class='text-center border-1 text-danger'>Old Password was Invalid!<br> Enter Correct Password.</p>");
 echo("<p class='text-center border-1 text-danger'>Remaining Chances: <b>".$_SESSION['p_attempt']."</b></p>");

    }
  }


// else{
// echo("<div class='error_message text-center'>login.</div><br/>");
// }
}else{
  echo("<p class='text-center small'>You must Renew Password for better security<br> Fill the form correctly to Setup a new password</p>");
}

//ob_flush();
?>
                   
                  </div>

                  <form class="row g-3 needs-validation" action="" method="post" novalidate>
                    <div class="col-12">
                      <label for="yourPassword" class="form-label">Old password</label>
                      <input type="password" name="old" class="form-control" id="yourPassword1" required>
                      <div class="invalid-feedback">Please, enter your current Password!</div>
                    </div>

                    <div class="col-12">
                      <label for="yourPassword" class="form-label">New Password</label>
                      <input type="password" name="newp" class="form-control" id="yourPassword2" required>
                      <div class="invalid-feedback">Please enter your password!</div>
                    </div>

                    

                    <div class="col-12">
                      <label for="yourPassword" class="form-label">Password</label>
                      <input type="password"  name="renew" class="form-control" id="yourPassword3" required>
                      <div class="invalid-feedback">Please enter your password!</div>
                    </div>

                    <div class="col-12">
                      <div class="form-check">
                        <input class="form-check-input" name="terms" type="checkbox"  onclick="myFunction()">
                        <label class="form-check-label" for="acceptTerms">Show Password 
                      </div>
                    </div>

                   

                                   <script>
function myFunction() {
  var x = document.getElementById("yourPassword1");
  var y = document.getElementById("yourPassword2");
  var z = document.getElementById("yourPassword3");
  if (x.type === "password" || y.type === "password") {
    x.type = "text";
    y.type = "text";
    z.type = "text";
  } else {
    x.type = "password";
     y.type = "password";
      z.type = "password";
  }
}
</script>

                   <!--  <div class="col-12">
                      <div class="form-check">
                        <input class="form-check-input" name="terms" type="checkbox" value="" id="acceptTerms" required>
                        <label class="form-check-label" for="acceptTerms">I agree and accept the <a href="#">terms and conditions</a></label>
                        <div class="invalid-feedback">You must agree before submitting.</div>
                      </div>
                    </div> -->
                    <div class="col-12">
                      <button class="btn btn-primary w-100" name="update_pass" type="submit">Save Changes</button>
                    </div>
                   <!--  <div class="col-12">
                      <p class="small mb-0">Already have an account? <a href="pages-login.html">Log in</a></p>
                    </div> -->
                  </form>

                </div>
              </div>

              <div class="credits">
                Designed by <a href="#" target="Blank"> Umwali Ange</a>
              </div>

            </div>
          </div>
        </div>

      </section>

    </div>
  </main><!-- End #main -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.min.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>