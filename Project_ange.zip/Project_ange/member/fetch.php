
<?php
//fetch.php;
$con=mysqli_connect('localhost','root','','care');
$query = "SELECT * FROM activity WHERE activity_status = 0 ORDER BY id DESC";
$result = mysqli_query($con, $query);
$rowcount=mysqli_num_rows($result);
$output = '';
while($row = mysqli_fetch_array($result))
{
   $current_alert=$row["id"];
 $output .= '
 <div class="alert alert_default">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  
  <i class="ri-alert-fill"></i><h4 class="alert-heading">'.$row["tittle"].'</h4>
     <p>'.$row["information"].'</p>
     <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
	<i class="ri-close-circle-line"></i>
	</button>
 </div>';

 $update_query = "UPDATE activity SET activity_status = 1 WHERE id=$current_alert and activity_status = 0";
 mysqli_query($con, $update_query);
 
}

//echo $output;

?>

<?php 
   if($rowcount>0){
    ?>
<div class="alert1 show alert-primary alert-dismissible fade" role="alert">
<?php  }else{?>
<div class="alert1 hide alert-primary alert-dismissible fade" role="alert">
<?php  } ?>
  <div class="">
    <div class="content">
    <?php echo $output;  ?>
    </div>
   </div>
 
</div>

<?php 
   if(mysqli_fetch_assoc($result)){
    ?>
<script>
	$('.close-btn').click(function(){
		$('.alert').addClass("show");
		$('.alert').removeClass("hide");
	});
</script>

<?php
   }else{?>
   <script>
	$('.close-btn').click(function(){
		$('.alert').addClass("hide");
		$('.alert').removeClass("show");
	});
</script>

<?php }  ?>
