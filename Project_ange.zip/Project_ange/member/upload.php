<?php
session_start();
?>
<?php
if(!isset($_SESSION["p_user"])){
echo("<script>location.href='login.php';</script>");
}elseif (isset($_SESSION["p_user"])&& !isset($_SESSION["access"])){
 echo("<script>location.href='lock.php';</script>");
}
else{
    include('connection.php'); 
$account_key=$_SESSION["p_user"];
$sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['user_name'];
$myemail=$fetch_account['email'];


if(isset($_POST["image"]))
{
 $data = $_POST["image"];
 $img_array_1 = explode(";", $data);
 $img_array_2 = explode(",", $img_array_1[1]);
 $basedecode = base64_decode($img_array_2[1]);
 $filename = time() . '_member.jpg';
 file_put_contents("assets/img/users/$filename", $basedecode);
 //file_put_contents($filename, $basedecode);
 echo '<img src="assets/img/users/'.$filename.'" class="img-thumbnail" />';
 echo '<input type="hidden" class="form-control" value="'.$filename.'"  name="imagename"  >';
 $now = date("Y-m-d H:i:s");
 $changequery=$con->query("UPDATE users SET profile='$filename' WHERE id ='$account_key' ")or die($con->error);
}else{
    echo '<div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show" role="alert">Select a quality Photo Please!<button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>';
}

if(isset($_POST["blogimage"]))
{
 $data = $_POST["blogimage"];
 $img_array_1 = explode(";", $data);
 $img_array_2 = explode(",", $img_array_1[1]);
 $basedecode = base64_decode($img_array_2[1]);
 $filename = time() . '.jpg';
 file_put_contents("../img/photo/$filename", $basedecode);
 //file_put_contents($filename, $basedecode);
 echo '<img src="../img/photo/'.$filename.'" class="img-thumbnail" />';
 echo '<input type="hidden" class="form-control" value="'.$filename.'"  name="imagename"  >';
 $now = date("Y-m-d H:i:s");
 //$sql = "INSERT INTO additions(caption, story_id, upload_date, file_name, deleted) VALUES ('$filename','40','$now','0')"; 
 //$con->query($sql); 
}
}
?>