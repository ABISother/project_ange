<?php
session_start();
?>
<?php
if(!isset($_SESSION["p_user"])){
echo("<script>location.href='login.php';</script>");
}elseif (isset($_SESSION["p_user"])&& !isset($_SESSION["access"])){
 echo("<script>location.href='lock.php';</script>");
}
else{
    include('connection.php'); 
$account_key=$_SESSION["p_user"];
$sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['user_name'];
$myemail=$fetch_account['email'];



$today=date(" M d, Y");
$todayyear=date("Y");
$time=date("h:i a");

$now=time();
}
    ?>

<?PHP
if(isset($_POST['saving_girl'])){

 if(empty($_POST['about']) ||empty($_POST['fName']) ||empty($_POST['bday'])){
     $info="Please Fill All Important information the Blanks,<br> Every box must contain Relevant details";
   }else{
     $about = $_POST['about'];
     $about=str_replace("'", "\'", $about);
  $fName=$_POST['fName'];
  $fName=str_replace("'", "\'", $fName);
  $otherName=$_POST['oName'];
  $otherName=str_replace("'", "\'",   $otherName);
  $bday=$_POST['bday']; 
  $newemail=$_POST['email'];
  $pnumber=$_POST['pnumber'];
  
  $byear=$_POST['byear'];
  $bMonth=$_POST['bMonth'];

  $location=$_POST['location'];
  
  $sector=$_POST['Sector'];
  $cell=$_POST['Cell'];

  if(isset($location) && !empty($location)){

    $sel_now_location=$con->query("SELECT*from locations WHERE id='$location' ")or die($con->error);
    if($count_now_location=$sel_now_location->num_rows>0){
      $fetch_now_location=$sel_now_location->fetch_assoc();
      $nowDistrict=$fetch_now_location['District'];
      $nowSector=$fetch_now_location['sector'];
      $nowProvince=$fetch_now_location['province'];
      $nowadmin=$fetch_now_location['D_admin'];
      $nowadmin=$fetch_now_location['D_admin'];
    }else{
      $alert=" Sorry!, we Didn't quite get Your choosen District!";
    }
    $sel_location=$con->query("SELECT*from locations WHERE District='$nowDistrict' and sector='$sector' ")or die($con->error);
if($count_location=$sel_location->num_rows>0){
  $fetch_location=$sel_location->fetch_assoc();
  $location=$fetch_location['id'];
}else{
  $savelocation=$con->query("INSERT INTO locations(province,District,sector,cell,created_date,D_admin) VALUES ('$nowProvince','$nowDistrict','$sector','$cell','$now','$nowadmin')")or die($con->error);
if($savelocation){
  $last=$con->query("SELECT * FROM locations WHERE id=(SELECT max(id) FROM locations) ")or die($con->error);
  $fetch_last=$last->fetch_assoc();
  $location=$fetch_last['id'];

}
}
  }
 $age=$todayyear-$byear;
 $Gbday=$bday."-".$bMonth."-".$byear;
    
    $herday=strtotime($Gbday);

 //===========generate the sku=============
function checkkeys($con,$randstr){
	$sql ="SELECT * FROM girls";
	$result=mysqli_query($con,$sql);
	while ($row=mysqli_fetch_assoc($result)){
		if($row['girl_unique']==$randstr){
			$keyExists=true;
			break;
			}else{
			$keyExists=false;
		}
    return $keyExists;
	}
}
function generatekey($con){
	$keylength = 6;
$str="1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ";
$randstr = substr(str_shuffle($str),0, $keylength);
$checkkeys= checkkeys($con,$randstr);
while ($checkkeys==true) {
$randstr = substr(str_shuffle($str),0, $keylength);
$checkkeys= checkkeys($con,$randstr);
}
return $randstr;
}
 //echo generatekey($con);
$sku=generatekey($con);
//------------======------End of sku Generations----========----


if(!isset($alert)){
  $savequery=$con->query("INSERT INTO girls(fname,lname,age,phone,email,girl_unique,birthdate,about,district,lsector,lcell,supervisor,join_date) VALUES ('$fName','$otherName','$age','$pnumber','$newemail','$sku','$herday','$about','$location','$sector','$cell','$account_key','$now')")or die($con->error);
  if ($savequery) {
      $approvo="New Member is added in System Please complete all related info!<br> ";
      $_SESSION["new_member"] = $sku;

      $saveactivity=$con->query("INSERT INTO activity(activity_by,tittle,category,information,event_time) VALUES ('$account_key','New Name has been Added','info','New name: $fName. has been added to the system','$now')")or die($con->error);
 

      if(isset($_SESSION["new_member"])){
        echo("<script>location.href='new_2.php';</script>");
       }
     
         } 
}
    
   }

}


?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Users / Account - Gender Justice for women and girls analytic and  management System</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

 <!-- Favicons -->
 <link href="assets/img/logo.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Image Crop upload -->

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Care International Rwanda
  * Author: Umwali Ange
  * License: +250786193917
  ======================================================== -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.css" />
</head>

<body>

  <!-- ======= Header ======= -->
 <?php 
 $active_admin='account';
 include'header.php';?> 

 

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>New Girl</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item">Users</li>
          <li class="breadcrumb-item">Account</li>
          <li class="breadcrumb-item active">New</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
    <?php if(isset($_GET['welcome'])){ ?>
                   <div class="alert alert-warning bg-primary text-light border-0 alert-dismissible fade show" role="alert">
                 <STRONG>Welcome</STRONG>, to Gender Justice for women and girls analytic and management System <br>Start to <a class="text-warning" href="index.php">Dashboard</a>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
                  <?php } ?>
    <section class="section profile">
      <div class="row">


        <div class="col-xl-12">
    <?php if(isset($alert)){ ?>
    <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show" role="alert">
                <?php echo $alert; ?>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
                  <?php } ?>
                  <?php if(isset($info)){ ?>
    <div class="alert alert-info bg-info text-light border-0 alert-dismissible fade show" role="alert">
                <?php echo $info; ?>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
                  <?php } ?>

<?php if(isset($approvo)){ ?>
                   <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show" role="alert">
                 <?php echo $approvo; ?>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
                  <?php } ?>
                  <?php if(isset($_GET['alert'])){ ?>
    <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show" role="alert">
                <?php echo $_GET['alert']; ?>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
                  <?php } ?>
                  <div class="card">
            <div class="card-body">
                
              <h5 class="card-title">Registering New Person</h5>

              <!-- Floating Labels Form -->
              <?php if(isset($_SESSION["new_member"])){?>
                <div class="progress">
                <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 40%" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>
               <label for="Indicator">Progress</label>
            </div>
              <?php }else{ ?>
              <div class="progress">
                <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 5%" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>
               <label for="Indicator">Initiated</label>
            </div>
            <?php } ?>

              <br>
              <form method="post" action="" name="update_account" class="row g-3">

              <div class="col-md-6">
                  <div class="form-floating">
                    <input type="text" class="form-control" id="floatingName" name="fName" placeholder="Name" required/>
                    <label for="floatingName">Girl Name</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-floating">
                    <input type="text" class="form-control" name="oName" id="floatingOname" placeholder="Other Name">
                    <label for="floatingOname">Other Names</label>
                  </div>
                </div>
               
                
                <div class="col-md-2">
                    <div class="form-floating">
                <label for="bday" class="col-form-label">BIRTH DATES</label>
                    </div>
                </div>


                <div class="col-md-3">
                  <div class="col-md-12">
                    <div class="form-floating">
                      <input type="Number" class="form-control" name="bday" max="31" min="1" id="floatingDay" placeholder="Day">
                      <label for="floatingDay">Day</label>
                     
                    </div>
                  </div>
                </div>
               
                <div class="col-md-3">
                  <div class="form-floating">
                 
                
                    <select class="form-select" id="floatingbMonth" name="bMonth" aria-label="Month" required/>
                      <option value="1">Jan</option>
                      <option value="2">Feb</option>
                      <option value="3">Marc</option>
                      <option value="4">Apr</option>
                      <option value="5">May</option>
                      <option value="6">Jun</option>
                      <option value="7">Jul</option>
                      <option value="8">Aug</option>
                      <option value="9">Sept</option>
                      <option value="10">Oct</option>
                      <option value="11">Nov</option>
                      <option value="12">Dec</option>

                    </select>
                    <label for="floatingbMonth">Month</label>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="form-floating mb-3">
                    <select class="form-select" id="floatingSelect" name="byear" aria-label="Year" required/>
                      <option selected>Select Year</option>
                      <?php                       
                       for($i=$todayyear;$i>=1990;$i--){
                           echo '<option value="'.$i.'">'.$i.'</option>';
                       } ?>

                      <option value="1989">Old enough...</option>
                    </select>
                    <label for="floatingSelect">Year</label>
                  </div>
                </div> 

                <div class="col-md-6">
                  <div class="form-floating">
                    <input type="email" name="email" class="form-control" id="floatingEmail" placeholder="N/A" >
                    <label for="floatingEmail">Girl's Email</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-floating">
                    <input  class="form-control" name="pnumber" id="floatingPhone" max="999999999999" type="number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"  maxlength = "10" placeholder="Phone Number" value="NA">
                    <label for="floatingPhone">Phone Number</label>
                    <span id="tell-numbers" style="font-size: 12px;">Provide Phone numbers if There is One</span>
                  </div>
                </div>
               
                <script type="text/javascript">
    	function numbersOnly(input){
    		var regex= /[^0-9]/gi;
    		input.value=input.value.replace(regex,"");
    		 $("#tell-numbers").html("Numbers only");
    	}
    </script>

<div  class="row">
                <div class="col-md-2">
                    <div class="form-floating">
                <label for="bday" class="col-form-label">Location</label>
                    </div>
                </div>

                <?php 
                  $sel_place=$con->query("SELECT*from locations WHERE D_admin='$account_key' ")or die($con->error);
                  if($count_place=$sel_place->num_rows>0){
                  //Number of locations this user has responsed to work on
                    $locations=$count_place;
                   // $fetch_place=$sel_place->fetch_assoc();
                  }else{
                    $locations=0;
                  }
                  //if($fetch_account['account_type']!='Manager'){ 

                    if($locations>0){
                  ?>
              
                <div class="col-md-3">
                  <div class="form-floating" id="in-district">
                   
                  <select class="form-select" id="validationDistrict" name="location" required>
                 
                      <?php
                  while($fetch_place=$sel_place->fetch_assoc()){ ?>
                  <option value="<?php echo $fetch_place['id'];  ?>" ><?php echo $fetch_place['District']; ?></option>
                    <?php }  ?>
                  </select>
                  <span id="tell-numbers" style="font-size: 12px;">You can only address in Abouve Districts as your Area.</span>
                  </div>
                  </div>
                  <?php }else{?>
                    <div class="col-md-3">
                    <div class="form-floating" id="in-district">
                  <select class="form-select" id="floatingDistrict" name="location" aria-label="district" required/>
    <option selected>Select Location</option>
    <?php
                  $sel_locations=$con->query("SELECT DISTINCT (District) District,id from locations ")or die($con->error);
                  while($fetch_locations=$sel_locations->fetch_assoc()){ ?>
                <option value="<?php echo $fetch_locations['id'] ?>" ><?php echo $fetch_locations['District'] ?></option>
                    <?php }  ?>
                    </select>
                    <span id="tell-numbers" style="font-size: 12px; color: Blue;">Your Account is not assigned to any Location You will choose in according to Girls info!.</span>
                  </div>
                  </div>
                  <?php } /* Being Admin Means nothing }else{ ?>

                    <div class="col-md-3">
                 
                  </div>
                  </div>
                  <?php } */ ?>
                  <div class="col-md-3">
                  <div class="form-floating" id="in-sector">
                    <input type="text" class="form-control" name="Sector" id="floatingSector" placeholder="Sector" Required="" >
                    <label for="floatingSector">Sector</label>
                  </div>
                  </div>

                  <div class="col-md-3">
                  <div class="form-floating" id="in-cell">
                    <input type="text" class="form-control"  id="Cell" name="Cell" placeholder="Cell" Required="">
                    <label for="floatingCell">Cell</label>
                  </div>
                  </div>



               
                  </div>
                <div class="card">
            <div class="card-body ">
              <h4 class="card-title">Discription/About </h4>

              <!-- TinyMCE Editor -->
              <textarea class="tinymce-editor" name="about" rows="3" style="height: 100px;" >
                <p>Hello Care Rwanda!</p>
                <p>This should be a<strong>full Story</strong> For this Unique Girl</p>
              </textarea><!-- End TinyMCE Editor -->

            </div>
          </div>
                <div class="text-center">
                <button type="reset" class="btn btn-secondary">Reset</button>
                  <button type="submit" name="saving_girl" class="btn btn-primary">Save & Continue</button>
                  
                </div>
              </form><!-- End floating Labels Form -->

            </div>
          </div>

      </div>
      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>Care International Rwanda</span></strong>. All Rights Reserved
    </div>
    <div class="credits">

      Designed by <a href="#">Umwali Ange</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.min.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>


<script>  
$(document).ready(function(){
 
 $image_crop = $('#image_demo').croppie({
    enableExif: true,
    viewport: {
      width:300,
      height:260,
      type:'rectangle' //circle
    },
    boundary:{
      width:420,
      height:400
    }
  });
 
  $('#upload_image').on('change', function(){
    var reader = new FileReader();
    reader.onload = function (event) {
      $image_crop.croppie('bind', {
        url: event.target.result
      }).then(function(){
        console.log('jQuery bind complete');
      });
    }
    reader.readAsDataURL(this.files[0]);
    $('#uploadimageModal').modal('show');
  });
 
  $('.crop_image').click(function(event){
    $image_crop.croppie('result', {
      type: 'canvas',
      size: 'viewport'
    }).then(function(response){
      $.ajax({
        url:"upload.php",
        type: "POST",
        data:{"image": response},
        success:function(data)
        {
          $('#uploadimageModal').modal('hide');
          $('#uploaded_image').html(data);
        }
      });
    })
  });
 
});  
</script>    
</body>

</html>