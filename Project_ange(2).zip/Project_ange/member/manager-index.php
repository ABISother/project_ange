<?php
session_start();
?>
<?php
if(!isset($_SESSION["p_user"])){
echo("<script>location.href='login.php';</script>");
}elseif (isset($_SESSION["p_user"])&& !isset($_SESSION["access"])){
 echo("<script>location.href='lock.php';</script>");
}
else{
    include('connection.php'); 
$account_key=$_SESSION["p_user"];
$sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['user_name'];
$myemail=$fetch_account['email'];


if($_SESSION["access"]!='Manager'){
  echo("<script>location.href='index.php';</script>"); 
}
if($fetch_account['first_login']==0){
 echo("<script>location.href='setting.php';</script>");
}

if(isset($_POST['saveUser'])){

  if(empty($_POST['UniqueName']) ||empty($_POST['lname']) ||empty($_POST['UserId'])){
      $info="Please Fill All Important information the Blanks,<br> Every box must contain Relevant details";
    }else{
      $Username= $_POST['UniqueName'];
      $Username=str_replace("'", "\'",   $Username);
      $UserId= $_POST['UserId'];
      $lname= $_POST['lname'];
      $lname=str_replace("'", "\'",   $lname);
      $fname= $_POST['fname'];
      $fname=str_replace("'", "\'",   $fname);
      $ulocation= $_POST['ulocation'];
      $ulocation=str_replace("'", "\'",   $ulocation);
      $Dpass= $_POST['Dpass'];
      $security=md5($Dpass);
      
      $Rtype= $_POST['Rtype'];

      $now=time();

      $sel_availables=$con->query("SELECT*from users where user_name='$Username' ")or die($con->error);
      if($count_availables=$sel_availables->num_rows>0){
       $alert="A Username ' ".$Username." ' Is taken <br>Choose a different name as User names should be Unique!";
      }

      if(!isset($alert)){
          $savequery=$con->query("INSERT INTO users(fname,lname,user_name,join_date,email,password,R_district,account_type,last_login) VALUES ('$fname','$lname','$Username','$now','$UserId','$security','$ulocation','$Rtype','$now')")or die($con->error);
          if ($savequery){
              $approvo="New Member is added in System Please complete all related info!<br> ";
        
              $saveactivity=$con->query("INSERT INTO activity(activity_by,tittle,category,information,event_time) VALUES ('$account_key','A New User has been Added','info','New User: $Username. has been added to the system','$now')")or die($con->error);
         
                     // $names=$_POST['names'];
        //$content=$_POST['content'];
        $to =$UserId;
        $subject = 'New Member is initiated in Care Internation';
        $message= '<p style="color:#4c5a7d"> Hello '.$lname.' , </p>';
        $message .= '<p>This is to inform that  </p>';
        $message .= '<p>New account is Created, Use the Below Credentials to Log in Your Account: </p>';
        $message .= '<p> User Name:'.$Username.'</p>';
        $message .= '<p> Email/ID: '.$UserId.'</p>';
        $message .= '<p> Default Password: '.$Dpass.'<small> Note that you will be Required to update This Right on the Loggin</small></p>';
        
        if(isset($alert)){
          $message .= '<p> Belows are Some Errors Occured:</p>';
        $message .= '<p> Errors:'.$alert.'</p>';
        }else{
          $message .= '<p> Thank you!</p>';
        }
        $message .= '<p> ------------------------------------------------------------------------------</p>';
        $message .= '<p>  If this was you, you don’t need to do anything. If not, we’ll help you secure your account. call Us now
         <a href="tel:+250786193917"> (+250) 786 193 917 </a> or just Reply to <b>doknge@gmail.com</b>!</p>';
        
        $headers = "From: Care International Rwanda \r\n";
        $headers .= "Reply-To: doknge@gmail.com\r\n";
        
        $headers .= "Content-type: text/html\r\n";
        
        $send=mail($to, $subject, $message, $headers);
        
        if($send){
          $approvo .="New Member is added in System Please complete all related info!<br> ";
        }else{
          $info="Email sending failed!";
        }
              
                 } 
        }

  }
} //====Closing The SaveUser============

if(isset($_POST['saveLocation'])){

  if(empty($_POST['District']) ||empty($_POST['province']) ||empty($_POST['Country'])){
      $info="Please Fill All Important information the Blanks,<br> Every box must contain Relevant details";
    }else{
      $province= $_POST['province'];
      $province=str_replace("'", "\'",   $province);

     
      $Country= $_POST['Country'];
      $Country=str_replace("'", "\'",   $Country);
      $District= $_POST['District'];
      $District=str_replace("'", "\'",   $District);
    
           
 $sel_availables=$con->query("SELECT*from locations where District='$District' ")or die($con->error);
 if($count_availables=$sel_availables->num_rows>0){
  $alert="A Branch Named".$District." Is already in system<br> A single Branch should have a Unique Name!";
 }
      $Buser= $_POST['Buser'];

      $now=time();

      if(!isset($alert)){
          $savequery=$con->query("INSERT INTO locations(country,province,District,created_date,D_admin,total_girls) VALUES ('$Country','$province','$District','$now','$Buser','0')")or die($con->error);
          if ($savequery){
              $approvo="A New Location/Branch (.$District.) has been Added!<br> ";
        
              $saveactivity=$con->query("INSERT INTO activity(activity_by,tittle,category,information,event_time) VALUES ('$account_key','A New Location/Branch has been Added','info','New Branch: $District. has been added to the system','$now')")or die($con->error);
      
              
                 } 
        }

  }
} //======End the saving Location



}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Dashboard - Care International Rwanda</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <!-- Ajax reasons-->
  <script src="assets/js/jquery.min.js"></script>


 <!-- =======================================================
  * Template Name: Care International Rwanda
  * Author: Umwali Ange
  * License: +250786193917
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <?php 
$active_admin='dashboard';
$dashboard='manager';
include'header.php';?>

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Manager - Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

          <?php if(isset($alert)){ ?>
        <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show" role="alert">
                    <?php echo $alert; ?>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
                  </div>
                      <?php } ?>
                      <?php if(isset($info)){ ?>
        <div class="alert alert-info bg-info text-light border-0 alert-dismissible fade show" role="alert">
                    <?php echo $info; ?>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
                  </div>
                      <?php } ?>

    <?php if(isset($approvo)){ ?>
                      <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show" role="alert">
                    <?php echo $approvo; ?>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
                  </div>
                      <?php } ?>
                      <?php if(isset($_GET['alert'])){ ?>
        <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show" role="alert">
                    <?php echo $_GET['alert']; ?>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
                  </div>
                      <?php } ?>
                      
        <!-- Left side columns -->
        <div class="col-lg-8">
          <div class="row">

            <!-- Sales Card -->
            <div class="col-xxl-4 col-md-6">
              <div class="card info-card sales-card">

                <div class="filter">
                  <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
                  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                    <li class="dropdown-header text-start">
                      <h6>Filter</h6>
                    </li>

                    <li><a class="dropdown-item" href="#">Today</a></li>
                    <li><a class="dropdown-item" href="#">This Month</a></li>
                    <li><a class="dropdown-item" href="#">This Year</a></li>
                  </ul>
                </div>

                <div class="card-body">
                  <h5 class="card-title">Branches <span>| Locations</span></h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-building"></i>
                    </div>
                    <div class="ps-3">
                      <h6><?php echo $count_destinations; ?></h6>
                      <span class="text-success small pt-1 fw-bold">12%</span> <span class="text-muted small pt-2 ps-1">increase</span>

                    </div>
                  </div>
                </div>

              </div>
            </div><!-- End Sales Card -->

            <!-- Revenue Card -->
            <div class="col-xxl-4 col-md-6">
              <div class="card info-card revenue-card">

               

                <div class="card-body">
                  <h5 class="card-title">Members <span>| Branch Managers</span></h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-person-badge"></i>
                    </div>
                    <div class="ps-3">
                      <h6><?php echo $count_all_users; ?></h6>
                      <span class="text-success small pt-1 fw-bold">8%</span> <span class="text-muted small pt-2 ps-1">increase</span>

                    </div>
                  </div>
                </div>

              </div>
            </div><!-- End Revenue Card -->

            <!-- Customers Card -->
            <div class="col-xxl-4 col-xl-12">

              <div class="card info-card customers-card">

                <div class="filter">
                  <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
                  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                    <li class="dropdown-header text-start">
                      <h6>Filter</h6>
                    </li>

                    <li><a class="dropdown-item" href="#">Today</a></li>
                    <li><a class="dropdown-item" href="#">This Month</a></li>
                    <li><a class="dropdown-item" href="#">This Year</a></li>
                  </ul>
                </div>

                <div class="card-body">
                  <h5 class="card-title">Cases <span>| Girls</span></h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-person-lines-fill"></i>
                    </div>
                    <div class="ps-3">
                      <h6><?php echo $count_all_cases; ?></h6>
                     
                    </div>
                  </div>

                </div>
              </div>

            </div><!-- End Customers Card -->

            <!-- Reports -->
            <div class="col-12">
              <div class="card">

                <div class="filter">
                  <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
                  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                    <li class="dropdown-header text-start">
                      <h6>Filter</h6>
                    </li>

                    <li><a class="dropdown-item" href="#">Today</a></li>
                    <li><a class="dropdown-item" href="#">This Month</a></li>
                    <li><a class="dropdown-item" href="#">This Year</a></li>
                  </ul>
                </div>

                <div class="card-body">
                  <h5 class="card-title">Reports <span>/Today</span></h5>

                  <!-- Line Chart -->
                  <div id="reportsChart"></div>

                  <script>
                    document.addEventListener("DOMContentLoaded", () => {
                      new ApexCharts(document.querySelector("#reportsChart"), {
                        series: [{
                          name: 'Minor',
                          data: [31, 40, 28, 51, 42, 82, 56],
                        }, {
                          name: 'Major',
                          data: [11, 32, 45, 32, 34, 52, 41]
                        }, {
                          name: 'criticals',
                          data: [15, 11, 32, 18, 9, 24, 11]
                        }],
                        chart: {
                          height: 350,
                          type: 'area',
                          toolbar: {
                            show: false
                          },
                        },
                        markers: {
                          size: 4
                        },
                        colors: ['#4154f1', '#2eca6a', '#ff771d'],
                        fill: {
                          type: "gradient",
                          gradient: {
                            shadeIntensity: 1,
                            opacityFrom: 0.3,
                            opacityTo: 0.4,
                            stops: [0, 90, 100]
                          }
                        },
                        dataLabels: {
                          enabled: false
                        },
                        stroke: {
                          curve: 'smooth',
                          width: 2
                        },
                        xaxis: {
                          type: 'datetime',
                          categories: ["2022-09-19T00:00:00.000Z", "2022-09-19T01:30:00.000Z", "2022-09-19T02:30:00.000Z", "2022-09-19T03:30:00.000Z", "2022-09-19T04:30:00.000Z", "2022-09-19T05:30:00.000Z", "2022-09-19T06:30:00.000Z"]
                        },
                        tooltip: {
                          x: {
                            format: 'dd/MM/yy HH:mm'
                          },
                        }
                      }).render();
                    });
                  </script>
                  <!-- End Line Chart -->

                </div>

              </div>
            </div><!-- End Reports -->

            <!-- Donations here  -->
                    
            <!-- Recent Sales -->
            <div class="col-12">
              <div class="card recent-sales overflow-auto">

                <div class="filter">
                  <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
                  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                    <li class="dropdown-header text-start">
                      <h6>Filter</h6>
                    </li>

                    <li><a class="dropdown-item" href="#">Today</a></li>
                    <li><a class="dropdown-item" href="#">This Month</a></li>
                    <li><a class="dropdown-item" href="#">This Year</a></li>
                  </ul>
                </div>

                <div class="card-body">
                  <h5 class="card-title">Donations <span>| <?php echo $count_donations; ?> Donor[s]</span></h5>

                  <table class="table table-borderless datatable">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Donor</th>
                        <th scope="col">Donor Address</th>
                        <th scope="col">Amount</th>
                        <th scope="col">Day of Donating</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $sel_avlocations=$con->query("SELECT*from donations ")or die($con->error);  
                      if($count_locations=$sel_avlocations->num_rows>0){
                        $c=0;
                        while($fetch_avlocations=$sel_avlocations->fetch_assoc()){
                          $c++;
                          $branch_id=$fetch_avlocations['id']; ?>
                      <tr>
                        <th scope="row"><a href="#">#<?php echo $c; ?></a></th>
                        <td><?php echo $fetch_avlocations['Donor_names']; ?></td>
                        <td><?php echo $fetch_avlocations['Donor_email']; ?>                                      
                      </td>
                      <td><?php echo $fetch_avlocations['amout']; ?> RWF</td>
                        <td><?php $nowtime=$fetch_avlocations['event_time'];
                    print date("D| M d,Y",$nowtime);?>
                            </td>
                      </tr>

                       <?php
                        }
                        
                        
                      }
                      ?>
                      
                     
                      
                    </tbody>
                  </table>

                </div>

              </div>
            </div><!-- End Recent Sales -->
            <!-- End of Donations Here  -->

            <!-- Recent Sales -->
            <div class="col-12">
              <div class="card recent-sales overflow-auto">

                <div class="filter">
                  <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
                  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                    <li class="dropdown-header text-start">
                      <h6>Filter</h6>
                    </li>

                    <li><a class="dropdown-item" href="#">Today</a></li>
                    <li><a class="dropdown-item" href="#">This Month</a></li>
                    <li><a class="dropdown-item" href="#">This Year</a></li>
                  </ul>
                </div>

                <div class="card-body">
                  <h5 class="card-title">Branches <span>| Today</span></h5>

                  <table class="table table-borderless datatable">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Branch Names</th>
                        <th scope="col">Branch Manager</th>
                        <th scope="col">People</th>
                        <th scope="col">User_type</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $sel_avlocations=$con->query("SELECT*from locations ")or die($con->error);  
                      if($count_locations=$sel_avlocations->num_rows>0){
                        $c=0;
                        while($fetch_avlocations=$sel_avlocations->fetch_assoc()){
                          $c++;
                          $branch_id=$fetch_avlocations['id']; ?>
                      <tr>
                        <th scope="row"><a href="#">#<?php echo $c; ?></a></th>
                        <td><?php echo $fetch_avlocations['District']; ?></td>
                        <td><?php $sel_Dadmin=$con->query("SELECT*from users where R_district='$branch_id' ")or die($con->error);  
                      if($count_Dadmin=$sel_Dadmin->num_rows>0){
                       $fetch_Dadmin=$sel_Dadmin->fetch_assoc();
                       echo '<a href="#?v!8='.$fetch_Dadmin['id'].'" class="text-primary">';
                     echo $fetch_Dadmin['user_name'];
                    echo '</a>';
                       }else{
                      echo "NONE";
                     }?>
                                              
                      </td>
                      <td><?php $sel_girls=$con->query("SELECT*from girls where district='$branch_id' ")or die($con->error); 
                        $count_girls=$sel_girls->num_rows; 
                      if($count_girls>0){
                       
                       echo $count_girls." Girl(s)";
                      }else{
                        echo $count_girls."(None)";
                      } ?>
                  
                            </td>
                        <td><?php  if($fetch_Dadmin['account_type']=='Manager'){
                          echo '<span class="badge bg-primary"> '.$fetch_Dadmin["account_type"].'</span>'; 
                        }elseif($fetch_Dadmin['account_type']=='user'){
                          echo '<span class="badge bg-success">'.$fetch_Dadmin["account_type"].'</span>'; 
                        }else{
                          echo '<span class="badge bg-warning">'.$fetch_Dadmin["account_type"].'</span>'; 
                        }
                        ?>
                            </td>
                      </tr>

                       <?php
                        }
                        
                        
                      }
                      ?>
                      
                     
                      
                    </tbody>
                  </table>

                </div>

              </div>
            </div><!-- End Recent Sales -->

            <!-- Top Selling -->
            <div class="col-12">
              <div class="card top-selling overflow-auto">

                <div class="filter">
                  <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
                  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                    <li class="dropdown-header text-start">
                      <h6>Filter</h6>
                    </li>

                    <li><a class="dropdown-item" href="#">Today</a></li>
                    <li><a class="dropdown-item" href="#">This Month</a></li>
                    <li><a class="dropdown-item" href="#">This Year</a></li>
                  </ul>
                </div>

                <div class="card-body pb-0">
                  <h5 class="card-title">Users <span>| Today</span></h5>

                  <table class="table table-borderless">
                    <thead>
                      <tr>
                        <th scope="col">Profile</th>
                        <th scope="col">User Names</th>
                        <th scope="col">Join Date</th>
                        <th scope="col" tittle="Cases followed By ">Cases</th>
                        <th scope="col">Locations</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php $sel_avusers=$con->query("SELECT*from users ")or die($con->error);  
                      if($count_avusers=$sel_avusers->num_rows>0){
                        while($fetch_avusers=$sel_avusers->fetch_assoc()){
                          $avusers_id=$fetch_avusers['id']; ?>
                      <tr>
                        <th scope="row"><a href="#"><img src="assets/img/users/<?php echo $fetch_avusers['profile'] ?>" alt=""></a></th>
                        <td><a href="#" class="text-primary fw-bold"><?php echo $fetch_avusers['user_name']; ?></a></td>
                        <td><?php $nowtime=$fetch_avusers['Join_date'];
                    print date("M d,Y (D)",$nowtime);?></td>
                        <td class="fw-bold" tittle="Cases followed By "><?php $sel_girls=$con->query("SELECT*from girls where 	supervisor='$avusers_id' ")or die($con->error); 
                        $count_girls=$sel_girls->num_rows; 
                      if($count_girls>0){
                       
                       echo $count_girls." Case(s)";
                      }else{
                        echo $count_girls."(None)";
                      } ?></td>
                        <td><?php  
                    
                    $sel_howmn=$con->query("SELECT*from locations where D_admin='$avusers_id' ")or die($con->error);
                    if($count_howmn=$sel_howmn->num_rows>0){
                        $fetch_howmn=$sel_howmn->fetch_assoc();
                        echo $count_howmn." ";
                        //echo $fetch_howmn['District'];
                    }else{
                     echo "(0) None"; 
                    }?></td>
                      </tr>
                      <?php } }else{
                        //when Users are not available!!

                        
                      }?>
                      
                    </tbody>
                  </table>

                </div>

              </div>
            </div><!-- End Top Selling -->

          </div>
        </div><!-- End Left side columns -->

        <!-- Right side columns -->
        <div class="col-lg-4">

          <!-- Recent Activity -->
          <div class="card">
            <div class="filter">
              <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
              <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                <li class="dropdown-header text-start">
                  <h6>Filter</h6>
                </li>

                <li><a class="dropdown-item" href="#">Today</a></li>
                <li><a class="dropdown-item" href="#">This Month</a></li>
                <li><a class="dropdown-item" href="#">This Year</a></li>
              </ul>
            </div>

            <div class="card-body">
              <h5 class="card-title">Recent Activity <span>| Today</span></h5>

              <div class="activity">
              <?php  
        
          $sel_acivities=$con->query("SELECT*from activity ORDER BY id DESC LIMIT 8;")or die($con->error);
        
         
        
        if($count_acivities=$sel_acivities->num_rows>0){

          while($fetch_acivities=$sel_acivities->fetch_assoc()){
            $event_time=$fetch_acivities['event_time'];
        ?>
                <div class="activity-item d-flex">
                  <div class="activite-label">
                  <?php  
 //date_default_timezone_set('America/New_York');  
 //echo facebook_time_ago('2016-03-11 04:58:00');  

      $time_ago = $event_time;  
      $current_time = time();  
      $time_difference = $current_time - $time_ago;  
      $seconds = $time_difference;  
      $minutes      = round($seconds / 60 );           // value 60 is seconds  
      $hours           = round($seconds / 3600);           //value 3600 is 60 minutes * 60 sec  
      $days          = round($seconds / 86400);          //86400 = 24 * 60 * 60;  
      $weeks          = round($seconds / 604800);          // 7*24*60*60;  
      $months          = round($seconds / 2629440);     //((365+365+365+365+366)/5/12)*24*60*60  
      $years          = round($seconds / 31553280);     //(365+365+365+365+366)/5 * 24 * 60 * 60  
      if($seconds <= 60)  
      {  
     echo "Just Now";  
   }  
      else if($minutes <=60)  
      {  
     if($minutes==1)  
           {  
       echo "one minute ago";  
     }  
     else  
           {  
       echo "$minutes minutes ago";  
     }  
   }  
      else if($hours <=24)  
      {  
     if($hours==1)  
           {  
       echo "an hour ago";  
     }  
           else  
           {  
       echo "$hours hrs ago";  
     }  
   }  
      else if($days <= 7)  
      {  
     if($days==1)  
           {  
       echo "yesterday";  
     }  
           else  
           {  
       echo "$days days ago";  
     }  
   }  
      else if($weeks <= 4.3) //4.3 == 52/12  
      {  
     if($weeks==1)  
           {  
       echo "a week ago";  
     }  
           else  
           {  
       echo "$weeks weeks";  
     }  
   }  
       else if($months <=12)  
      {  
     if($months==1)  
           {  
       echo "a month ago";  
     }  
           else  
           {  
       echo "$months months ago";  
     }  
   }  
      else  
      {  
     if($years==1)  
           {  
       echo "one year ago";  
     }  
           else  
           {  
       echo "$years years ago";  
     }  
   }  

 ?> 
                </div>
                <?php if($fetch_acivities['category']=='info'){
                  echo "<i class='bi bi-circle-fill activity-badge text-primary align-self-start'></i>";
                }elseif($fetch_acivities['category']=='Alert'){ 
                 echo "<i class='bi bi-circle-fill activity-badge text-danger align-self-start'></i>";
                }elseif($fetch_acivities['category']=='warning'){ 
                  echo "<i class='bi bi-circle-fill activity-badge text-warning align-self-start'></i>";
                 }elseif($fetch_acivities['category']=='message'){ 
                  echo "<i class='bi bi-circle-fill activity-badge text-success align-self-start' tittle='Message'></i>";
                 }else{
                  echo "<i class='bi bi-circle-fill activity-badge text-muted align-self-start'></i>";
                }
                ?>
                  
                  <div class="activity-content">
                  <?php echo $fetch_acivities['tittle'];?> [Done by  <a href="#" class="fw-bold text-dark"><?php if($fetch_acivities['activity_by']==0){ echo "Unknown";}else{$doner=$fetch_acivities['activity_by']; 
                  $sel_doner=$con->query("SELECT*from users WHERE id='$doner' ")or die($con->error);
                  $fetch_doner=$sel_doner->fetch_assoc();
                  echo $fetch_doner['user_name'];}?></a>] 
                  </div>
               </div><!-- End activity item-->
                <?php } } ?>

               
              </div>

            </div>
          </div><!-- End Recent Activity -->

          <!-- Budget Report -->
          <div class="card">
            <div class="filter">
              <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
              <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                <li class="dropdown-header text-start">
                  <h6>Filter</h6>
                </li>

                <li><a class="dropdown-item" href="#">Today</a></li>
                <li><a class="dropdown-item" href="#">This Month</a></li>
                <li><a class="dropdown-item" href="#">This Year</a></li>
              </ul>
            </div>

            <div class="card-body pb-0">
              <h5 class="card-title">Quick Actions <span>| For Managers Only</span></h5>

                    <!-- Default Accordion -->
                    <div class="accordion" id="accordionExample">
                
                <div class="accordion-item">
                  <h2 class="accordion-header" id="headingTwo">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                      Add a .<strong> Member/User</strong> 
                    </button>
                  </h2>
                  <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                    <div class="accordion-body">
                      <strong>Just Fill the Form To add New User.</strong> 
                      <div class="card-body">
              <!-- <h5 class="card-title">New User Account</h5> -->

              <!--New User Form -->
              <form class="row g-3 needs-validation" name="user_form" action="" method="POST" >
                <div class="col-md-6">
                  <label for="validationCustom01" class="form-label">User name</label>
                  <input type="text" class="form-control" id="validationCustom01" name="fname"  required>
                  <div class="invalid-feedback">
                    Please Give a Valid NAME
                  </div>
                </div>
                <div class="col-md-6">
                  <label for="validationCustom02" class="form-label">Last name</label>
                  <input type="text" class="form-control" id="validationCustom02" name="lname"  required>
                  <div class="valid-feedback">
                    Looks good!
                  </div>
                </div>

                <div class="col-md-12">
                  <label for="validationCustomUsername" class="form-label">Username</label>
                  <div class="input-group has-validation">
                    <span class="input-group-text" id="inputGroupPrepend">U</span>
                    <input type="text" class="form-control" id="validationCustomUsername" aria-describedby="inputGroupPrepend" name="UniqueName" required>
                    <div class="invalid-feedback">
                    Please Give a unique NAME
                    </div>
                  </div>
                  </div>
                
                <div class="col-md-12">
                  <label for="validationCustomUsername" class="form-label">User ID</label>
                  <div class="input-group has-validation">
                    <span class="input-group-text" id="inputGroupPrepend">@</span>
                    <input type="email" class="form-control" id="validationCustomUsername" aria-describedby="inputGroupPrepend" Name="UserId" required>
                    <div class="invalid-feedback">
                      Please choose an email.
                    </div>
                  </div>
                  </div>
                <div class="col-md-6">
                  <label for="validationCustom04" class="form-label">Location</label>
                  <select class="form-select" id="validationCustom04" name="ulocation" required>
                    <option selected  value="">Choose Location...</option>
                    <?php
                  $sel_locations=$con->query("SELECT*from locations ")or die($con->error);
                  while($fetch_locations=$sel_locations->fetch_assoc()){ ?>
                <option value="<?php echo $fetch_locations['id'] ?>" ><?php echo $fetch_locations['District'] ?></option>
                    <?php }  ?>
                    <option value="0">Unlocated</option>             
                
                  </select>
                  <div class="invalid-feedback">
                    Please select a valid state.
                  </div>
                </div>
                <div class="col-md-6">
                  <label for="validationCustom05" class="form-label">Account-Type</label>
                  <fieldset class="row mb-3">
                  
                  <div class="col-sm-10">
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="Rtype" id="gridRadios1" value="user" checked>
                      <label class="form-check-label" for="gridRadios1">
                      User
                      </label>
                    </div>
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="Rtype" id="gridRadios2" value="Manager">
                      <label class="form-check-label" for="gridRadios2">
                      Manager
                      </label>
                    </div>
                   
                  </div>
                </fieldset>
                  <div class="invalid-feedback">
                    Please provide a valid Type
                  </div>
                </div>
                <div class="col-md-12">
                  
                  <div class="input-group has-validation">
                    <span class="input-group-text" id="inputGroupPrepend">Default U.Password</span>
                    <input type="text" class="form-control" id="validationCustomUsername" value="Carerw@12" aria-describedby="inputGroupPrepend" Name="Dpass" required>
                    <div class="invalid-feedback">
                      Please Decide a User Password.
                    </div>
                  </div>
                  </div>
                <div class="col-12">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
                    <label class="form-check-label" for="invalidCheck">
                      Agree to terms and conditions
                    </label>
                    <div class="invalid-feedback">
                      You must agree before submitting.
                    </div>
                  </div>
                </div>
                <div class="col-12">
                  <button class="btn btn-primary"  type="submit" name="saveUser">Save a User</button>
                </div>
              </form><!-- End Custom Styled Validation -->

            </div>
                    </div>
                  </div>
                </div>
                <div class="accordion-item">
                  <h2 class="accordion-header" id="headingThree">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                      Add a .<strong>LOCATION</strong>
                    </button>
                  </h2>
                  <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                    <div class="accordion-body">
                      <strong>This is the third item's accordion body.</strong>     
                         <!-- New Location-->
              <form class="row g-3 needs-validation" name="location_form" method="post" novalidate>
                <div class="col-md-6">
                  <label for="validationCountry" class="form-label">country</label>
                  <input type="text" class="form-control" id="validationCountry" name="Country" value="Rwanda"  required>
                  <div class="invalid-feedback">
                    Please Give a Valid Country
                  </div>
                </div>
                <div class="col-md-6">
                  <label for="validationProvince" class="form-label">Province</label>
                  <input type="text" class="form-control" id="validationProvince" name="province"  required>
                  <div class="valid-feedback">
                    Looks good!
                  </div>
                </div>
                
                
                <div class="col-md-6">
                  <label for="validationBuser" class="form-label">Branch Manager</label>
                  <select class="form-select" id="validationBuser" name="Buser" required>
                  <option selected  value="">Choose a User...</option>
                  <option value="0">Unavailable</option>
                      <?php
                  $sel_luser=$con->query("SELECT*from users ")or die($con->error);
                  while($fetch_luser=$sel_luser->fetch_assoc()){ ?>
                  <option value="<?php echo $fetch_luser['id'] ?>" ><?php echo $fetch_luser['user_name'] ?></option>
                    <?php }  ?>
                  </select>
                  <div class="invalid-feedback">
                    Please select a valid state.
                  </div>
                </div>
                <div class="col-md-6">
                  <label for="validationDistrict" class="form-label">District</label>
                  <input type="text" class="form-control" id="validationDistrict" name="District"  required>
                  <div class="valid-feedback">
                    Looks good!
                  </div>
                  <div class="invalid-feedback">
                      Please provide a validi District
                    </div>
                </div>
                <div class="col-12">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
                    <label class="form-check-label" for="invalidCheck">
                      Agree to terms and conditions
                    </label>
                    <div class="invalid-feedback">
                      You must agree before submitting.
                    </div>
                  </div>
                </div>
                <div class="col-12">
                  <button class="btn btn-primary" name="saveLocation" type="submit">Submit Location</button>
                </div>
              </form><!-- End CNew Location-->
            </div>
                  </div>
                </div>
                <div class="accordion-item">
                  <h2 class="accordion-header" id="headingZero">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseZero" aria-expanded="false" aria-controls="collapseThree">
                    <strong>Assign</strong>. a Location to User
                    </button>
                  </h2>
                  <div id="collapseZero" class="accordion-collapse collapse" aria-labelledby="headingZero" data-bs-parent="#accordionExample">
                    <div class="accordion-body">
                      <strong>Choose User and a Location to be assigned to...</strong> 
              <form class="row g-3 needs-validation" id="assign_form" action="" name="Assign_form" method="post" novalidate> 
               <div class="col-md-12">
                  <label for="validationCustom04" class="form-label">Location</label>
                  <select class="form-select" id="alocation" name="alocation" required>
                    <option selected disabled value="">Choose Location...</option>
                      <?php
                  $sel_locations=$con->query("SELECT*from locations ")or die($con->error);
                  while($fetch_locations=$sel_locations->fetch_assoc()){ ?>
                  <option value="<?php echo $fetch_locations['id'] ?>" ><?php echo $fetch_locations['District'] ?></option>
                    <?php }  ?>
                    <option value="0"></option>
                                       
                  </select>
                  <div class="invalid-feedback">
                    Please select a valid Location.
                  </div>
                </div>

                <div class="col-md-12">
                  <label for="validationCustom04" class="form-label">Users</label>
                  <select class="form-select" id="auser" name="auser" required>
                    <option selected  value="">Choose a User...</option>
                      <?php
                  $sel_luser=$con->query("SELECT*from users ")or die($con->error);
                  while($fetch_luser=$sel_luser->fetch_assoc()){ ?>
                  <option value="<?php echo $fetch_luser['id'] ?>" ><?php echo $fetch_luser['user_name'] ?></option>
                    <?php }  ?>
                    <option value="0"></option>
                                       
                  </select>
                  <div class="invalid-feedback">
                    Please select a valid User.
                  </div>
                </div>
                <div class="col-md-12" id="fedback_alert">
                 
                  </div>
                  <div class="col-12">
                  <button class="btn btn-primary" name="post" id="post" type="submit">Assign User</button>
                </div>
               </div>
              
                    
<script>
$(document).ready(function(){

 $('#assign_form').on('submit', function(event){
  event.preventDefault();
  if($('#alocation').val() != '' && $('#auser').val() != '')
  {
   var form_data = $(this).serialize();
   $.ajax({
    url:"assignments.php",
    method:"POST",
    data:form_data,
    success:function(data)
    {
     //$('#assign_form')[0].reset();
     $('#fedback_alert').html(data);
    }
   })
  }
  else
  {
   alert("Both Fields are Required");
  }
 });
});
</script>


              </form>
                  </div>
                </div>
              </div><!-- End Default Accordion Example -->

            </div>
          </div><!-- End Budget Report -->

          <!-- Website Traffic -->
          <div class="card">
            <div class="filter">
              <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
              <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                <li class="dropdown-header text-start">
                  <h6>Filter</h6>
                </li>

                <li><a class="dropdown-item" href="#">Today</a></li>
                <li><a class="dropdown-item" href="#">This Month</a></li>
                <li><a class="dropdown-item" href="#">This Year</a></li>
              </ul>
            </div>

            <div class="card-body pb-0">
              <h5 class="card-title">Website Traffic <span>| Today</span></h5>

              <div id="trafficChart" style="min-height: 400px;" class="echart"></div>

              <script>
                document.addEventListener("DOMContentLoaded", () => {
                  echarts.init(document.querySelector("#trafficChart")).setOption({
                    tooltip: {
                      trigger: 'item'
                    },
                    legend: {
                      top: '5%',
                      left: 'center'
                    },
                    series: [{
                      name: 'Access From',
                      type: 'pie',
                      radius: ['40%', '70%'],
                      avoidLabelOverlap: false,
                      label: {
                        show: false,
                        position: 'center'
                      },
                      emphasis: {
                        label: {
                          show: true,
                          fontSize: '18',
                          fontWeight: 'bold'
                        }
                      },
                      labelLine: {
                        show: false
                      },
                      data: [{
                          value: 1048,
                          name: 'Search Engine'
                        },
                        {
                          value: 735,
                          name: 'Direct'
                        },
                        {
                          value: 580,
                          name: 'Email'
                        },
                        {
                          value: 484,
                          name: 'Union Ads'
                        },
                        {
                          value: 300,
                          name: 'Video Ads'
                        }
                      ]
                    }]
                  });
                });
              </script>

            </div>
          </div><!-- End Website Traffic -->

       <!-- News & Updates Traffic -->
       <div class="card">
            

            <div class="card-body pb-0">
              <h5 class="card-title">Cases &amp; Updates <span>| Currently</span></h5>
              <div class="news">
              <?php    
               $sel_nearme_girls=$con->query("SELECT*from girls where supervisor='$account_key' ")or die($con->error);
            if($count_nearme_girls=$sel_nearme_girls->num_rows>0){
              
            
                    while($fetch_mygirls=$sel_nearme_girls->fetch_assoc()){ 
                      $client_id=$fetch_mygirls['id'];
                       //========================================== Select Cases====================================================
                    $sel_case=$con->query("SELECT*from cases where child_id='$client_id' ORDER BY event_time DESC ")or die($con->error);
                    $count_case=$sel_case->num_rows>0;
                        while($fetch_case=$sel_case->fetch_assoc()){
                       
                      ?>

              
                <div class="post-item clearfix">
                  <img src="assets/img/users/<?php echo $fetch_mygirls['image'];?>" alt="">
                  <h4><a href="../report/case.php?U08R=<?php echo $fetch_mygirls['id'];?>" target="_blank"><?php echo $fetch_mygirls['fname'];?> |[ <?php echo $fetch_case['case_code'];?> ] </a></h4>
                  <p><?php echo $fetch_case['event_text'];?></p>
                  <p><?php $evday=$fetch_case['event_time'];
                       print date("h:m A (M d,Y)",$evday);?></p>
                </div>
                      <?php } } ?>
               

               

              
                            <?php } ?>
                            </div><!-- End sidebar recent posts-->
            </div>
          </div><!-- End News & Updates -->

        </div><!-- End Right side columns -->

      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>Care</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
     
      Designed by <a href="#">Umwali Ange</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.min.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>