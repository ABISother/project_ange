<?php
session_start();
?>
<?php
if(!isset($_SESSION["p_user"])){
echo("<script>location.href='login.php';</script>");
}elseif (isset($_SESSION["p_user"])&& !isset($_SESSION["access"])){
 echo("<script>location.href='lock.php';</script>");
}
else{
    include('connection.php'); 
$account_key=$_SESSION["p_user"];
$sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['user_name'];
$myemail=$fetch_account['email'];


if($fetch_account['first_login']==0){
 echo("<script>location.href='setting.php';</script>");
}

}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Member List - Care International Rwanda</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Care International Rwanda
  * Author: Umwali Ange
  * License: +250786193917
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <?php 

$active_admin='girls';

 if(isset($_GET['nearme'])) {
$view='nearme';
}else{
    $view='allgirls';   
}

include'header.php';?>

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Girls</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item">Members[Girls]</li>
          <li class="breadcrumb-item active">Data</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">

      <div class="row">
        <div class="col-lg-12">

        
        <?php  
        if(isset($_GET['nearme'])){
          $sel_members=$con->query("SELECT*from girls where supervisor='$account_key' ")or die($con->error);
        }else{
          $sel_members=$con->query("SELECT*from girls ")or die($con->error);
        }
         
        
        if($count_members=$sel_members->num_rows>0){
          $message='<p>The Below is the list of Members Available Care Database You can Sort and see <a href="girls.php?nearme">only Members from Your Location .</a></p>';
          
          $Q=0;
        }else{
          $message='<p>Currently There is No Such Member in Care Database You can be the First to <a href="#">Add a Member From the Location</a></p>';
        }
        ?>

<?php if(isset($_GET['Info'])){ ?>
    <div class="alert alert-info bg-info text-light border-0 alert-dismissible fade show" role="alert">
                <?php echo $_GET['Info']; ?>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
                  <?php } ?>

                    <!-- Card with header and footer -->
                    <?php if(isset($_GET['view'])){ 
                        $viewing=$_GET['view'];
                        $sel_view=$con->query("SELECT*from girls where girl_unique='$viewing' ")or die($con->error); 
                        if( $count_view=$sel_view->num_rows>0){
                          $fetch_view=$sel_view->fetch_assoc();
                          $herlocations=$fetch_view['district'];
                        
                          $sel_place=$con->query("SELECT*from locations WHERE id='$herlocations' ")or die($con->error);
                          $fetch_place=$sel_place->fetch_assoc();
                        ?>
          <div class="card">
            <div class="card-header">Viewing <?php echo $fetch_view['girl_unique'];?></div>
            <div class="card-body">
             
             <!-- Card with an image on left -->
          <div class="card mb-3">
            <div class="row g-0">
              <div class="col-md-2">
                <img src="assets/img/users/<?php echo $fetch_view['image'];?>" class="img-fluid rounded-start" alt="<?php echo $fetch_view['fname'];?>">
                <h5 class="card-title"><?php echo $fetch_view['fname']." ".$fetch_view['lname'];?></h5>
              </div>
              <div class="col-md-6">
                <div class="card-body">
                  <h5 class="card-title">Basic Information</h5>
                  <label class="card-title">
                  <?php if($fetch_view['category']=='Critical'){ 
                      echo '<span class="badge bg-danger"><i class="bi bi-exclamation-octagon me-1"></i> '.$fetch_view["category"].'</span>';
                    }elseif($fetch_view['category']=='Major'){ 
                      echo '<span class="badge bg-warning text-dark"><i class="bi bi-exclamation-triangle me-1"></i>  '.$fetch_view["category"].'</span>';
                    }elseif($fetch_view['category']=='Minor'){ 
                      echo '<span class="badge bg-info text-dark"><i class="bi bi-info-circle me-1"></i> '.$fetch_view["category"].'</span>';
                    }else{ 
                      echo '<span class="badge bg-secondary"><i class="bi bi-collection me-1"></i> '.$fetch_view["category"].'</span>';
                    } ?></label>
                    <br/>
                    <span class="badge border-light border-1 text-black-50"><?php echo $fetch_place['District']  ?></span>
                    <span class="badge border-light border-1 text-black-50"><?php echo $fetch_view['age']  ?></span>
                  <p class="card-text"><?php echo $fetch_view['about'];?></p>
                </div>
              </div>
              <div class="col-md-3">
                <div class="card-body">
                  <h5 class="card-title">Family</h5>
                  <p class="card-text">
                  <small>Father:</small><?php if($fetch_view['palive']=='1'){ 
                      echo '<span class="badge border-success border-1 text-success"><i class="bi bi-exclamation-octagon me-1"></i> '.$fetch_view['father'].'</span>';
                    }else{
                      echo '<span class="badge border-danger border-1 text-danger"><i class="bi bi-exclamation-octagon me-1"></i> <s>'.$fetch_view['father'].'</s></span>';
                    } ?> <br>
                  <small> Mother: </small>  <?php if($fetch_view['malive']=='1'){ 
                      echo '<span class="badge border-success border-1 text-success"><i class="bi bi-exclamation-octagon me-1"></i> '.$fetch_view['mother'].'</span>';
                    }else{
                      echo '<span class="badge border-danger border-1 text-danger"><i class="bi bi-exclamation-octagon me-1"></i> <s>'.$fetch_view['mother'].'</s></span>';
                    } ?></p>
                </div>
              </div>
            </div>
          </div><!-- End Card with an image on left -->
            </div>
            <div class="card-footer">
            Joined: <?php $hernow=$fetch_view['join_date'];
                       print date("M d,Y - h:m A",$hernow);?>
            </div>
          </div><!-- End Card with header and footer -->
                      <?php }else{ ?>
                        <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show" role="alert">
                        <p>Currently There is No Such Member in Care Database You can be the First to <$fetch_viewAdd a Member From the Location</a></p>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
                      <?php } } ?>

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Database</h5>

             <?php if(isset($message)){ echo($message); } ?>
             <!-- Right/End Aligned Pagination -->
              <nav aria-label="Page navigation example">
                <ul class="pagination justify-content-end">
                  
                  <li class="page-item"><a class="page-link bg-danger" href="#"><span class="badge bg-danger"><i class="bi bi-exclamation-octagon me-1"></i> Criticals</span></a></li>
                  <li class="page-item"><a class="page-link bg-warning" href="#"><span class="badge bg-warning text-dark"><i class="bi bi-exclamation-triangle me-1"></i>  Major</span></a></li>
                  <li class="page-item"><a class="page-link bg-info" href="#"><span class="badge bg-info text-dark"><i class="bi bi-info-circle me-1"></i>  Minor</span></a></li>
                  <li class="page-item bg-secondary"><a class="page-link bg-secondary" href="#"><span class="badge bg-secondary"><i class="bi bi-collection me-1"></i>  Normal</span></a></li>
                  
                </ul>
              </nav><!-- End Right/End Aligned Pagination -->
              <!-- Table with stripped rows -->
              <table class="table datatable">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Names</th>
                    <th scope="col">Unique Code</th>
                    <th scope="col">Category</th>
                    <th scope="col">Age</th>
                    <th scope="col">Start Date</th>
                    <th ></th>
                  </tr>
                </thead>
                <tbody>
                  
                  <?php while($fetch_members=$sel_members->fetch_assoc()){ 
                    $Q++; ?>
                  <tr>
                    <th scope="row"><?php echo $Q; ?></th>
                    <td><?php echo $fetch_members['fname']." ".$fetch_members['lname'];?></td>
                    <td><code><?php echo $fetch_members['girl_unique'];?></code></td>
                    <td><?php if($fetch_members['category']=='Critical'){ 
                      echo '<span class="badge bg-danger"><i class="bi bi-exclamation-octagon me-1"></i> '.$fetch_members["category"].'</span>';
                    }elseif($fetch_members['category']=='Major'){ 
                      echo '<span class="badge bg-warning text-dark"><i class="bi bi-exclamation-triangle me-1"></i>  '.$fetch_members["category"].'</span>';
                    }elseif($fetch_members['category']=='Minor'){ 
                      echo '<span class="badge bg-info text-dark"><i class="bi bi-info-circle me-1"></i> '.$fetch_members["category"].'</span>';
                    }else{ 
                      echo '<span class="badge bg-secondary"><i class="bi bi-collection me-1"></i> '.$fetch_members["category"].'</span>';
                    }
                    ?>
                  </td>
                    <td><?php echo $fetch_members['age'];?></td>
                    <td ><label tittle="Here"><?php $herday=$fetch_members['join_date'];
                       print date("M d,Y - h:m A",$herday);?></label>
                       </td>
                      <td><?php if($fetch_members['supervisor']==$account_key){ ?>
                        <div class="filter">
                  <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
                  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                    <li class="dropdown-header text-start">
                      <h6><?php echo $fetch_members['girl_unique'];?></h6>
                    </li>

                    <li><a class="dropdown-item" href="girls.php?view=<?php echo $fetch_members['girl_unique'] ?>">View</a></li>
                    <li><a class="dropdown-item" href="#">Edit <?php echo $fetch_members['girl_unique'];?> </a></li>
                    <li><a class="dropdown-item" href="#">Delete <?php echo $fetch_members['girl_unique'];?></a></li>
                  </ul>
                </div><?php } ?></td>

                  </tr>
                  <?php  } ?>
                  
                 
                </tbody>
              </table>
              <!-- End Table with stripped rows -->

            </div>
          </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->

 <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>Care</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
     
      Designed by <a href="#">Umwali Ange</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.min.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>