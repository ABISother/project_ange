<?php
session_start();
?>
<?php
if(!isset($_SESSION["p_user"])){
echo("<script>location.href='login.php';</script>");
}elseif (isset($_SESSION["p_user"])&&isset($_SESSION["access"])){
 echo("<script>location.href='index.php';</script>");
}
else{
    include('connection.php'); 
$account_key=$_SESSION["p_user"];
$sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['user_name'];
$myemail=$fetch_account['email'];

}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Locked - Gender Justice for women and girls analytic and  management System</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Care International Rwanda
  * Author: Umwali Ange
  * License: +250786193917
  ======================================================== -->
</head>

<body>

  <main>
    <div class="container">

      <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center">

              <div class="d-flex justify-content-center py-4">
                <a href="index.php" class="logo d-flex align-items-center w-auto">
                  <img src="assets/img/logo_care.svg" alt="">
                  <span class="d-none d-lg-block">International Rwanda</span>
                </a>
              </div><!-- End Logo -->

              <div class="card mb-3">

               

                    

   
        <!-- lockscreen image -->
             <div class="card">
            <div class="card-body profile-card pt-4 d-flex flex-column align-items-center">
               
              <img src="assets/img/users/<?php echo $fetch_account['profile'] ?>" width="100px;" alt="Profile" class="rounded-circle">
              <h2><?php echo $fetch_account['user_name'] ?></h2>
              <h3><?php echo $fetch_account['account_type'] ?></h3>
              <div class="social-links mt-2">

              <?php

require_once('connection.php');

if(isset($_POST['users_login']))
{

  //$name=$_POST['loginname'];
  

  if(empty($_POST['password']))

  {
    //echo("<div class='error_message btn-primary text-center'>Please Fill in the Blanks.</div><br/>"); 
      echo("<span class='badge border-primary border-1 text-primary'>Please Fill in the Blanks.</span>");
    
  }
  else{
     $pass = md5($_POST['password']);

    $query="select * from  users  where password='".$pass."' and id='".$account_key."' ";
    $result=mysqli_query($con,$query);
    if(mysqli_fetch_assoc($result))
    {
$view_p=$con->query("SELECT * from users where  password='$pass' and  id='$account_key'")or die("Connection failed: " . $con->connect_error);
      $view=$view_p->fetch_assoc();
      //$id=$view['store_No'];
      $last_login=time();
      $_SESSION["p_user"] = $view['id'];
      $_SESSION["access"] = $view['account_type'];
      $_SESSION["last_login"] = $last_login;

      if($view['account_type']=='Manager'){
      $_SESSION["Manager"] =$view['id'];    
 }

 $query=$con->query("UPDATE users SET status='Online',last_login='$last_login' WHERE id ='".$view['id']."' ")or die($con->error);
 if(isset($_SESSION['p_attempt'])){
    unset($_SESSION['p_attempt']);
}
      echo("<script>location.href='index.php?load&user=".$view['id']."';</script>");  
    }
    else{
 //echo("<div class='error_message btn-danger text-center'>Invalid!<br> Enter Correct User name/email OR Password.</div><br/>");
 if(!isset($_SESSION['p_attempt'])){
    $_SESSION['p_attempt']=2;
     }elseif (isset($_SESSION['p_attempt'])&&($_SESSION['p_attempt']<=0)) {
        echo("<script>location.href='logout.php?falseuser=".$names."';</script>"); 
     }
     else{
    $_SESSION['p_attempt']=$_SESSION['p_attempt']-1;
     }
     echo("<p class='text-center text-danger'>Invalid  Password.</p>");
     echo("<p class='text-center border-1 text-danger'>Remaining Chances: <b>".$_SESSION['p_attempt']."</b></p>");

    }
  }

// else{
// echo("<div class='error_message text-center'>login.</div><br/>");
// }
}else{
  echo("<p class='text-center small'>Enter your password to login</p>");
}

//ob_flush();
?>
                      <!-- lockscreen credentials (contains the form) -->
        <form class="lockscreen-credentials" action="" method="post">
          
           <div class="input-group">
                      <input type="password" name="password" class="form-control" placeholder="password" aria-label="Recipient's username" aria-describedby="basic-addon2">
                     <button class="btn btn-outline-primary"type="submit" name="users_login" id="basic-addon2"> Unlock</button>
                    </div>
        </form><!-- /.lockscreen credentials -->
              </div>
            </div>
          </div>
        <!-- /.lockscreen-image -->

  
      <div class="help-block text-center">
        Enter your password to retrieve your session
      </div>
      <div class='text-center'>
        <a href="#" onclick="killsession()">Or sign in as a different user</a>
        <span id="demo"></span>
      </div>
      <script>
function killsession() {
  var txt;
  var r = confirm("You are about to End this whole Session User name and Password will be requested to Login Again!");
  if (r == true) {
    txt = "You pressed OK!";
    location.href='logout.php';
  } else {
   
   txt = "You pressed Cancel!";
  }
  //document.getElementById("demo").innerHTML = txt;
}
</script>
   

               
              </div>

              <div class="credits">
              
                Designed by <a href="#">Umwali Ange</a>
              </div>

            </div>
          </div>
        </div>

      </section>

    </div>
  </main><!-- End #main -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.min.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>