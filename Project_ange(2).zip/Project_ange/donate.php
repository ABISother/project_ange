<?php
//donate.php
if(isset($_POST['donations'])){

    include('member/connection.php'); 
     
        $donations = $_POST['donations'];
        $mName = $_POST['name'];
        $mName=str_replace("'", "\'", $mName);
        $email = $_POST['email'];
        $email=str_replace("'", "\'", $email);
        $message = $_POST['message'];
        $message=str_replace("'", "\'", $message);
        $now=time();

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $alert = "Invalid email format Try Again";
            ?>
            <script> 
            var errormsg="Invalid email format Try Again";
     $('#error-message').addClass("d-block");
     $('#error-message').html(errormsg);
     $('#email').addClass("is-invalid");
    $('#donationloader').removeClass('d-block')
              </script> 
          <?PHP
        
          }
    
        
   
   if(!isset($alert)){
     //$savequery=$con->query("INSERT INTO girls(email,lname,age,phone,email,girl_unique,birthdate,about,district,supervisor,join_date) VALUES ('$email','$otherName','$age','$pnumber','$newemail','$sku','$herday','$about','$location','$account_key','$now')")or die($con->error);
     $saveactivity=$con->query("INSERT INTO donations(Donor_names,Donor_email,amout,donor_msg,donate_for,event_time,particular_reasons) VALUES ('$mName','$email','$donations','$message','0','$now','No reason Given')")or die($con->error);
 
     if ($saveactivity) {
        //  $approvo="The photo was successfully assigned to ".$her_email." is added in System Please complete all related info!<br> ";
       echo "Your Donations has been sent. Thank you!";
         ?>
         <script> 
         var msg="Thanks For Donating";
         $('#msg').addClass("d-block");
           </script> 
       <?PHP
            }else{
                echo "Error";
            } 
   }
       
      }
   
   

?>