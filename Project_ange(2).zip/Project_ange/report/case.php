<?php
session_start();
?>
<?php
if(!isset($_SESSION["p_user"])){
echo("<script>location.href='../member/login.php';</script>");
}elseif (isset($_SESSION["p_user"])&& !isset($_SESSION["access"])){
 echo("<script>location.href='../member/lock.php';</script>");
}
else{
    include('../member/connection.php'); 
$account_key=$_SESSION["p_user"];
$sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['user_name'];
$myemail=$fetch_account['email'];

$sel_place=$con->query("SELECT*from locations WHERE D_admin='$account_key' ")or die($con->error);
if($count_place=$sel_place->num_rows>0){
//Number of locations this user has responsed to work on
  $locations=$count_place;
 
}else{
  $locations=0;
}

$today=date(" M d, Y");
$time=date("h:i a");
}
    ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Case | Care International Rwanda</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Font Awesome Icons -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons -->
    <link href="http://code.ionicframework.com/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css" />
    <!-- fullCalendar 2.2.5-->
    <link href="plugins/fullcalendar/fullcalendar.min.css" rel="stylesheet" type="text/css" />
    <link href="plugins/fullcalendar/fullcalendar.print.css" rel="stylesheet" type="text/css" media='print' />
    <!-- Theme style -->
    <link href="dist/css/AdminLTE.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link href="dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- iCheck -->
    <link href="plugins/iCheck/flat/blue.css" rel="stylesheet" type="text/css" />
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="sidebar-collapse">
    <div class="wrapper">
      
      <header class="main-header">
        <a href="../member/index.php" class="logo"><b>Care</b>Rwanda </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              
              
             
              <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <img src="../member/assets/img/users/<?php echo $fetch_account['profile'] ?>" class="user-image" alt="User Image"/>
                  <span class="hidden-xs"><?php echo $fetch_account['user_name'] ?></span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  
              <li>
                <a class="dropdown-item d-flex align-items-center" href="../member/profile.php">
                  <i class="bi bi-person"></i>
                  <span>My Profile</span>
                </a>
              </li>
              <li>
              <hr class="dropdown-divider">
            </li>
              <li>
                <a class="dropdown-item d-flex align-items-center" href="../member/logout.php">
                  <i class="bi bi-person"></i>
                  
                  <span>Sign Out</span>
                </a>
              </li>
           

                </ul>
              </li>
            </ul>
          </div>
        </nav>

        <!-- Logout Disabled Backdrop Modal-->
       <div class="card">
            <div class="card-body">
             <!-- <h5 class="card-title">Disabled Backdrop</h5>
              <p>You can disable the backdrop by adding <code>data-bs-backdrop="false"</code> to <code>.modal-dialog</code></p>-->

              <!-- Disabled Backdrop Modal -->
             <!-- <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#disablebackdrop">
                Launch Modal
              </button>-->
              <div class="modal fade" id="disablebackdrop" tabindex="-1" data-bs-backdrop="false">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">LOG OUT</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                      You are about to Logout your account, Unsaved changes May be lost!
                      <br>
                      <code>Are you Sure you want to End this Session?</code>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-dark" data-bs-dismiss="modal">Cancel</button>
                       <a href="logout.php?lockscreen" class="btn btn-secondary">Lock Instead</a>
                      <a href="logout.php" class="btn btn-primary">Logout</a>
                    </div>
                  </div>
                </div>
              </div><!-- End Disabled Backdrop Modal-->

            </div>
          </div>
          
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      

      <!-- Right side column. Contains the navbar and content of the page -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
        <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="../member/index.php"><i class="fa fa-dashboard"></i> Home</a></li>
          <li class="breadcrumb-item">Cases</li>
          <li class="breadcrumb-item active">Case Details</li>
        </ol>
      </nav>
        <!-- =======================================================  * All Retreives======================================================== -->
        <?php 
                    
                    if(isset($_GET['U08R'])){
                      $client_id=$_GET['U08R'];

      //========================================== Select Client/Girls====================================================
                      $sel_client=$con->query("SELECT*from girls where id='$client_id' ")or die($con->error);
                      if($count_client=$sel_client->num_rows>0){  
                        $fetch_client=$sel_client->fetch_assoc();
                        $selected_client=1;
                    }else{
                      $selected_client=0;
                    }

//========================================== Select Cases====================================================
                    $sel_case=$con->query("SELECT*from cases where child_id='$client_id' ")or die($con->error);
                    if($count_case=$sel_case->num_rows>0){
                        $fetch_case=$sel_case->fetch_assoc();
                        echo $fetch_case['case_code'];
                        $selected_case=1;
                    }else{
                      $selected_case=0;  
                     // echo $fetch_account['R_district']." None"; 
                    }
                    
                  }else{
                     echo '<div class="callout callout-info">
               <h4><i class="icon fa fa-info"></i>  No Case Selected!</h4>
               <p>
               <hr>
               Go to <a>all cases</a>.</p> </div>
            ';            
                  }?>

  <!-- =======================================================  * End of All Retreives======================================================== -->
          <h1>
            Case
            <small><?php if(isset($selected_client)&&$selected_client==1){ echo $fetch_client['fname']." ".$fetch_client['lname']; } ?></small>
          </h1>
          
          
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-md-3">
            <?php  if(isset($selected_client)&&$selected_client==1){  
              $childnow=$fetch_client["id"];
              if(isset($selected_case)&&$selected_case==1){
                echo '<a class="btn btn-primary btn-block margin-bottom"   href="compose.php?U08R='.$fetch_client["id"].'" >ADD Your Idea</a>';
              }else{
                echo '<a class="btn btn-primary btn-block margin-bottom"   href="compose.php?U08R='.$fetch_client["id"].'" > Create New Case chat For '.$fetch_client["fname"].'</a>';
              }
              }else{
                echo '<a class="btn btn-primary btn-block margin-bottom"   href="../member/index.php">Back to Dashboard</a>';?>
                <script>
                window.stop();
                </script>
           <?php   } ?>
              
            
         

              <div class="box box-solid">
                <div class="box-body ">
                  <ul class="users-list clearfix">
                    
                      <img src="../member/assets/img/users/<?php echo $fetch_client['image'];?>" width="50%" alt="User Image"/>
                      <a class="users-list-name" href="#"><?php echo $fetch_client['fname']." ".$fetch_client['lname']; ?></a>
                     
                      <?php if($fetch_client['category']=='Critical'){ 
                      echo '<span class="badge btn-danger btn-sm"><i class="bi bi-exclamation-octagon me-1"></i> '.$fetch_client["category"].'</span>';
                    }elseif($fetch_client['category']=='Major'){ 
                      echo '<span class="badge btn-primary btn-sm"><i class="bi bi-exclamation-triangle me-1"></i>  '.$fetch_client["category"].'</span>';
                    }elseif($fetch_client['category']=='Minor'){ 
                      echo '<span class="badge btn-info btn-sm"><i class="bi bi-info-circle me-1"></i> '.$fetch_client["category"].'</span>';
                    }else{ 
                      echo '<span class="badge bg-secondary"><i class="bi bi-collection me-1"></i> '.$fetch_client["category"].'</span>';
                    }
                    ?>
                </div>
                <div class="box-header with-border">
                  <h3 class="box-title">Folders</h3>
                </div>
                <div class="box-body no-padding">
                  <ul class="nav nav-pills nav-stacked">
                    <li class="active"><a href="case.php?U08R=<?php echo $fetch_client["id"]; ?>"><i class="fa fa-inbox"></i> All Events <span class="label label-primary pull-right">12</span></a></li>
                    <li><a href="#"><i class="fa fa-envelope-o"></i> Add/Propose an Event on the Case</a></li>
                    <li><a href="#"><i class="fa fa-file-text-o"></i> Drafts</a></li>
                    <li><a href="#"><i class="fa fa-filter"></i> Junk <span class="label label-waring pull-right">65</span></a></li>
                    <li><a href="#"><i class="fa fa-trash-o"></i> Close Case</a></li>
                  </ul>
                </div><!-- /.box-body -->
              </div><!-- /. box -->
              <div class="box box-solid">
                <div class="box-header with-border">
                  <h3 class="box-title">Labels</h3>
                </div>
                <div class="box-body no-padding">
                  <ul class="nav nav-pills nav-stacked">
                    <li><a href="#" class="btn-danger"><i class="fa fa-circle-o text-light-blue"></i> Make Critical</a></li>
                    <li><a href="#" class="btn-warning"><i class="fa fa-circle-o text-light-blue"></i> Make Major</a></li>
                    <li><a href="#" class="btn-info" disabled><i class="fa fa-circle-o text-light-blue"></i> Minor</a></li>
                  </ul>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
            <div class="col-md-9">
              <div class="box box-primary">
                <?php 
                if(isset($selected_case)&&$selected_case==1){ ?>
                   <div class="box-header with-border">
                  <h3 class="box-title">Inbox</h3>
                  <div class="box-tools pull-right">
                    <div class="has-feedback">
                      <input type="text" class="form-control input-sm" placeholder="Search Mail"/>
                      <span class="glyphicon glyphicon-search form-control-feedback"></span>
                    </div>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body no-padding">
                  <div class="mailbox-controls">
                    <!-- Check all button -->
                    <button class="btn btn-default btn-sm checkbox-toggle"><i class="fa fa-square-o"></i></button>
                    <div class="btn-group">
                      <button class="btn btn-default btn-sm"><i class="fa fa-trash-o"></i></button>
                      <button class="btn btn-default btn-sm"><i class="fa fa-reply"></i></button>
                      <button class="btn btn-default btn-sm"><i class="fa fa-share"></i></button>
                    </div><!-- /.btn-group -->
                    <button class="btn btn-default btn-sm"><i class="fa fa-refresh"></i></button>
                    <div class="pull-right">
                      1-50/200
                      <div class="btn-group">
                        <button class="btn btn-default btn-sm"><i class="fa fa-chevron-left"></i></button>
                        <button class="btn btn-default btn-sm"><i class="fa fa-chevron-right"></i></button>
                      </div><!-- /.btn-group -->
                    </div><!-- /.pull-right -->
                  </div>
                  <div class="table-responsive mailbox-messages">
                    <table class="table table-hover table-striped">
                      <tbody>
                        <?php  
                        $sel_clients=$con->query("SELECT*from cases where 	child_id='$childnow' ORDER BY id DESC  ")or die($con->error); 
                        while($fetch_child=$sel_clients->fetch_assoc()){ 
                        ?>
                        <tr>
                          <td><input type="checkbox" /></td>
                          <td class="mailbox-star"><a href="#"><i class="fa fa-star text-yellow"></i></a></td>
                          <td class="mailbox-name"><b><?php echo $fetch_child['event_tittle'];?></b></td>
                          <td class="mailbox-subject"><a href="#"><?php echo $fetch_child['event_tittle'];?></a> - <?php echo $fetch_child['event_text'];?>...</td>
                          <td class="mailbox-attachment"></td>
                          <td class="mailbox-date">   <?php  
 //date_default_timezone_set('America/New_York');  
 //echo facebook_time_ago('2016-03-11 04:58:00');  
 $event_time=$fetch_child['event_time'];
      $time_ago = $event_time;  
      $current_time = time();  
      $time_difference = $current_time - $time_ago;  
      $seconds = $time_difference;  
      $minutes      = round($seconds / 60 );           // value 60 is seconds  
      $hours           = round($seconds / 3600);           //value 3600 is 60 minutes * 60 sec  
      $days          = round($seconds / 86400);          //86400 = 24 * 60 * 60;  
      $weeks          = round($seconds / 604800);          // 7*24*60*60;  
      $months          = round($seconds / 2629440);     //((365+365+365+365+366)/5/12)*24*60*60  
      $years          = round($seconds / 31553280);     //(365+365+365+365+366)/5 * 24 * 60 * 60  
      if($seconds <= 60)  
      {  
     echo "Just Now";  
   }  
      else if($minutes <=60)  
      {  
     if($minutes==1)  
           {  
       echo "one minute ago";  
     }  
     else  
           {  
       echo "$minutes minutes ago";  
     }  
   }  
      else if($hours <=24)  
      {  
     if($hours==1)  
           {  
       echo "an hour ago";  
     }  
           else  
           {  
       echo "$hours hrs ago";  
     }  
   }  
      else if($days <= 7)  
      {  
     if($days==1)  
           {  
       echo "yesterday";  
     }  
           else  
           {  
       echo "$days days ago";  
     }  
   }  
      else if($weeks <= 4.3) //4.3 == 52/12  
      {  
     if($weeks==1)  
           {  
       echo "a week ago";  
     }  
           else  
           {  
       echo "$weeks weeks";  
     }  
   }  
       else if($months <=12)  
      {  
     if($months==1)  
           {  
       echo "a month ago";  
     }  
           else  
           {  
       echo "$months months ago";  
     }  
   }  
      else  
      {  
     if($years==1)  
           {  
       echo "one year ago";  
     }  
           else  
           {  
       echo "$years years ago";  
     }  
   }  

 ?> </td>
                        </tr>
                     <?php } ?>
                      </tbody>
                    </table><!-- /.table -->
                  </div><!-- /.mail-box-messages -->
                </div><!-- /.box-body -->
                <div class="box-footer no-padding">
                  <div class="mailbox-controls">
                    <!-- Check all button -->
                    <button class="btn btn-default btn-sm checkbox-toggle"><i class="fa fa-square-o"></i></button>                    
                    <div class="btn-group">
                      <button class="btn btn-default btn-sm"><i class="fa fa-trash-o"></i></button>
                      <button class="btn btn-default btn-sm"><i class="fa fa-reply"></i></button>
                      <button class="btn btn-default btn-sm"><i class="fa fa-share"></i></button>
                    </div><!-- /.btn-group -->
                    <button class="btn btn-default btn-sm"><i class="fa fa-refresh"></i></button>
                    <div class="pull-right">
                      1-50/200
                      <div class="btn-group">
                        <button class="btn btn-default btn-sm"><i class="fa fa-chevron-left"></i></button>
                        <button class="btn btn-default btn-sm"><i class="fa fa-chevron-right"></i></button>
                      </div><!-- /.btn-group -->
                    </div><!-- /.pull-right -->
                  </div>
                </div>
                <?php
                //Clossing the availability
                }else{
                  echo ' <div class="box-header with-border">
                  <h3 class="box-title">Read Mail</h3>
                  <div class="box-tools pull-right">
                    <a href="#" class="btn btn-box-tool" data-toggle="tooltip" title="Previous"><i class="fa fa-chevron-left"></i></a>
                    <a href="#" class="btn btn-box-tool" data-toggle="tooltip" title="Next"><i class="fa fa-chevron-right"></i></a>
                  </div>';
                  echo '<div class="mailbox-read-info">
                  <h3>There is No current event on This client!</h3>
                  <h5>Cleat One Now!! <span class="mailbox-read-time pull-right">15 Feb. 2015 11:03 PM</span></h5>
                </div>';

                echo ' <div class="mailbox-controls with-border text-center">
                <div class="btn-group">
                  <button class="btn btn-default btn-sm" data-toggle="tooltip" title="Delete"><i class="fa fa-trash-o"></i></button>
                  <button class="btn btn-default btn-sm" data-toggle="tooltip" title="Reply"><i class="fa fa-reply"></i></button>
                  <button class="btn btn-default btn-sm" data-toggle="tooltip" title="Forward"><i class="fa fa-share"></i></button>
                </div><!-- /.btn-group -->
                <button class="btn btn-default btn-sm" data-toggle="tooltip" title="Print"><i class="fa fa-print"></i></button>
              </div><!-- /.mailbox-controls -->';
                }
                
                ?>
             
              </div><!-- /. box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
      <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>Care</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
     
      Designed by <a href="#">Umwali Ange</a>
    </div>
  </footer><!-- End Footer -->
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.3 -->
    <script src="plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- Slimscroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js" type="text/javascript"></script>
    <!-- iCheck -->
    <script src="plugins/iCheck/icheck.min.js" type="text/javascript"></script>
    <!-- Page Script -->
    <script>
      $(function () {
        //Enable iCheck plugin for checkboxes
        //iCheck for checkbox and radio inputs
        $('input[type="checkbox"]').iCheck({
          checkboxClass: 'icheckbox_flat-blue',
          radioClass: 'iradio_flat-blue'
        });

        //Enable check and uncheck all functionality
        $(".checkbox-toggle").click(function () {
          var clicks = $(this).data('clicks');
          if (clicks) {
            //Uncheck all checkboxes
            $("input[type='checkbox']", ".mailbox-messages").iCheck("uncheck");
          } else {
            //Check all checkboxes
            $("input[type='checkbox']", ".mailbox-messages").iCheck("check");
          }
          $(this).data("clicks", !clicks);
        });

        //Handle starring for glyphicon and font awesome
        $(".mailbox-star").click(function (e) {
          e.preventDefault();
          //detect type
          var $this = $(this).find("a > i");
          var glyph = $this.hasClass("glyphicon");
          var fa = $this.hasClass("fa");          

          //Switch states
          if (glyph) {
            $this.toggleClass("glyphicon-star");
            $this.toggleClass("glyphicon-star-empty");
          }

          if (fa) {
            $this.toggleClass("fa-star");
            $this.toggleClass("fa-star-o");
          }
        });
      });
    </script>
  </body>
</html>